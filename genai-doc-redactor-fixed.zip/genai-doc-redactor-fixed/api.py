"""Local REST API: the same agent, callable from other programs on this computer.

    python api.py                      # serves http://127.0.0.1:8600

Endpoints
---------
GET  /health    Status: local-only mode, Ollama reachability. No document data.
POST /protect   multipart/form-data with:
                  file            PDF, DOCX, PNG or JPG (required)
                  question        what you need from the document (required)
                  privacy_mode    Strict | Maximum | Standard      (default Strict)
                  style           solid | blur | replacement        (default solid)
                  output_format   PDF | DOCX | PNG | JPG            (default PDF)
                  ai_mode         Auto | Always | Off               (default Auto)
                  verify_output   true | false (OCR read-back)      (default true)
                  recipient       who the copy is for: adds an invisible
                                  trace mark                      (optional)
                Returns JSON: answer, disclosed field names and values,
                computed answers, re-identification risk, security warnings,
                photos/codes found, the output check, the privacy audit, and
                the protected file as base64. The upload and the generated
                file are deleted from disk before the response is sent.
POST /trace     multipart/form-data with ``file``: a protected copy. Returns
                who it was made for, if it carries a trace mark.

The server listens on 127.0.0.1 only and refuses to start on another address
while LOCAL_ONLY is on. Set API_TOKEN in .env to also require
``Authorization: Bearer <token>`` from callers.
"""
from __future__ import annotations

import base64
import hmac
import ipaddress
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import LOCAL_ONLY, MAX_FILE_SIZE_MB
from utils import network_guard

if LOCAL_ONLY:
    network_guard.activate_local_only()

from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from agents.field_matcher import display_label
from agents.llm_client import LLMClient
from pipeline import process_document
from utils.file_utils import get_temp_path, save_upload, validate_file
from utils.logging_utils import get_logger
from utils.retention import delete_files
from redaction.watermark import trace_file

logger = get_logger("api")

API_HOST = os.getenv("API_HOST", "127.0.0.1")
API_PORT = int(os.getenv("API_PORT", "8600"))
API_TOKEN = os.getenv("API_TOKEN", "")

_STYLES = {"solid": "blackout", "blackout": "blackout", "blur": "blur", "replacement": "replacement"}
_TRUE = {"1", "true", "yes", "on"}


def _authorised(request: Request) -> bool:
    if not API_TOKEN:
        return True
    header = request.headers.get("authorization", "")
    return hmac.compare_digest(header, f"Bearer {API_TOKEN}")


def _error(status: int, message: str) -> JSONResponse:
    return JSONResponse({"error": message}, status_code=status)


async def health(request: Request) -> JSONResponse:
    if not _authorised(request):
        return _error(401, "Missing or wrong API token.")
    try:
        ollama_ok, _ = await run_in_threadpool(LLMClient().check_connection)
    except Exception:
        ollama_ok = False
    return JSONResponse({
        "status": "ok",
        "local_only": network_guard.is_enabled(),
        "blocked_connections": network_guard.blocked_count(),
        "ollama_available": ollama_ok,
    })


async def protect(request: Request) -> JSONResponse:
    if not _authorised(request):
        return _error(401, "Missing or wrong API token.")
    try:
        form = await request.form(max_files=1, max_fields=20)
    except Exception:
        return _error(400, "Send the request as multipart/form-data.")
    upload = form.get("file")
    question = str(form.get("question") or "").strip()
    if upload is None or not hasattr(upload, "read"):
        return _error(400, "A 'file' field is required.")
    if not question:
        return _error(400, "A 'question' field is required.")
    data = await upload.read(MAX_FILE_SIZE_MB * 1024 * 1024 + 1)
    ok, message = validate_file(upload.filename or "", len(data))
    if not ok:
        return _error(400, message)
    style = _STYLES.get(str(form.get("style") or "solid").lower())
    if style is None:
        return _error(400, "style must be solid, blur or replacement.")

    saved = save_upload(upload.filename, data)
    result = None
    try:
        result = await run_in_threadpool(
            process_document,
            saved, question,
            redaction_mode=style,
            output_format=str(form.get("output_format") or "PDF"),
            privacy_mode=str(form.get("privacy_mode") or "Strict"),
            llm_mode=str(form.get("ai_mode") or "Auto"),
            verify_output=str(form.get("verify_output") or "true").lower() in _TRUE,
            recipient=str(form.get("recipient") or "").strip() or None,
        )
        output = result.output_path.read_bytes() if result.output_path and result.output_path.exists() else None
    finally:
        # Nothing from this request stays on disk.
        delete_files([saved, result.output_path if result else None])
    if result.error:
        return _error(422, result.error)

    disclosed = {
        display_label(f): f.value for f in result.fields if f.field_id in result.selected_field_ids
    }
    return JSONResponse({
        "answer": result.decision.answer,
        "disclosed_fields": disclosed,
        "interpretation": result.query_diagnostics.get("requested_segments", []),
        "ai_status": result.decision.llm_status,
        "computed_answers": [
            {"answer": d.label, "value": d.text, "computed_from": d.source_label} for d in result.derived_answers
        ],
        "risk": result.risk,
        "security_warnings": [
            {"kind": f["kind"], "reason": f["reason"], "page": f["page"]} for f in result.security_findings
        ],
        "visual_regions": [
            {"kind": r.kind, "page": r.page, "shown": r.region_id in result.visual_disclosed}
            for r in result.visual_regions
        ],
        "traced_copy": result.trace or None,
        "output_check": result.leak_check,
        "audit": result.audit_report,
        "file_name": result.output_path.name if result.output_path else None,
        "file_base64": base64.b64encode(output).decode("ascii") if output else None,
        "processing_seconds": round(result.processing_time, 1),
    })


async def trace(request: Request) -> JSONResponse:
    if not _authorised(request):
        return _error(401, "Missing or wrong API token.")
    try:
        form = await request.form(max_files=1, max_fields=5)
    except Exception:
        return _error(400, "Send the request as multipart/form-data.")
    upload = form.get("file")
    if upload is None or not hasattr(upload, "read"):
        return _error(400, "A 'file' field is required.")
    data = await upload.read(MAX_FILE_SIZE_MB * 1024 * 1024 + 1)
    if len(data) > MAX_FILE_SIZE_MB * 1024 * 1024:
        return _error(400, f"File too large (max {MAX_FILE_SIZE_MB} MB).")
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in (".pdf", ".docx", ".png", ".jpg", ".jpeg", ".zip"):
        return _error(400, "Upload a protected PDF, DOCX, PNG, JPG or ZIP.")
    temp = get_temp_path(suffix)
    temp.write_bytes(data)
    try:
        return JSONResponse(await run_in_threadpool(trace_file, temp))
    finally:
        temp.unlink(missing_ok=True)


app = Starlette(routes=[
    Route("/health", health, methods=["GET"]),
    Route("/protect", protect, methods=["POST"]),
    Route("/trace", trace, methods=["POST"]),
])


def _is_loopback(host: str) -> bool:
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return host == "localhost"


if __name__ == "__main__":
    if LOCAL_ONLY and not _is_loopback(API_HOST):
        raise SystemExit("Local-only mode: API_HOST must be a loopback address such as 127.0.0.1.")
    import uvicorn
    uvicorn.run(app, host=API_HOST, port=API_PORT, log_level="warning")
