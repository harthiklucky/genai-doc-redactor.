"""Main processing pipeline: ingest -> OCR -> PII -> GenAI -> Redact -> Output."""
from __future__ import annotations
import hashlib
import time
import uuid
from copy import deepcopy
from dataclasses import asdict, replace
from pathlib import Path
from PIL import Image

from ingestion.document_model import DocumentRepresentation, DocumentPage
from ingestion.pdf_processor import is_scanned_pdf, extract_text_pdf, render_pdf_pages
from ingestion.image_processor import load_image
from ingestion.layout_refiner import snap_split_boundaries
from ingestion.field_extractor import (
    DocumentField,
    extract_document_fields,
    field_element_ids,
    query_explicitly_matches_value,
    split_inline_key_value_spans,
)
from agents.field_matcher import (
    NOT_FOUND_ANSWER, SegmentResolution, _distinctive, build_answer, canonical_tokens,
    concept_category, display_label,
    match_fields, validate_llm_field_selection,
)
from ocr.factory import get_ocr_engine
from pii.presidio_detector import detect_pii_in_elements
from agents.privacy_agent import analyze_document
from agents.relevance import (
    FILLER_WORDS, extract_answer_from_keep_fields, find_relevant_field_ids,
    normalize_tokens,
)
from agents.schemas import FieldDecision, RedactionAction
from agents.schemas import PrivacyDecisionResponse
from agents.llm_client import LLMClient
from redaction.image_redactor import render_visual_regions, selective_disclosure_image
from redaction.pdf_redactor import images_to_pdf
from redaction.docx_redactor import images_to_docx
from redaction.output_writer import images_to_raster_output
from redaction.leak_check import verify_protected_output
from redaction import watermark
from ingestion.visual_detector import VisualRegion, detect_visual_regions, qr_codes_readable, requested_kind
from agents.derived_answers import derive
from agents.injection_detector import find_instructions, find_invisible_text
from agents.risk import Item, assess, item_for_field
from rendering.document_viewer import get_privacy_summary, add_secure_document_heading
from utils.file_utils import get_output_path
from utils.document_type import infer_document_type
from utils.logging_utils import get_logger
import config

logger = get_logger("pipeline")

LOW_CONFIDENCE = 0.5
MAX_QUERY_CHARS = 1000
LLM_MODES = {"Auto", "Always", "Off"}


class PipelineResult:
    def __init__(self):
        self.document: DocumentRepresentation | None = None
        self.original_images: list[Image.Image] = []
        self.redacted_images: list[Image.Image] = []
        self.redacted_pdf_path: Path | None = None
        self.output_path: Path | None = None
        self.output_format: str = "PDF"
        self.decision: PrivacyDecisionResponse | None = None
        self.privacy_summary: dict = {}
        self.audit_report: dict = {}
        self.document_type: str = "Secure Document"
        self.fields: list[DocumentField] = []
        self.resolutions: list[SegmentResolution] = []
        self.query_diagnostics: dict = {}
        self.leak_check: dict = {}
        # Set by the UI, which keeps the protected file in memory only.
        self.output_bytes: bytes | None = None
        self.output_name: str = ""
        self.selected_field_ids: set[str] = set()
        self.derived_answers: list = []          # agents.derived_answers.DerivedAnswer
        self.visual_regions: list[VisualRegion] = []
        self.visual_disclosed: set[str] = set()
        self.security_findings: list[dict] = []  # excerpts: for the user's screen only
        self.risk: dict = {}
        self.trace: dict = {}
        self.processing_time: float = 0.0
        self.error: str | None = None


def process_document(
    file_path: Path,
    user_query: str,
    redaction_mode: str = "blackout",
    llm_provider: str | None = None,
    llm_model: str | None = None,
    output_format: str = "PDF",
    privacy_mode: str = "Strict",
    llm_mode: str = "Auto",
    disclose_field_ids: set[str] | None = None,
    verify_output: bool = False,
    ingest_cache: dict | None = None,
    disclose_visual_ids: set[str] | None = None,
    recipient: str | None = None,
) -> PipelineResult:
    """Run the full document redaction pipeline.

    ``llm_mode``: "Auto" consults the local model only for parts of the
    request that deterministic field matching cannot resolve, "Always"
    consults it on every request, "Off" never does.

    ``disclose_field_ids``: a reviewed selection made by the user. When given,
    exactly these extracted fields are disclosed and request matching and the
    model are skipped.

    ``verify_output``: also read the protected pages back with local OCR and
    refuse to release the file if any protected value is readable. (The file
    content check always runs.)

    ``ingest_cache``: a dict owned by the caller (e.g. one browser session).
    Extraction results for the most recent file are kept in it, in memory, so
    follow-up questions on the same file skip OCR and PII detection.

    ``disclose_visual_ids``: with a reviewed selection, the photos / codes /
    signatures (visual region IDs) to show.

    ``recipient``: when given, every page carries an invisible trace mark and
    the local ledger records who this copy was made for.
    """
    result = PipelineResult()
    user_query = (user_query or "").strip()
    if not user_query:
        result.error = "Please enter a question about the document."
        return result
    if len(user_query) > MAX_QUERY_CHARS:
        result.error = f"The question is too long (maximum {MAX_QUERY_CHARS} characters)."
        return result
    llm_mode = (llm_mode or "Auto").strip().title()
    if llm_mode not in LLM_MODES:
        llm_mode = "Auto"
    output_format = (output_format or "PDF").upper()
    if output_format not in {"PDF", "DOCX", "PNG", "JPG", "JPEG"}:
        result.error = f"Unsupported output format: {output_format}"
        return result
    result.output_format = "JPG" if output_format == "JPEG" else output_format
    privacy_mode = (privacy_mode or "Strict").strip().title()
    if privacy_mode not in {"Standard", "Strict", "Maximum"}:
        privacy_mode = "Strict"
    start_time = time.time()

    try:
        ext = file_path.suffix.lower()
        logger.info("Processing %s file", ext)
        if ext not in (".pdf", ".docx", ".png", ".jpg", ".jpeg"):
            result.error = f"Unsupported file type: {ext}"
            return result

        # Steps 1-2: ingest, layout, PII detection and field extraction (or
        # the cached result of those steps for the same file).
        cache_key = hashlib.sha256(ext.encode() + b"\0" + file_path.read_bytes()).hexdigest()
        cached = ingest_cache.get("entry") if ingest_cache is not None else None
        if cached and cached["key"] == cache_key:
            result.document = deepcopy(cached["document"])
            result.original_images = list(cached["images"])
            logger.info("Stage ingest: reused extraction for this file (cached in memory)")
        else:
            result.document, result.original_images = _ingest(file_path, ext)
            if result.document and result.document.all_elements() and ingest_cache is not None:
                ingest_cache["entry"] = {
                    "key": cache_key, "document": deepcopy(result.document),
                    "images": list(result.original_images),
                }

        if not result.document or not result.document.all_elements():
            result.error = "No text content could be extracted from the document."
            return result

        all_elements = result.document.all_elements()
        result.fields = result.document.fields
        result.document_type = infer_document_type(all_elements)
        result.visual_regions = [VisualRegion(**r) for r in result.document.visual_regions]
        result.security_findings = result.document.security_findings
        # Text that tries to instruct the AI is never disclosed, and the model
        # is not consulted for such a document.
        instruction_ids = {
            eid for f in result.security_findings if f["kind"] == "instruction" for eid in f["element_ids"]
        }
        manipulated = any(f["kind"] in ("instruction", "code_instruction") for f in result.security_findings)

        # Step 3: Query interpretation and deterministic field matching.
        field_by_id = {f.field_id: f for f in result.fields}
        manual_ids = (
            {fid for fid in disclose_field_ids if fid in field_by_id}
            if disclose_field_ids is not None else None
        )
        match = match_fields(result.fields, user_query)
        if manual_ids is not None:
            # A reviewed selection replaces request matching entirely.
            match = replace(match, resolutions=[SegmentResolution(
                segment="your reviewed selection", status="matched", match_type="manual",
                field_ids=sorted(manual_ids), confidence=1.0,
            )], excluded_field_ids=set())
            match.intent.wants_all = False
            llm_mode = "Off"
            result.visual_disclosed = {
                r.region_id for r in result.visual_regions if r.region_id in (disclose_visual_ids or set())
            }
        else:
            # Answers that reveal less than the field (age check, city, last
            # digits...), and requests for a photo / QR code / signature.
            resolved = []
            for res in match.resolutions:
                derived = derive(res.segment, result.fields, already_matched=res.status == "matched")
                kind = requested_kind(res.segment) if res.status != "matched" else None
                if derived is not None:
                    result.derived_answers.append(derived)
                    res = SegmentResolution(segment=res.segment, status="matched", match_type="derived",
                                            confidence=1.0)
                elif kind and any(r.kind == kind for r in result.visual_regions):
                    result.visual_disclosed |= {r.region_id for r in result.visual_regions if r.kind == kind}
                    res = SegmentResolution(segment=res.segment, status="matched", match_type="visual",
                                            confidence=1.0)
                resolved.append(res)
            match = replace(match, resolutions=resolved)
        logger.info(
            "Stage query->fields: %d requested segment(s), %d excluded, %d matched, %d unresolved",
            len(match.intent.segments), len(match.intent.excluded),
            sum(1 for r in match.resolutions if r.status == "matched"), len(match.unresolved),
        )

        # Step 4: Semantic reasoning with the local model, only when it can add
        # something (or when the user asked for it on every request).
        need_llm = llm_mode == "Always" or (
            llm_mode == "Auto" and (bool(match.unresolved) or not result.fields)
        )
        if manipulated:
            need_llm = False
        client = LLMClient(provider=llm_provider, model=llm_model) if need_llm else None
        result.decision = analyze_document(result.document, user_query, client, use_llm=need_llm)
        if manual_ids is not None:
            result.decision.llm_status = "Not used: you chose the fields to disclose."
        elif manipulated:
            result.decision.llm_status = (
                "Not used: this document contains text that tries to instruct the AI, "
                "so only deterministic matching was used."
            )
        elif llm_mode == "Off":
            result.decision.llm_status = "Disabled in settings; deterministic matching only."

        # Step 5: Validate model selections against the document and the request.
        resolutions = match.resolutions
        llm_notes: list[str] = []
        if result.decision.llm_used and result.decision.semantic_document_field_ids:
            resolutions, llm_notes = validate_llm_field_selection(
                match, result.fields, result.decision.semantic_document_field_ids,
                result.decision.confidence,
            )
        if privacy_mode == "Maximum" and manual_ids is None:
            # Maximum mode never discloses a sensitive value on model judgement
            # alone, nor values whose text recognition is unreliable.
            checked = []
            for res in resolutions:
                kept = [
                    fid for fid in res.field_ids
                    if not (res.match_type == "llm_semantic" and field_by_id[fid].sensitivity)
                    and field_by_id[fid].confidence >= LOW_CONFIDENCE
                ]
                if res.status == "matched" and res.field_ids and not kept:
                    llm_notes.append(
                        f"'{res.segment}' withheld: Maximum mode requires an explicit, clearly recognised field"
                    )
                    res = SegmentResolution(segment=res.segment, status="not_found")
                elif res.status == "matched":
                    res = replace(res, field_ids=kept)
                checked.append(res)
            resolutions = checked

        selected_field_ids = {
            fid for res in resolutions if res.status == "matched" for fid in res.field_ids
        } - match.excluded_field_ids
        broad_note = ""
        if match.intent.wants_all:
            if privacy_mode == "Standard":
                selected_field_ids |= {f.field_id for f in result.fields} - match.excluded_field_ids
            else:
                broad_note = (
                    f"{privacy_mode} mode discloses only fields named in the request; "
                    "list the fields you need, or use Standard mode."
                )

        # Step 6: Unstructured text (paragraphs, header-less tables) for parts of
        # the request that no labelled field answers.
        structured_ids = {
            fid for field in result.fields for fid in field_element_ids(field)
        }
        element_by_id = {el.id: el for el in all_elements}
        unstructured = [el for el in all_elements if el.id not in structured_ids]
        unstructured_match_ids: set[str] = set()
        extra_answer_lines: list[str] = []
        updated = []
        for res in resolutions:
            if res.status == "not_found" and unstructured:
                ids = find_relevant_field_ids(unstructured, res.segment)
                ids = _answering_lines(ids, element_by_id, res.segment)
                # A text line answers the request only if it contains every
                # distinctive word of it ("invoice total" is not answered by
                # a title line that just says "INVOICE").
                required = _distinctive(canonical_tokens(res.segment))
                found_tokens = set(canonical_tokens(_joined_text(unstructured, ids, limit=10_000)))
                if ids and not required <= found_tokens:
                    ids = set()
                if ids:
                    unstructured_match_ids |= ids
                    line = extract_answer_from_keep_fields(res.segment, unstructured, ids)
                    extra_answer_lines.append(line or _joined_text(unstructured, ids))
                    res = SegmentResolution(segment=res.segment, status="matched",
                                            match_type="text_line", confidence=0.7)
            updated.append(res)
        resolutions = updated
        if any(r.status == "not_found" for r in resolutions) and not result.fields:
            # Header-less tables and prose: the established line/row policy
            # (deterministic first, then validated model line selections).
            legacy_ids = set(result.decision.semantic_field_ids) - structured_ids - unstructured_match_ids
            legacy_ids = _answering_lines(legacy_ids, element_by_id, user_query)
            if legacy_ids:
                unstructured_match_ids |= legacy_ids
                line = extract_answer_from_keep_fields(user_query, unstructured, legacy_ids)
                extra_answer_lines.append(line or _joined_text(unstructured, legacy_ids))
                resolutions = [
                    SegmentResolution(segment=r.segment, status="matched", match_type="text_line", confidence=0.6)
                    if r.status == "not_found" else r
                    for r in resolutions
                ]
        if privacy_mode != "Standard":
            unstructured_match_ids = {
                fid for fid in unstructured_match_ids
                if not element_by_id[fid].entity_type
                or query_explicitly_matches_value(user_query, element_by_id[fid].text)
            }
        if privacy_mode == "Maximum":
            request_tokens = {
                token for token in normalize_tokens(user_query)
                if token not in FILLER_WORDS
            }
            unstructured_match_ids = {
                fid for fid in unstructured_match_ids
                if query_explicitly_matches_value(user_query, element_by_id[fid].text)
                or bool(request_tokens & set(normalize_tokens(element_by_id[fid].text)))
            }

        # Step 7: Privacy policy -> explicit per-element actions.
        disclosed_ids: set[str] = set(unstructured_match_ids)
        for fid in selected_field_ids:
            disclosed_ids |= field_element_ids(field_by_id[fid])
        context_ids: set[str] = set()
        if privacy_mode == "Standard":
            # Standard mode can show non-sensitive sibling fields on the same
            # row (other cells of a selected table row) for context.
            for fid in selected_field_ids:
                chosen = field_by_id[fid]
                for other in result.fields:
                    if other.field_id in selected_field_ids or other.sensitivity or other.page != chosen.page:
                        continue
                    if _same_line(chosen, other) and not any(
                        element_by_id[e].entity_type for e in other.value_element_ids if e in element_by_id
                    ):
                        context_ids |= field_element_ids(other)
        label_ids = {fid for field in result.fields for fid in field.label_element_ids}
        # Labels stay readable for context unless the label text itself was
        # recognised as personal data (then it is protected like a value).
        visible_label_ids = {
            fid for fid in label_ids if fid in element_by_id and not element_by_id[fid].entity_type
        }
        if privacy_mode == "Maximum":
            visible_label_ids &= disclosed_ids
        value_field = {
            eid: field for field in result.fields for eid in field.value_element_ids
        }
        decisions = []
        for el in all_elements:
            if el.id in instruction_ids:
                decisions.append(FieldDecision(
                    field_id=el.id, action=RedactionAction.HIDE, category="SUSPICIOUS_INSTRUCTION",
                    reason="Text addressed to the AI; never disclosed",
                ))
            elif el.id in disclosed_ids or el.id in context_ids:
                decisions.append(FieldDecision(
                    field_id=el.id, action=RedactionAction.DISCLOSE,
                    category="QUERY_RELEVANT" if el.id in disclosed_ids else "ROW_CONTEXT",
                    reason="Required to answer the user query" if el.id in disclosed_ids
                    else "Non-sensitive context on the requested row (Standard mode)",
                ))
            elif el.id in visible_label_ids:
                decisions.append(FieldDecision(
                    field_id=el.id, action=RedactionAction.DISCLOSE, category="FIELD_LABEL",
                    reason="Field label retained for context",
                ))
            elif el.id in value_field or el.entity_type:
                owner = value_field.get(el.id)
                category = (
                    (concept_category(owner.concept) if owner else None)
                    or (owner.sensitivity[0] if owner and owner.sensitivity else None)
                    or el.entity_type or "FIELD_VALUE"
                )
                decisions.append(FieldDecision(
                    field_id=el.id, action=RedactionAction.REDACT, category=category,
                    reason="Not requested; value protected in output",
                ))
            else:
                decisions.append(FieldDecision(
                    field_id=el.id, action=RedactionAction.HIDE, category="NOT_REQUESTED",
                    reason="Not required for the user query",
                ))
        result.decision.decisions = decisions
        result.selected_field_ids = set(selected_field_ids)
        result.decision.semantic_field_ids = sorted(disclosed_ids)

        # Step 8: Answer built only from the values that are disclosed.
        answer_resolutions = []
        for res in resolutions:
            if res.status == "matched" and res.field_ids:
                res = replace(res, field_ids=[fid for fid in res.field_ids if fid in selected_field_ids])
            answer_resolutions.append(res)
        if match.intent.wants_all and privacy_mode == "Standard":
            answer_resolutions.append(SegmentResolution(
                segment="all fields", status="matched", match_type="all_requested",
                field_ids=[f.field_id for f in result.fields if f.field_id in selected_field_ids],
                confidence=0.9,
            ))
        segment_notes: dict[str, list[str]] = {}
        for derived in result.derived_answers:
            extra_answer_lines.append(f"{derived.label}: {derived.text}")
            segment_notes[derived.segment] = [f"{derived.label} (computed from {derived.source_label}, "
                                              f"which stays hidden)"]
        shown_kinds = dict.fromkeys(r.kind for r in result.visual_regions if r.region_id in result.visual_disclosed)
        for kind in shown_kinds:
            shown = [r for r in result.visual_regions if r.kind == kind and r.region_id in result.visual_disclosed]
            pages = ", ".join(str(page) for page in sorted({r.page for r in shown}))
            extra_answer_lines.append(f"{shown[0].label}: shown in the protected copy (page {pages})")
        for res in answer_resolutions:
            if res.match_type == "visual":
                kind = requested_kind(res.segment)
                segment_notes[res.segment] = [r.label for r in result.visual_regions if r.kind == kind][:1]
        answer = build_answer(
            answer_resolutions, result.fields, match.excluded_field_ids,
            extra_lines=extra_answer_lines, low_confidence_threshold=LOW_CONFIDENCE,
        )
        if (len(answer_resolutions) == 1 and len(result.derived_answers) == 1
                and answer == f"{result.derived_answers[0].label}: {result.derived_answers[0].text}"):
            answer = result.derived_answers[0].text  # a single derived answer stands alone
        if broad_note:
            answer = broad_note if answer == NOT_FOUND_ANSWER else f"{answer}\n{broad_note}"
        for note in llm_notes:
            if " withheld: " in note:
                # Say why nothing was shown, rather than "not found".
                not_found = f"{note.split(' withheld: ')[0]} was not found in the document."
                if not_found in answer:
                    answer = answer.replace(not_found, note)
                elif answer == NOT_FOUND_ANSWER:
                    answer = note
                else:
                    answer = f"{answer}\n{note}"
        result.decision.answer = answer
        result.resolutions = answer_resolutions
        result.query_diagnostics = {
            "requested_segments": [
                {
                    "request": r.segment,
                    "status": r.status,
                    "matched_fields": [display_label(field_by_id[fid]) for fid in r.field_ids if fid in field_by_id]
                    or segment_notes.get(r.segment, []),
                    "match_method": r.match_type or "-",
                    "confidence": r.confidence,
                    "candidates": r.candidate_labels,
                }
                for r in answer_resolutions
            ],
            "excluded_fields": sorted(display_label(field_by_id[f]) for f in match.excluded_field_ids),
            "llm_status": result.decision.llm_status,
            "llm_reasoning": result.decision.llm_reasoning,
            "llm_answer_matches_document": result.decision.llm_answer_verified,
            "validation_notes": llm_notes,
            "fields_extracted": len(result.fields),
            "elements_extracted": len(all_elements),
        }
        logger.info(
            "Stage policy: %d field(s) disclosed, %d element(s) disclosed, %d context, mode=%s, llm_used=%s",
            len(selected_field_ids), len(disclosed_ids), len(context_ids), privacy_mode,
            result.decision.llm_used,
        )

        # Re-identification risk of everything disclosed together (kinds only).
        risk_items = [
            item for f in result.fields if f.field_id in selected_field_ids
            for item in [item_for_field(display_label(f), f.concept, f.sensitivity)] if item
        ]
        risk_items += [Item(d.label, d.kind) for d in result.derived_answers]
        risk_items += [Item(r.label, r.kind) for r in result.visual_regions
                       if r.region_id in result.visual_disclosed and r.kind != "image"]
        risk_items += [
            item for eid in unstructured_match_ids if element_by_id[eid].entity_type
            for item in [item_for_field("Text line", None, [element_by_id[eid].entity_type])] if item
        ]
        result.risk = assess(risk_items)

        result.privacy_summary = get_privacy_summary(result.decision)
        sensitive_ids = {el.id for el in all_elements if el.entity_type} | {
            eid for field in result.fields if field.sensitivity for eid in field.value_element_ids
        }
        disclosed_sensitive = sum(
            1 for d in result.decision.decisions
            if d.field_id in sensitive_ids and d.action.is_keep()
        )
        protected_sensitive = max(0, len(sensitive_ids) - disclosed_sensitive)
        result.privacy_summary.update({
            "pages": len(result.document.pages),
            "sensitive_detected": len(sensitive_ids),
            "disclosed_sensitive": disclosed_sensitive,
            "protected_sensitive": protected_sensitive,
            "disclosure_ratio": round(disclosed_sensitive / len(sensitive_ids), 3) if sensitive_ids else 0.0,
            "protection_ratio": round(protected_sensitive / len(sensitive_ids), 3) if sensitive_ids else 1.0,
            "mean_extraction_confidence": round(sum(el.confidence for el in all_elements) / len(all_elements), 3) if all_elements else 0.0,
            "privacy_mode": privacy_mode,
        })
        field_by_element = {}
        for field in result.fields:
            for fid in field.label_element_ids + field.value_element_ids:
                field_by_element[fid] = display_label(field)
        result.audit_report = {
            "query": "Omitted to avoid storing user-entered sensitive text",
            "document_type": result.document_type,
            "privacy_mode": privacy_mode,
            "selection": "reviewed by user" if manual_ids is not None else "from the request",
            "llm": result.decision.llm_status,
            "summary": {key: result.privacy_summary[key] for key in (
                "pages", "sensitive_detected", "disclosed_sensitive", "protected_sensitive",
                "disclosure_ratio", "protection_ratio", "mean_extraction_confidence"
            )},
            "fields": [
                {"page": f.page, "field": display_label(f), "source": f.source_type,
                 "sensitivity": f.sensitivity, "confidence": round(f.confidence, 3),
                 "action": "DISCLOSED" if f.field_id in selected_field_ids else "PROTECTED"}
                for f in result.fields
            ],
            "decisions": [
                {"page": element_by_id[d.field_id].page,
                 "field": field_by_element.get(d.field_id, d.category),
                 "category": d.category,
                 "action": "DISCLOSED" if d.action.is_keep() else "PROTECTED",
                 "reason": ("Selected by the request" if d.action.is_keep()
                            else "Not needed for the request; protected in output")}
                for d in result.decision.decisions if d.field_id in sensitive_ids
            ],
            "derived_answers": [
                {"answer": d.label, "computed_from": d.source_label, "source_disclosed": False}
                for d in result.derived_answers
            ],
            "visual_regions": [
                {"page": r.page, "kind": r.kind,
                 "action": "DISCLOSED" if r.region_id in result.visual_disclosed else "PROTECTED"}
                for r in result.visual_regions
            ],
            "security_warnings": [
                {"kind": f["kind"], "reason": f["reason"], "page": f["page"]} for f in result.security_findings
            ],
            "risk": {key: result.risk[key] for key in ("level", "score", "identifying_bits", "reasons")},
        }
        logger.info("AI decision: %d visible, %d redacted, %d hidden",
                     result.privacy_summary["visible_count"],
                     result.privacy_summary["redacted_count"],
                     result.privacy_summary.get("hidden_count", 0))

        # Step 4: Copy approved regions and all detected field labels onto a
        # clean canvas. Mask unrequested field values and hide unrelated text.
        keep_ids = {
            d.field_id for d in result.decision.decisions
            if d.action.is_keep()
        }
        # Values are shown only when the validated decision discloses them;
        # every other key/value value is replaced on the new output canvas
        # using the selected style, so the reader sees that it was protected.
        protected_value_ids = {
            fid for field in result.fields for fid in field.value_element_ids
            if fid not in keep_ids
        }

        for page_data in result.document.pages:
            page_idx = page_data.page - 1
            if page_idx >= len(result.original_images):
                continue

            orig_img = result.original_images[page_idx]
            keep_elements = [el for el in page_data.elements if el.id in keep_ids]
            protected_elements = [el for el in page_data.elements if el.id in protected_value_ids]
            hidden_elements = [
                el for el in page_data.elements
                if el.id not in keep_ids and el.id not in protected_value_ids
            ]

            scale_x = orig_img.width / page_data.width if page_data.width else 1.0
            scale_y = orig_img.height / page_data.height if page_data.height else 1.0

            redacted_img = selective_disclosure_image(
                orig_img,
                keep_elements,
                mode=redaction_mode,
                scale_x=scale_x,
                scale_y=scale_y,
                protected_elements=protected_elements,
                hidden_elements=hidden_elements,
            )
            page_regions = [r for r in result.visual_regions if r.page == page_data.page]
            if page_regions:
                redacted_img = render_visual_regions(
                    redacted_img, orig_img, page_regions, result.visual_disclosed, mode=redaction_mode,
                )
            if page_idx == 0:
                redacted_img = add_secure_document_heading(redacted_img, result.document_type)
            result.redacted_images.append(redacted_img)

        # Traceable copy: an invisible mark naming who this copy is for.
        if recipient and recipient.strip() and result.redacted_images:
            trace_id = watermark.register(
                recipient, result.document_type, result.output_format, len(result.redacted_images),
            )
            result.redacted_images = [watermark.embed(image, trace_id) for image in result.redacted_images]
            result.trace = {"trace_id": f"{trace_id:08x}", "recipient": " ".join(recipient.split())[:120]}
            result.audit_report["traced_copy"] = dict(result.trace)

        # Step 5: Generate a new protected file in the selected format. Every
        # format is built from the already-sanitized page images, never from
        # the original document bytes.
        if result.redacted_images:
            ext_by_format = {"PDF": ".pdf", "DOCX": ".docx", "PNG": ".png", "JPG": ".jpg"}
            # A fresh name per run, so a download can never serve the file of
            # an earlier request.
            output_path = get_output_path(
                file_path.name, suffix=f"_protected_{uuid.uuid4().hex[:8]}",
                ext=ext_by_format[result.output_format],
            )
            if result.output_format == "PDF":
                result.redacted_pdf_path = images_to_pdf(result.redacted_images, output_path)
                result.output_path = result.redacted_pdf_path
            elif result.output_format == "DOCX":
                result.output_path = images_to_docx(result.redacted_images, output_path)
            else:
                result.output_path = images_to_raster_output(
                    result.redacted_images, output_path, result.output_format
                )

            logger.info("Stage export: format=%s pages=%d", result.output_format, len(result.redacted_images))

            # Step 6: Check the released file. Every value that should be
            # protected must be unreadable in it; otherwise it is withheld.
            protected_texts = [
                el.text for el in all_elements
                if el.id not in keep_ids and (el.id in protected_value_ids or el.entity_type)
            ]
            visible_texts = [el.text for el in all_elements if el.id in keep_ids] + [result.document_type]
            result.leak_check = verify_protected_output(
                result.output_path, result.redacted_images, protected_texts, visible_texts,
                use_ocr=verify_output,
            )
            hidden_codes = [r for r in result.visual_regions
                            if r.kind == "qr" and r.region_id not in result.visual_disclosed]
            if hidden_codes:
                shown_codes = sum(1 for r in result.visual_regions
                                  if r.kind == "qr" and r.region_id in result.visual_disclosed)
                readable = qr_codes_readable(result.redacted_images)
                result.leak_check["qr_codes_hidden"] = len(hidden_codes)
                result.leak_check["qr_leaks"] = max(0, readable - shown_codes)
                if result.leak_check["qr_leaks"]:
                    result.leak_check["status"] = "failed"
            result.audit_report["output_check"] = result.leak_check
            if result.leak_check["status"] != "passed":
                result.output_path.unlink(missing_ok=True)
                result.output_path = result.redacted_pdf_path = None
                result.error = (
                    "Safety check failed: a protected value could still be read from the generated "
                    "file, so it was deleted and not released. Try the Solid Mask style or another format."
                )

    except ConnectionError as e:
        result.error = str(e)
        logger.error("Connection error: %s", type(e).__name__)
    except Exception as e:
        result.error = f"Processing failed ({type(e).__name__}). Check the file and local processing dependencies, then try again."
        logger.error("Pipeline error: %s", type(e).__name__)
    finally:
        result.processing_time = time.time() - start_time
        logger.info("Pipeline completed in %.1fs", result.processing_time)

    return result


def _ingest(file_path: Path, ext: str) -> tuple[DocumentRepresentation | None, list[Image.Image]]:
    """Read the file, align layout, detect PII and extract labelled fields."""
    if ext == ".pdf":
        document, images = _process_pdf(file_path)
    elif ext == ".docx":
        document, images = _process_docx(file_path)
    else:
        document, images = _process_image(file_path)
    if not document or not document.all_elements():
        return document, images

    all_elements = document.all_elements()
    for element in all_elements:
        element.document_id = document.document_id
    logger.info("Extracted %d elements across %d pages", len(all_elements), len(document.pages))

    # Snap estimated label/value splits to real whitespace on the page so
    # masks neither clip labels nor miss value pixels.
    snapped = sum(
        snap_split_boundaries(page.elements, images[page.page - 1])
        for page in document.pages if page.page - 1 < len(images)
    )
    logger.info("Stage layout: %d label/value boundaries aligned to page whitespace", snapped)

    # Text a reader cannot see (white, microscopic, off-page) is removed
    # before anything else uses it: it is the usual carrier of planted
    # instructions or fake values.
    findings = []
    for page in document.pages:
        if page.page - 1 < len(images):
            hidden = find_invisible_text(page.elements, images[page.page - 1])
            hidden_ids = {eid for f in hidden for eid in f.element_ids}
            page.elements = [el for el in page.elements if el.id not in hidden_ids]
            findings.extend(hidden)
    all_elements = document.all_elements()
    if not all_elements:
        document.security_findings = [asdict(f) for f in findings]
        return document, images

    pdf_sizes = None
    if ext == ".pdf":
        import pymupdf as fitz
        with fitz.open(str(file_path)) as pdf:
            pdf_sizes = [(pg.rect.width, pg.rect.height) for pg in pdf]
    regions, code_texts = detect_visual_regions(
        images, [page.elements for page in document.pages],
        pdf_path=file_path if ext == ".pdf" else None, pdf_page_sizes=pdf_sizes,
    )
    document.visual_regions = [r.as_dict() for r in regions]
    findings.extend(find_instructions(all_elements, code_texts))
    document.security_findings = [asdict(f) for f in findings]
    if findings:
        logger.warning("Stage security: %d suspicious item(s) (%s)", len(findings),
                       ", ".join(sorted({f.kind for f in findings})))

    for page in document.pages:
        detect_pii_in_elements(page.elements)
    document.fields = extract_document_fields(all_elements, document.document_id)

    pii_count = sum(1 for el in all_elements if el.entity_type)
    logger.info("Stage extraction: %d field(s) (%s), %d PII-tagged element(s)",
                len(document.fields),
                ", ".join(sorted({f.source_type for f in document.fields})) or "none",
                pii_count)
    return document, images


def _answering_lines(ids: set[str], element_by_id: dict, request: str) -> set[str]:
    """Drop lines that cannot answer anything: a question printed in the
    document, or a line that only repeats the requested words (a bare
    "Address" label)."""
    request_words = set(canonical_tokens(request))
    return {
        eid for eid in ids
        if eid in element_by_id
        and not element_by_id[eid].text.rstrip().endswith("?")
        and set(canonical_tokens(element_by_id[eid].text)) - request_words
    }


def _joined_text(elements, ids: set[str], limit: int = 400) -> str:
    text = " ".join(el.text for el in elements if el.id in ids and el.text.strip())
    return text if len(text) <= limit else text[:limit].rsplit(" ", 1)[0] + " ..."


def _same_line(a: DocumentField, b: DocumentField) -> bool:
    box_a, box_b = a.full_bbox or a.value_bbox, b.full_bbox or b.value_bbox
    if not box_a or not box_b:
        return False
    overlap = min(box_a[3], box_b[3]) - max(box_a[1], box_b[1])
    return overlap >= 0.5 * min(box_a[3] - box_a[1], box_b[3] - box_b[1])


def _process_pdf(file_path: Path) -> tuple[DocumentRepresentation, list[Image.Image]]:
    """Process a PDF file — text-based or scanned."""
    import pymupdf as fitz
    doc = fitz.open(str(file_path))
    scanned = is_scanned_pdf(doc)
    doc.close()

    images = render_pdf_pages(file_path, dpi=200)

    if scanned:
        logger.info("Detected scanned PDF, using OCR")
        return _ocr_images_to_doc(images, file_path), images
    else:
        logger.info("Detected text-based PDF")
        doc_repr = extract_text_pdf(file_path)
        for page_data in doc_repr.pages:
            page_data.elements = split_inline_key_value_spans(page_data.elements)
        # Scale bbox from PDF points to rendered image pixels
        for i, page_data in enumerate(doc_repr.pages):
            if i < len(images):
                img = images[i]
                sx = img.width / page_data.width if page_data.width else 1.0
                sy = img.height / page_data.height if page_data.height else 1.0
                page_data.width = img.width
                page_data.height = img.height
                for el in page_data.elements:
                    el.bbox = [
                        el.bbox[0] * sx,
                        el.bbox[1] * sy,
                        el.bbox[2] * sx,
                        el.bbox[3] * sy,
                    ]
        return doc_repr, images


def _process_docx(file_path: Path) -> tuple[DocumentRepresentation, list[Image.Image]]:
    """Lay a Word document out as a text PDF locally, then process that PDF."""
    from ingestion.docx_processor import docx_to_pdf
    from utils.file_utils import get_temp_path
    temp_pdf = get_temp_path(".pdf")
    try:
        docx_to_pdf(file_path, temp_pdf)
        doc_repr, images = _process_pdf(temp_pdf)
    finally:
        temp_pdf.unlink(missing_ok=True)
    doc_repr.filename = file_path.name
    doc_repr.file_type = "docx"
    return doc_repr, images


def _process_image(file_path: Path) -> tuple[DocumentRepresentation, list[Image.Image]]:
    """Process a single image file via OCR."""
    image = load_image(file_path)
    doc_repr = _ocr_images_to_doc([image], file_path)
    return doc_repr, [image]


def _ocr_images_to_doc(images: list[Image.Image], file_path: Path) -> DocumentRepresentation:
    """Run OCR on a list of images and build a unified document representation."""
    import uuid
    ocr_engine = get_ocr_engine()
    pages = []

    for i, img in enumerate(images):
        elements = ocr_engine.extract(img, page_num=i + 1)
        elements = split_inline_key_value_spans(elements)
        pages.append(DocumentPage(
            page=i + 1,
            width=img.width,
            height=img.height,
            elements=elements,
        ))

    return DocumentRepresentation(
        document_id=uuid.uuid4().hex[:8],
        filename=file_path.name,
        file_type=file_path.suffix.lower().lstrip("."),
        pages=pages,
    )
