"""Accuracy benchmark on synthetic documents.

    python benchmark.py                 # text documents, deterministic matching
    python benchmark.py --scanned       # also scanned (image/OCR) copies
    python benchmark.py --ai            # also paraphrases answered via the local model

Every case states which values the answer must contain and which sensitive
values must never appear. A case passes only if the answer is right, nothing
forbidden is disclosed, and the output check finds no readable protected value.
All documents are synthetic; everything runs on this machine.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import LOCAL_ONLY
from utils import network_guard

if LOCAL_ONLY:
    network_guard.activate_local_only()

import pymupdf as fitz

from pipeline import process_document

ROOT = Path(__file__).parent
DEMO = ROOT / "demo_documents"


@dataclass
class Case:
    document: str
    question: str
    expect: list[str]
    forbid: list[str]
    ai_mode: str = "Off"
    privacy_mode: str = "Strict"


@dataclass
class Outcome:
    document: str
    question: str
    passed: bool
    answer: str
    missing: list[str] = field(default_factory=list)
    leaked: list[str] = field(default_factory=list)
    output_check: str = ""
    seconds: float = 0.0


def _id_card(path: Path) -> Path:
    """Two-column identity-card layout, labels without colons."""
    rows = [
        ("Full Name", "Ananya Mehta"), ("Date of Birth", "14 August 1998"), ("Gender", "Female"),
        ("Address", "42 Lakeview Road, Coimbatore, Tamil Nadu 641018"), ("Phone Number", "+91 90000 12345"),
        ("Email", "ananya.mehta.demo@example.com"), ("Fake Test Number", "4827 1936 5041"),
    ]
    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 70), "DEMO TEST IDENTITY CARD", fontsize=16)
    for i, (label, value) in enumerate(rows):
        y = 120 + i * 30
        page.insert_text((72, y), label, fontsize=11)
        page.insert_text((230, y), value, fontsize=11)
    doc.save(path)
    doc.close()
    return path


def _stacked_form(path: Path) -> Path:
    """Labels on their own line with the value below (no colons)."""
    lines = ["Customer Form", "Full Name", "Rahul Kumar", "Phone Number", "9876543210",
             "Email Address", "rahul@example.com", "Date of Birth", "15/08/2002"]
    doc = fitz.open()
    page = doc.new_page()
    for i, line in enumerate(lines):
        page.insert_text((72, 80 + i * 24), line, fontsize=12)
    doc.save(path)
    doc.close()
    return path


ID = ["Ananya Mehta", "14 August 1998", "Lakeview", "90000 12345", "ananya.mehta.demo", "4827 1936 5041"]
FORM = ["Rahul Kumar", "9876543210", "rahul@example.com", "15/08/2002"]
INVOICE = ["Jane Smith", "jane.smith@", "321-9876", "4532", "7891"]
MEDICAL = ["John Michael Doe", "987-6543", "john.doe@", "456 Oak Street", "INS-HB-992341", "PT-2024-88421"]
EMPLOYEE = ["Robert James Anderson", "4589", "456-7890", "r.anderson@", "789 Maple Drive", "456-7891"]


def _plain(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalnum())


def _without(values: list[str], *keep: str) -> list[str]:
    return [v for v in values if v not in keep]


def cases(ai: bool) -> list[Case]:
    found = [
        Case("id_card", "What is the date of birth?", ["14 August 1998"], _without(ID, "14 August 1998")),
        Case("id_card", "What is the phone number?", ["90000 12345"], _without(ID, "90000 12345")),
        Case("id_card", "I only need the address", ["Lakeview"], _without(ID, "Lakeview")),
        Case("id_card", "email and gender", ["ananya.mehta.demo", "Female"], _without(ID, "ananya.mehta.demo")),
        Case("id_card", "What is the fake test number?", ["4827 1936 5041"], _without(ID, "4827 1936 5041")),
        Case("id_card", "What is the passport number?", ["not found"], ID),
        # Answers that reveal less than the field.
        Case("id_card", "Is she over 18?", ["Yes"], ID),
        Case("id_card", "Which city does she live in?", ["Coimbatore"], ID),
        Case("id_card", "last 4 digits of the phone number", ["2345"], ID),
        Case("id_card", "What is her year of birth?", ["1998"], ID),
        Case("form", "phone number", ["9876543210"], _without(FORM, "9876543210")),
        Case("form", "name and date of birth", ["Rahul Kumar", "15/08/2002"], _without(FORM, "Rahul Kumar", "15/08/2002")),
        Case("form", "email address", ["rahul@example.com"], _without(FORM, "rahul@example.com")),
        Case("invoice", "What is the invoice total and invoice date?", ["5,086.98", "February 20, 2024"], INVOICE),
        Case("invoice", "What is the invoice number?", ["INV-2024-07823"], INVOICE),
        Case("invoice", "What is the tax amount?", ["381.98"], INVOICE),
        Case("invoice", "unit price of the ergonomic mouse", ["45.00"], INVOICE),
        Case("medical", "Show me the patient's diagnosis and medication.", ["Type 2 Diabetes"], MEDICAL),
        Case("medical", "Who is the attending physician?", ["Sarah Williams"], MEDICAL),
        Case("medical", "What is the HbA1c result?", ["8.2%"], MEDICAL),
        Case("employee", "What is the employee's salary and department?", ["125,000", "Engineering"], EMPLOYEE),
        Case("employee", "What is the employee ID?", ["EMP-2019-04521"], EMPLOYEE),
        Case("employee", "What is the blood group?", ["not found"], EMPLOYEE),
    ]
    if ai:
        found += [
            Case("id_card", "Where does this person live?", ["Lakeview"], _without(ID, "Lakeview"), ai_mode="Auto"),
            Case("id_card", "How can I reach her by phone?", ["90000 12345"], _without(ID, "90000 12345"), ai_mode="Auto"),
            Case("medical", "What illness does the patient have?", ["Diabetes"], MEDICAL, ai_mode="Auto"),
        ]
    return found


def documents(workdir: Path, scanned: bool) -> dict[str, Path]:
    docs = {
        "id_card": _id_card(workdir / "id_card.pdf"),
        "form": _stacked_form(workdir / "form.pdf"),
        "invoice": DEMO / "invoice.pdf",
        "medical": DEMO / "medical_report.pdf",
        "employee": DEMO / "employee_record.pdf",
    }
    if scanned:
        from ingestion.pdf_processor import render_pdf_pages
        for name in list(docs):
            image = render_pdf_pages(docs[name], dpi=200)[0]
            path = workdir / f"{name}_scan.png"
            image.save(path)
            docs[f"{name} (scan)"] = path
    return docs


def run(scanned: bool, ai: bool, verify: bool) -> list[Outcome]:
    outcomes = []
    with tempfile.TemporaryDirectory() as tmp:
        docs = documents(Path(tmp), scanned)
        caches: dict[str, dict] = {}
        all_cases = cases(ai)
        if scanned:
            all_cases += [Case(f"{c.document} (scan)", c.question, c.expect, c.forbid, c.ai_mode, c.privacy_mode)
                          for c in cases(ai)]
        for case in all_cases:
            start = time.time()
            result = process_document(
                docs[case.document], case.question, llm_mode=case.ai_mode, privacy_mode=case.privacy_mode,
                output_format="PNG", verify_output=verify, ingest_cache=caches.setdefault(case.document, {}),
            )
            answer = result.error or result.decision.answer
            # Compare letters and digits only: OCR drops dots and spaces
            # ("ananya.mehta.demo" read as "ananya mehta demo").
            plain = _plain(answer)
            missing = [v for v in case.expect if _plain(v) not in plain]
            rest = plain
            for v in case.expect:
                rest = rest.replace(_plain(v), " ")
            leaked = [v for v in case.forbid if _plain(v) in rest]
            check = (result.leak_check or {}).get("status", "error")
            outcomes.append(Outcome(
                case.document, case.question, not result.error and not missing and not leaked and check == "passed",
                answer, missing, leaked, check, round(time.time() - start, 1),
            ))
            if result.output_path:
                result.output_path.unlink(missing_ok=True)
    return outcomes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--scanned", action="store_true", help="also run scanned (OCR) copies")
    parser.add_argument("--ai", action="store_true", help="also run paraphrases that need the local model")
    parser.add_argument("--verify", action="store_true", help="OCR read-back check on every output (slow)")
    parser.add_argument("--json", type=Path, help="write the results to this JSON file")
    args = parser.parse_args()
    logging.disable(logging.WARNING)

    outcomes = run(args.scanned, args.ai, args.verify)
    width = max(len(f"{o.document}: {o.question}") for o in outcomes)
    for o in outcomes:
        mark = "PASS" if o.passed else "FAIL"
        detail = "" if o.passed else f"  missing={o.missing} leaked={o.leaked} check={o.output_check}"
        print(f"[{mark}] {f'{o.document}: {o.question}':<{width}}  {o.seconds:>5.1f}s{detail}")
    passed = sum(o.passed for o in outcomes)
    leaks = sum(bool(o.leaked) or o.output_check == "failed" for o in outcomes)
    print(f"\n{passed}/{len(outcomes)} cases passed | cases with a disclosure leak: {leaks} | "
          f"network attempts blocked: {network_guard.blocked_count()}")
    if args.json:
        args.json.write_text(json.dumps([asdict(o) for o in outcomes], indent=2), encoding="utf-8")
    return 0 if passed == len(outcomes) else 1


if __name__ == "__main__":
    raise SystemExit(main())
