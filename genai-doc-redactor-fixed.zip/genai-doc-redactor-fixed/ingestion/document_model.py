from __future__ import annotations
from pydantic import BaseModel, Field


class DocumentElement(BaseModel):
    id: str
    text: str
    bbox: list[float] = Field(description="[x0, y0, x1, y1] in pixels")
    document_id: str | None = None
    page: int = 1
    entity_type: str | None = None
    sensitive_spans: list[tuple[int, int]] = Field(
        default_factory=list,
        description="Character offsets of sensitive text within this OCR element",
    )
    confidence: float = 1.0

    @property
    def bbox_tuple(self) -> tuple[float, float, float, float]:
        return (self.bbox[0], self.bbox[1], self.bbox[2], self.bbox[3])

    def text_without_sensitive_spans(self) -> str:
        """Return safe surrounding text without recognized sensitive substrings."""
        if self.entity_type and not self.sensitive_spans:
            return ""
        if not self.sensitive_spans:
            return self.text

        spans = sorted(
            (max(0, start), min(len(self.text), end))
            for start, end in self.sensitive_spans
            if end > start and start < len(self.text) and end > 0
        )
        if not spans:
            return "" if self.entity_type else self.text

        chunks = []
        cursor = 0
        for start, end in spans:
            if start > cursor:
                chunks.append(self.text[cursor:start])
            cursor = max(cursor, end)
        if cursor < len(self.text):
            chunks.append(self.text[cursor:])
        return "".join(chunks)


class DocumentPage(BaseModel):
    page: int
    width: float
    height: float
    elements: list[DocumentElement] = Field(default_factory=list)


class DocumentField(BaseModel):
    """A label/value pair with page-aware source elements and geometry."""
    field_id: str
    document_id: str = ""
    label: str
    value: str
    page: int
    label_element_ids: list[str] = Field(default_factory=list)
    value_element_ids: list[str] = Field(default_factory=list)
    label_bbox: list[float] | None = None
    value_bbox: list[float] | None = None
    full_bbox: list[float] | None = None
    sensitivity: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    source_type: str = "key_value"  # key_value, inline_split, table_row, table_cell, multiline
    # Table cells: the row heading that identifies the cell together with the
    # column label. Kept separately so row headings are not treated as labels
    # that stay visible for every row.
    row_label: str = ""
    row_label_element_ids: list[str] = Field(default_factory=list)
    row_context: str = ""
    concept: str | None = None


class DocumentRepresentation(BaseModel):
    document_id: str
    filename: str
    file_type: str
    pages: list[DocumentPage] = Field(default_factory=list)
    fields: list[DocumentField] = Field(default_factory=list)
    # Photos, QR codes, barcodes and signatures (ingestion/visual_detector.py).
    visual_regions: list[dict] = Field(default_factory=list)
    # Hidden instructions / invisible text (agents/injection_detector.py).
    # Excerpts are kept in memory for the user's screen only.
    security_findings: list[dict] = Field(default_factory=list)

    def all_elements(self) -> list[DocumentElement]:
        result = []
        for page in self.pages:
            result.extend(page.elements)
        return result

    def get_element_by_id(self, element_id: str) -> DocumentElement | None:
        for page in self.pages:
            for el in page.elements:
                if el.id == element_id:
                    return el
        return None

    def full_text(self) -> str:
        lines = []
        for page in self.pages:
            for el in page.elements:
                lines.append(el.text)
        return " ".join(lines)
