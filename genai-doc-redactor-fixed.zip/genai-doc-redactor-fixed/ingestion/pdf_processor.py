from __future__ import annotations
import uuid
from pathlib import Path
import pymupdf as fitz
from PIL import Image
from ingestion.document_model import DocumentElement, DocumentPage, DocumentRepresentation
from utils.logging_utils import get_logger

logger = get_logger("pdf_processor")


def is_scanned_pdf(doc: fitz.Document, sample_pages: int = 3) -> bool:
    """Check if PDF is scanned (image-based) by looking at text content of first few pages."""
    pages_to_check = min(sample_pages, len(doc))
    total_text = ""
    for i in range(pages_to_check):
        total_text += doc[i].get_text()
    return len(total_text.strip()) < 50


def extract_text_pdf(file_path: Path) -> DocumentRepresentation:
    """Extract text and bounding boxes from a text-based PDF."""
    doc = fitz.open(str(file_path))
    doc_id = uuid.uuid4().hex[:8]
    pages = []
    element_counter = 0

    for page_num in range(len(doc)):
        page = doc[page_num]
        rect = page.rect
        page_width = rect.width
        page_height = rect.height

        blocks = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)["blocks"]
        elements = []

        for block in blocks:
            if block["type"] != 0:  # text block
                continue
            for line in block["lines"]:
                for span in line["spans"]:
                    # Some embedded fonts extract spaces as no-break spaces.
                    text = span["text"].replace("\u00a0", " ").strip()
                    if not text:
                        continue
                    bbox = list(span["bbox"])  # [x0, y0, x1, y1]
                    element_counter += 1
                    elements.append(DocumentElement(
                        id=f"field_{element_counter:04d}",
                        text=text,
                        bbox=bbox,
                        page=page_num + 1,
                        confidence=1.0,
                    ))

        pages.append(DocumentPage(
            page=page_num + 1,
            width=page_width,
            height=page_height,
            elements=elements,
        ))

    doc.close()
    logger.info("Extracted %d pages from text PDF", len(pages))
    return DocumentRepresentation(
        document_id=doc_id,
        filename=file_path.name,
        file_type="pdf",
        pages=pages,
    )


def render_pdf_pages(file_path: Path, dpi: int = 200) -> list[Image.Image]:
    """Render each PDF page to a PIL Image."""
    doc = fitz.open(str(file_path))
    images = []
    zoom = dpi / 72
    mat = fitz.Matrix(zoom, zoom)

    for page_num in range(len(doc)):
        page = doc[page_num]
        pix = page.get_pixmap(matrix=mat)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        images.append(img)

    doc.close()
    return images


def get_pdf_page_count(file_path: Path) -> int:
    doc = fitz.open(str(file_path))
    count = len(doc)
    doc.close()
    return count
