"""Find photos, QR codes, barcodes and signatures on a page.

These carry personal data that text extraction never sees: a face, a QR code
that can encode the whole record, a barcode with an ID, a handwritten
signature. Everything runs locally with OpenCV (and PyMuPDF for images
embedded in PDFs). No model is downloaded.

The protected output is drawn on a blank canvas, so these regions are already
absent unless disclosed; detecting them lets the output show a labelled
placeholder ("PHOTO HIDDEN"), lets a request disclose them ("show the photo"),
lets the risk score count them, and lets the leak check confirm that a hidden
QR code cannot be scanned from the output.

QR / barcode contents are decoded only to check them for hidden instructions
(see agents/injection_detector.py); they are never stored or logged.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image

from ingestion.document_model import DocumentElement
from utils.logging_utils import get_logger

logger = get_logger("visual_detector")

KIND_LABELS = {
    "photo": "Photo", "image": "Image", "qr": "QR code", "barcode": "Barcode", "signature": "Signature",
}
_SIGNATURE_LABEL = re.compile(r"\b(signature|signed|sign here|authori[sz]ed signatory)\b", re.IGNORECASE)


@dataclass
class VisualRegion:
    region_id: str
    kind: str                 # photo, image, qr, barcode, signature
    page: int
    bbox: list[float]         # pixels on the rendered page image

    @property
    def label(self) -> str:
        return KIND_LABELS.get(self.kind, self.kind.title())

    def as_dict(self) -> dict:
        return {"region_id": self.region_id, "kind": self.kind, "page": self.page, "bbox": self.bbox}


def _gray(image: Image.Image) -> np.ndarray:
    return np.asarray(image.convert("L"))


def _overlap(a, b) -> float:
    """Share of box a covered by box b."""
    w = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    h = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    area = max((a[2] - a[0]) * (a[3] - a[1]), 1.0)
    return w * h / area


def _codes(gray: np.ndarray) -> tuple[list[tuple[str, list[float]]], list[str]]:
    import cv2
    found, payloads = [], []
    try:
        ok, decoded, points, _ = cv2.QRCodeDetector().detectAndDecodeMulti(gray)
        if ok and points is not None:
            for text, quad in zip(decoded, points):
                xs, ys = quad[:, 0], quad[:, 1]
                found.append(("qr", [float(xs.min()), float(ys.min()), float(xs.max()), float(ys.max())]))
                if text:
                    payloads.append(text)
    except cv2.error:
        pass
    try:
        detector = cv2.barcode.BarcodeDetector()
        ok, points = detector.detect(gray)
        if ok and points is not None:
            for quad in np.asarray(points).reshape(-1, 4, 2):
                box = [float(quad[:, 0].min()), float(quad[:, 1].min()),
                       float(quad[:, 0].max()), float(quad[:, 1].max())]
                if not any(kind == "qr" and _overlap(box, other) > 0.3 for kind, other in found):
                    found.append(("barcode", box))
            try:
                decoded = detector.detectAndDecode(gray)[0]
                payloads.extend(t for t in (decoded if isinstance(decoded, (list, tuple)) else [decoded]) if t)
            except (cv2.error, TypeError, ValueError):
                pass
    except (cv2.error, AttributeError):
        pass
    return found, payloads


def _faces(gray: np.ndarray, text_boxes: list[list[float]]) -> list[list[float]]:
    import cv2
    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    if cascade.empty():
        return []
    side = max(48, min(gray.shape) // 25)
    faces = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=8, minSize=(side, side))
    boxes = []
    for x, y, w, h in (faces if len(faces) else []):
        box = [float(x), float(y), float(x + w), float(y + h)]
        # Printed text can look like a face to the detector; a real face is
        # not covered by recognised text.
        if any(_overlap(box, t) > 0.2 for t in text_boxes):
            continue
        boxes.append(box)
    return boxes


def _portrait_box(face: list[float], gray: np.ndarray) -> list[float]:
    """Grow a face box to the surrounding photo (non-white area)."""
    h, w = gray.shape
    fw, fh = face[2] - face[0], face[3] - face[1]
    box = [face[0] - 0.6 * fw, face[1] - 0.7 * fh, face[2] + 0.6 * fw, face[3] + 1.3 * fh]
    box = [max(0.0, box[0]), max(0.0, box[1]), min(float(w), box[2]), min(float(h), box[3])]
    region = gray[int(box[1]):int(box[3]), int(box[0]):int(box[2])]
    ink = np.argwhere(region < 245)
    if len(ink):
        (y0, x0), (y1, x1) = ink.min(0), ink.max(0)
        box = [box[0] + x0, box[1] + y0, box[0] + x1 + 1, box[1] + y1 + 1]
    return [float(v) for v in box]


def _embedded_images(pdf_path: Path, page_index: int, scale_x: float, scale_y: float, page_area: float):
    import pymupdf as fitz
    boxes = []
    with fitz.open(str(pdf_path)) as pdf:
        if page_index >= len(pdf):
            return boxes
        for info in pdf[page_index].get_image_info():
            x0, y0, x1, y1 = info["bbox"]
            box = [x0 * scale_x, y0 * scale_y, x1 * scale_x, y1 * scale_y]
            area = (box[2] - box[0]) * (box[3] - box[1])
            # Skip specks and full-page scans (a scanned PDF is one big image).
            if area < 400 or area > 0.6 * page_area:
                continue
            boxes.append(box)
    return boxes


def _signatures(gray: np.ndarray, elements: list[DocumentElement]) -> list[list[float]]:
    """Ink next to a "Signature" label that is not recognised text."""
    h, w = gray.shape
    text_boxes = [el.bbox for el in elements]
    boxes = []
    for el in elements:
        if not _SIGNATURE_LABEL.search(el.text) or len(el.text) > 40:
            continue
        line = max(el.bbox[3] - el.bbox[1], 12.0)
        candidates = [
            [el.bbox[2], el.bbox[1] - 1.5 * line, min(w, el.bbox[2] + 0.45 * w), el.bbox[3] + 1.5 * line],
            [el.bbox[0], el.bbox[3], min(w, el.bbox[0] + 0.45 * w), min(h, el.bbox[3] + 4 * line)],
            [el.bbox[0], max(0, el.bbox[1] - 4 * line), min(w, el.bbox[0] + 0.45 * w), el.bbox[1]],
        ]
        for box in candidates:
            x0, y0, x1, y1 = (int(max(0, v)) for v in box)
            if x1 - x0 < 10 or y1 - y0 < 10:
                continue
            ink = gray[y0:y1, x0:x1] < 140
            for t in text_boxes:  # remove recognised text (labels, printed names)
                tx0, ty0 = int(t[0]) - x0 - 2, int(t[1]) - y0 - 2
                tx1, ty1 = int(t[2]) - x0 + 2, int(t[3]) - y0 + 2
                ink[max(0, ty0):max(0, ty1), max(0, tx0):max(0, tx1)] = False
            # Ruled lines (signature lines, table borders) are not a signature.
            rows = ink.sum(1)
            ink[rows > 0.6 * ink.shape[1], :] = False
            cols = ink.sum(0)
            ink[:, cols > 0.8 * ink.shape[0]] = False
            points = np.argwhere(ink)
            if len(points) < 120:
                continue
            (py0, px0), (py1, px1) = points.min(0), points.max(0)
            if px1 - px0 < 2 * line:  # a signature is wider than a short mark
                continue
            boxes.append([float(x0 + px0 - 3), float(y0 + py0 - 3), float(x0 + px1 + 4), float(y0 + py1 + 4)])
            break
    return boxes


def _merge_adjacent(boxes: list[tuple[str, list[float]]]) -> list[tuple[str, list[float]]]:
    """Join pieces of one object (the detector can return a barcode as two halves)."""
    merged: list[tuple[str, list[float]]] = []
    for kind, box in boxes:
        for index, (other_kind, other) in enumerate(merged):
            if other_kind != kind:
                continue
            v_overlap = min(box[3], other[3]) - max(box[1], other[1])
            gap = max(box[0], other[0]) - min(box[2], other[2])
            if v_overlap > 0.5 * min(box[3] - box[1], other[3] - other[1]) and gap < 25:
                merged[index] = (kind, [min(box[0], other[0]), min(box[1], other[1]),
                                        max(box[2], other[2]), max(box[3], other[3])])
                break
        else:
            merged.append((kind, list(box)))
    return merged


def detect_visual_regions(
    images: list[Image.Image],
    pages_elements: list[list[DocumentElement]],
    pdf_path: Path | None = None,
    pdf_page_sizes: list[tuple[float, float]] | None = None,
) -> tuple[list[VisualRegion], list[str]]:
    """Visual regions per page, plus decoded QR/barcode texts (for checks only)."""
    regions: list[VisualRegion] = []
    payloads: list[str] = []
    counter = 0
    for index, image in enumerate(images):
        gray = _gray(image)
        elements = pages_elements[index] if index < len(pages_elements) else []
        text_boxes = [el.bbox for el in elements]
        page_boxes: list[tuple[str, list[float]]] = []

        codes, texts = _codes(gray)
        page_boxes.extend(codes)
        payloads.extend(texts)

        embedded = []
        if pdf_path is not None and pdf_page_sizes and index < len(pdf_page_sizes):
            pw, ph = pdf_page_sizes[index]
            embedded = _embedded_images(pdf_path, index, image.width / pw, image.height / ph,
                                        image.width * image.height)
        faces = _faces(gray, text_boxes)
        for box in embedded:
            container = next((i for i, (_, b) in enumerate(page_boxes) if _overlap(b, box) > 0.8), None)
            if container is not None:
                # An embedded image that holds a QR code / barcode: use the
                # whole image (including its margin) as that region.
                page_boxes[container] = (page_boxes[container][0], box)
                continue
            if any(_overlap(box, b) > 0.5 for _, b in page_boxes):
                continue
            has_face = any(_overlap(face, box) > 0.6 for face in faces)
            page_boxes.append(("photo" if has_face else "image", box))
        for face in faces:
            if not any(_overlap(face, b) > 0.6 for _, b in page_boxes):
                page_boxes.append(("photo", _portrait_box(face, gray)))
        for box in _signatures(gray, elements):
            if not any(_overlap(box, b) > 0.5 for _, b in page_boxes):
                page_boxes.append(("signature", box))

        for kind, box in _merge_adjacent(page_boxes):
            counter += 1
            regions.append(VisualRegion(f"v{counter}", kind, index + 1, [round(v, 1) for v in box]))
    if regions:
        logger.info("Stage visuals: %s", ", ".join(
            f"{sum(r.kind == k for r in regions)} {k}" for k in KIND_LABELS if any(r.kind == k for r in regions)
        ))
    return regions, payloads


def qr_codes_readable(images: list[Image.Image]) -> int:
    """How many QR codes can still be detected on the given pages."""
    count = 0
    for image in images:
        codes, _ = _codes(_gray(image))
        count += sum(1 for kind, _ in codes if kind == "qr")
    return count


# Words in a request that ask for a visual region of a given kind.
REQUEST_WORDS = {
    "photo": {"photo", "photograph", "picture", "pic", "face", "portrait", "selfie"},
    "signature": {"signature", "sign", "signed"},
    "qr": {"qr"},
    "barcode": {"barcode", "bar"},
    "image": {"image", "logo", "stamp", "seal"},
}


def requested_kind(segment: str) -> str | None:
    words = set(re.findall(r"[a-z]+", segment.lower()))
    if "bar" in words and "code" not in words:
        words.discard("bar")
    for kind, options in REQUEST_WORDS.items():
        if words & options:
            return kind
    return None
