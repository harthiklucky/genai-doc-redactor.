from __future__ import annotations
from pathlib import Path
from PIL import Image
from utils.logging_utils import get_logger

logger = get_logger("image_processor")


def load_image(file_path: Path) -> Image.Image:
    """Load an image file and convert to RGB."""
    img = Image.open(file_path).convert("RGB")
    logger.info("Loaded image: %dx%d", img.width, img.height)
    return img
