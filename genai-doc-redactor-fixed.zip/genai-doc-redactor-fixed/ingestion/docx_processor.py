"""DOCX input: lay a Word document out as a text PDF on this machine.

Word documents carry no page geometry, so the text (paragraphs and tables,
in document order) is laid out onto A4 pages with PyMuPDF. The result is an
ordinary text PDF, which then goes through the same extraction, matching and
image-based redaction as any other PDF. Nothing is sent to Word, LibreOffice
or any other program.

Not reproduced: embedded images, headers/footers, text boxes and exact
fonts/spacing of the original. The protected output shows the document's
text content in this simplified layout.
"""
from __future__ import annotations

from pathlib import Path

import pymupdf as fitz

from utils.logging_utils import get_logger

logger = get_logger("docx_processor")

PAGE_WIDTH, PAGE_HEIGHT = 595.0, 842.0  # A4 in points
MARGIN = 54.0
BODY_SIZE = 11.0
HEADING_SIZE = 15.0
LINE_GAP = 1.45
CELL_PAD = 4.0

_FONT_CANDIDATES = (
    ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf"),
    ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ("/Library/Fonts/Arial.ttf", "/Library/Fonts/Arial Bold.ttf"),
)


def _fonts() -> tuple[fitz.Font, fitz.Font]:
    """A Unicode TrueType font when one is installed, else the PDF base font."""
    for regular, bold in _FONT_CANDIDATES:
        if Path(regular).exists():
            bold_font = fitz.Font(fontfile=bold) if Path(bold).exists() else fitz.Font(fontfile=regular)
            return fitz.Font(fontfile=regular), bold_font
    return fitz.Font("helv"), fitz.Font("hebo")


def _wrap(text: str, font: fitz.Font, size: float, width: float) -> list[str]:
    lines: list[str] = []
    for raw_line in text.replace("\t", "    ").splitlines() or [""]:
        words = raw_line.split(" ")
        current = ""
        for word in words:
            candidate = f"{current} {word}" if current else word
            if font.text_length(candidate, fontsize=size) <= width or not current:
                current = candidate
            else:
                lines.append(current)
                current = word
        lines.append(current)
    return lines


class _Layout:
    def __init__(self, pdf: fitz.Document, regular: fitz.Font, bold: fitz.Font):
        self.pdf, self.regular, self.bold = pdf, regular, bold
        self.page = None
        self.writer = None
        self.y = 0.0
        self._new_page()

    def _new_page(self) -> None:
        self.finish_page()
        self.page = self.pdf.new_page(width=PAGE_WIDTH, height=PAGE_HEIGHT)
        self.writer = fitz.TextWriter(self.page.rect)
        self.y = MARGIN

    def finish_page(self) -> None:
        if self.writer is not None and self.page is not None:
            self.writer.write_text(self.page)
            self.writer = None

    def ensure(self, height: float) -> None:
        if self.y + height > PAGE_HEIGHT - MARGIN and self.y > MARGIN:
            self._new_page()

    def text(self, x: float, baseline: float, line: str, font: fitz.Font, size: float) -> None:
        if line.strip():
            self.writer.append((x, baseline), line, font=font, fontsize=size)

    def paragraph(self, text: str, heading: bool) -> None:
        font = self.bold if heading else self.regular
        size = HEADING_SIZE if heading else BODY_SIZE
        line_height = size * LINE_GAP
        width = PAGE_WIDTH - 2 * MARGIN
        if not text.strip():
            self.y += line_height * 0.6
            return
        for line in _wrap(text, font, size, width):
            self.ensure(line_height)
            self.text(MARGIN, self.y + size, line, font, size)
            self.y += line_height
        self.y += size * 0.35

    def table(self, rows: list[list[str]], header: bool) -> None:
        if not rows:
            return
        columns = max(len(r) for r in rows)
        col_width = (PAGE_WIDTH - 2 * MARGIN) / columns
        size = BODY_SIZE - 1
        line_height = size * LINE_GAP
        self.y += size * 0.4
        for index, row in enumerate(rows):
            font = self.bold if header and index == 0 else self.regular
            wrapped = [
                _wrap(cell, font, size, col_width - 2 * CELL_PAD) if cell.strip() else []
                for cell in row + [""] * (columns - len(row))
            ]
            row_height = max(1, max(len(w) for w in wrapped)) * line_height + 2 * CELL_PAD
            self.ensure(row_height)
            top = self.y
            for col, lines in enumerate(wrapped):
                x = MARGIN + col * col_width
                self.page.draw_rect(
                    fitz.Rect(x, top, x + col_width, top + row_height), color=(0.6, 0.6, 0.6), width=0.5,
                )
                for n, line in enumerate(lines):
                    self.text(x + CELL_PAD, top + CELL_PAD + n * line_height + size, line, font, size)
            self.y = top + row_height
        self.y += size * 0.8


def _cell_texts(row) -> list[str]:
    texts, seen = [], set()
    for cell in row.cells:
        # Merged cells repeat the same underlying cell; keep it once.
        if id(cell._tc) in seen:
            continue
        seen.add(id(cell._tc))
        texts.append(" ".join(p.text.strip() for p in cell.paragraphs if p.text.strip()))
    return texts


def docx_to_pdf(docx_path: Path, pdf_path: Path) -> Path:
    """Lay out a DOCX file's paragraphs and tables as a text PDF."""
    try:
        import docx
        from docx.table import Table
    except ImportError as exc:  # pragma: no cover - dependency listed in requirements
        raise RuntimeError("DOCX input needs python-docx: pip install python-docx") from exc

    source = docx.Document(str(docx_path))
    pdf = fitz.open()
    regular, bold = _fonts()
    layout = _Layout(pdf, regular, bold)
    paragraphs = tables = 0
    for block in source.iter_inner_content():
        if isinstance(block, Table):
            layout.table([_cell_texts(row) for row in block.rows], header=True)
            tables += 1
        else:
            style = (block.style.name if block.style is not None else "") or ""
            layout.paragraph(block.text, heading=style.startswith(("Heading", "Title")))
            paragraphs += 1
    layout.finish_page()
    pdf.set_metadata({"title": "", "author": "", "producer": "Privacy Agent"})
    pdf.save(str(pdf_path))
    pages = len(pdf)
    pdf.close()
    logger.info("DOCX laid out: %d paragraph(s), %d table(s), %d page(s)", paragraphs, tables, pages)
    return pdf_path
