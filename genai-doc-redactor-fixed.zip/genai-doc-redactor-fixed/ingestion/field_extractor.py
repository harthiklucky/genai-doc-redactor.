"""Generic key/value field discovery for OCR and text PDF spans."""
from __future__ import annotations

import re
from ingestion.document_model import DocumentElement, DocumentField
from agents.relevance import FILLER_WORDS, _TABLE_HEADER_WORDS, group_rows, is_numeric_span, normalize_tokens


_SEPARATOR = r"(?:\s*[:;]\s*|\s+[–—-]\s+|\s*\|\s*|\s{2,})"
_FIELD_PATTERN = re.compile(
    r"(?<![A-Za-z0-9(])(?P<label>[A-Za-z0-9][A-Za-z0-9 &'()/._#-]{0,39}?)"
    rf"(?P<separator>{_SEPARATOR})"
    r"(?P<value>.*?)(?=[\s,;|]+[A-Z][A-Za-z0-9 &'()/._#-]{0,30}"
    rf"{_SEPARATOR}|$)"
)
_NON_FIELD_LABELS = {"http", "https", "mailto", "file"}
_SEPARATOR_ONLY = {":", ";", "-", "–", "—", "|"}


def _clean_label(text: str) -> str:
    return text.strip().strip("|").strip().rstrip(":;-–— ").strip()


def _lexicon_split(text: str):
    """Split ``Label Value`` (no delimiter) when the label is a known field type.

    Only used for short spans whose leading words exactly name a common field
    type (``Phone 9876543210``, ``Date of Birth 15/08/2002``) and whose
    remainder looks like a value (starts with a capital or digit, or holds an
    e-mail address). Anything else is left alone rather than guessed.
    """
    from agents.field_matcher import FIELD_CONCEPTS
    words = text.split()
    if len(words) < 2 or len(words) > 10 or text.rstrip().endswith((".", "?", "!", ":", ";")):
        return None
    phrases = sorted(
        {p for _, ps in FIELD_CONCEPTS.values() for p in ps}, key=lambda p: len(p.split()), reverse=True
    )
    lowered = text.lower()
    from agents.field_matcher import QUALIFIER_WORDS, canonical_tokens
    if " ".join(lowered.split()) in phrases:  # the whole text is a label ("Email Address")
        return None
    for phrase in phrases:
        if lowered.startswith(phrase + " "):
            value = text[len(phrase):].strip()
            # "Phone Number" / "Address Details" is a longer label, not
            # label + value: a remainder made only of qualifier words
            # ("number", "details", ...) is part of the label.
            rest_tokens = canonical_tokens(value)
            if rest_tokens and set(rest_tokens) <= QUALIFIER_WORDS | {"id"} and not any(
                ch.isdigit() or ch == "@" for ch in value
            ):
                return None
            if value and (value[0].isupper() or value[0].isdigit() or "@" in value):
                return text[:len(phrase)], value, len(text) - len(text[len(phrase):].lstrip())
    return None


def _plausible_label(label: str, separator: str) -> bool:
    """A colon marks a label explicitly. Weaker separators (" - ", "|", wide
    spacing) also join ordinary text such as "Lisa Anderson - (555) 456-7891",
    so there the label must contain a recognisable field word."""
    if ":" in separator:
        return True
    # A semicolon is usually an OCR misreading of a comma inside a value
    # ("42 Lakeview Road, Green Park; Coimbatore"), so it needs a field word
    # like the other weak separators.
    from agents.field_matcher import FIELD_CONCEPTS, canonical_tokens
    tokens = set(canonical_tokens(label))
    if not tokens or any(ch.isdigit() for ch in label):
        return False
    vocabulary = set(_TABLE_HEADER_WORDS) | {
        t for _, phrases in FIELD_CONCEPTS.values() for p in phrases for t in canonical_tokens(p)
    } | {"number", "id"}
    return bool(tokens & vocabulary)


def split_inline_key_value_spans(elements: list[DocumentElement]) -> list[DocumentElement]:
    """Split OCR spans like ``Name: Lucky`` into separately maskable regions.

    Coordinates are proportionally estimated from the text span. This is a
    fallback for engines that return a whole key/value pair as one box.
    """
    output: list[DocumentElement] = []
    for element in elements:
        matches = [
            (match.group("label"), match.start("label"), match.start("value"), match.group("value"), match.end("value"))
            for match in _FIELD_PATTERN.finditer(element.text)
            if match.group("value").strip()
            # "Total  Due:" is one label, not label "Total" with value "Due:".
            and not match.group("value").strip().endswith((":", ";"))
            and match.group("label").strip().lower() not in _NON_FIELD_LABELS
            and len(match.group("label").split()) <= 4
            and not any(mark in match.group("label").strip().rstrip(".") for mark in ".!?\n")
            and _plausible_label(match.group("label"), match.group("separator"))
            # A label needs a word: "10:30 AM" is a time, not "10" -> "30 AM".
            and re.search(r"[A-Za-z]{2,}", match.group("label"))
            and not (match.group("label").rstrip()[-1:].isdigit() and match.group("value").lstrip()[:1].isdigit())
        ]
        if not matches:
            lexical = _lexicon_split(element.text)
            if lexical:
                label, value, value_start = lexical
                matches = [(label, 0, value_start, element.text[value_start:], len(element.text))]
        if not matches:
            output.append(element)
            continue

        x0, y0, x1, y1 = element.bbox
        width = max(0.0, x1 - x0)
        for index, (label_text, label_start, raw_value_start, raw_value, value_end) in enumerate(matches, start=1):
            label = label_text.strip().rstrip(":;-–— ") + ":"
            value = raw_value.strip()
            label_end = raw_value_start
            value_start = raw_value_start + len(raw_value) - len(raw_value.lstrip())
            text_len = max(len(element.text), 1)
            label_x0 = x0 + width * label_start / text_len
            label_x1 = x0 + width * label_end / text_len
            estimated_char_width = width / text_len
            value_x0 = max(
                label_x0,
                x0 + width * value_start / text_len - max(6.0, estimated_char_width * 1.5),
            )
            value_x1 = x0 + width * value_end / text_len
            output.append(DocumentElement(
                id=f"{element.id}::label{index}", text=label,
                bbox=[label_x0, y0, label_x1, y1], page=element.page,
                confidence=element.confidence,
            ))
            output.append(DocumentElement(
                id=f"{element.id}::value{index}", text=value,
                bbox=[value_x0, y0, value_x1, y1], page=element.page,
                confidence=element.confidence,
            ))
    return output


def _union_bbox(boxes: list[list[float]]) -> list[float]:
    return [
        min(box[0] for box in boxes), min(box[1] for box in boxes),
        max(box[2] for box in boxes), max(box[3] for box in boxes),
    ]


def _make_field(
    label_element: DocumentElement,
    value_elements: list[DocumentElement],
    document_id: str,
    source_type: str,
    label: str | None = None,
    label_elements: list[DocumentElement] | None = None,
) -> DocumentField:
    label_elements = label_elements or [label_element]
    value = " ".join(_clean_value(el.text) for el in value_elements).strip()
    boxes = [*(el.bbox for el in label_elements), *(el.bbox for el in value_elements)]
    return DocumentField(
        field_id=f"p{label_element.page}:{label_element.id}",
        document_id=document_id or label_element.document_id or "",
        label=label if label is not None else _clean_label(" ".join(el.text for el in label_elements)),
        value=value,
        page=label_element.page,
        label_element_ids=[el.id for el in label_elements],
        value_element_ids=[el.id for el in value_elements],
        label_bbox=_union_bbox([el.bbox for el in label_elements]),
        value_bbox=_union_bbox([el.bbox for el in value_elements]),
        full_bbox=_union_bbox(boxes),
        sensitivity=sorted({el.entity_type for el in value_elements if el.entity_type}),
        confidence=min([*(el.confidence for el in label_elements), *(el.confidence for el in value_elements)], default=0.0),
        source_type=source_type,
    )


def _clean_value(text: str) -> str:
    return text.strip().lstrip(":;|").strip()


def _is_label(element: DocumentElement, next_element: DocumentElement | None) -> bool:
    text = element.text.strip()
    core = text.rstrip(":;").strip()
    if not (1 <= len(core) <= 48) or len(core.split()) > 6:
        return False
    if text.endswith(":"):
        return True
    # OCR sometimes returns the colon as its own token or glued to the value.
    if next_element is not None and next_element.text.strip()[:1] in (":", ";") and not text.endswith(";"):
        return not any(ch.isdigit() for ch in core)
    # A span that is exactly a known field name ("Phone Number", "Date of
    # Birth") is a label even without a colon, as on ID cards and forms.
    return " ".join(core.lower().split()) in _concept_phrases()


_CONCEPT_PHRASES: set[str] = set()


def _concept_phrases() -> set[str]:
    if not _CONCEPT_PHRASES:
        from agents.field_matcher import FIELD_CONCEPTS
        _CONCEPT_PHRASES.update(p for _, phrases in FIELD_CONCEPTS.values() for p in phrases)
    return _CONCEPT_PHRASES


def _row_height(row: list[DocumentElement]) -> float:
    return max((el.bbox[3] - el.bbox[1] for el in row), default=10.0) or 10.0


def _detect_tables(rows: list[list[DocumentElement]], document_id: str) -> tuple[list[DocumentField], set[str]]:
    """Recognise header + data-row tables and emit one field per data cell.

    Each cell is labelled by its column header and identified by its row
    heading (first column), so "price of the gadget" can resolve to one cell
    without exposing the rest of the row or column.
    """
    fields: list[DocumentField] = []
    used: set[str] = set()
    index = 0
    while index < len(rows):
        header = rows[index]
        header_tokens = [set(normalize_tokens(el.text)) - FILLER_WORDS for el in header]
        header_words = sum(1 for tokens in header_tokens if tokens & _TABLE_HEADER_WORDS)
        looks_like_header = (
            len(header) >= 2
            and not any(el.entity_type or is_numeric_span(el.text) or el.text.strip().endswith(":") for el in header)
            and (header_words == len(header) or (len(header) >= 3 and header_words * 2 >= len(header)))
        )
        if not looks_like_header:
            index += 1
            continue

        columns = [(el.bbox[0], el.bbox[2]) for el in header]
        data_rows = []
        previous_bottom = max(el.bbox[3] for el in header)
        line_height = _row_height(header)
        for row in rows[index + 1:]:
            if row[0].page != header[0].page:
                break
            if min(el.bbox[1] for el in row) - previous_bottom > 3.0 * line_height:
                break
            if any(el.text.strip().endswith(":") for el in row):
                break
            assignment = {}
            for el in row:
                center = (el.bbox[0] + el.bbox[2]) / 2
                overlaps = [
                    max(0.0, min(el.bbox[2], c1) - max(el.bbox[0], c0)) for c0, c1 in columns
                ]
                best = max(range(len(columns)), key=lambda c: (overlaps[c], -abs(center - sum(columns[c]) / 2)))
                if overlaps[best] <= 0:
                    # Allow left-aligned cells that start under the header.
                    nearest = min(range(len(columns)), key=lambda c: abs(center - sum(columns[c]) / 2))
                    best = nearest
                assignment.setdefault(best, []).append(el)
            if len(row) < 2 or len(assignment) < min(2, len(columns)):
                break
            data_rows.append(assignment)
            previous_bottom = max(el.bbox[3] for el in row)
        if not data_rows or (len(header) < 3 and len(data_rows) < 2):
            index += 1
            continue

        for assignment in data_rows:
            row_heading = assignment.get(0, [])
            row_label = " ".join(el.text.strip() for el in row_heading)
            text_cells = [
                el for column, cells in sorted(assignment.items()) for el in cells
                if not is_numeric_span(el.text) and el not in row_heading
            ]
            for column, cells in sorted(assignment.items()):
                header_el = header[column]
                if column == 0:
                    # The row heading is context for the other cells, but it
                    # is still a value of the first column.
                    cell_field = _make_field(header_el, cells, document_id, "table_cell")
                    cell_field.field_id = f"p{header_el.page}:{cells[0].id}"
                    cell_field.row_label = ""
                else:
                    cell_field = _make_field(header_el, cells, document_id, "table_cell")
                    cell_field.field_id = f"p{header_el.page}:{cells[0].id}"
                    cell_field.row_label = row_label
                    cell_field.row_label_element_ids = [el.id for el in row_heading]
                    # Other descriptive cells ("Ergonomic Mouse") also identify
                    # the row; they are used for matching only.
                    cell_field.row_context = " ".join(
                        el.text.strip() for el in text_cells if el not in cells
                    )
                fields.append(cell_field)
                used.update(el.id for el in cells)
        used.update(el.id for el in header)
        index += 1 + len(data_rows)
    return fields, used


def extract_document_fields(
    elements: list[DocumentElement], document_id: str = ""
) -> list[DocumentField]:
    """Pair labels with value spans: same line, following lines, or table cells."""
    from agents.field_matcher import concept_category, field_concept

    rows = group_rows(elements)
    fields, table_ids = _detect_tables(rows, document_id)
    rows = [[el for el in row if el.id not in table_ids] for row in rows]
    rows = [row for row in rows if row]
    pending_labels: list[tuple[int, DocumentElement]] = []  # colon labels with no value on their line

    for row_index, row in enumerate(rows):
        ordered = sorted(row, key=lambda element: element.bbox[0])
        ordered = [el for el in ordered if el.text.strip()]
        label_indexes = [
            index for index, element in enumerate(ordered)
            if _is_label(element, ordered[index + 1] if index + 1 < len(ordered) else None)
        ]
        if not label_indexes and len(ordered) == 2:
            # A simple two-cell OCR table row has a usable label/value boundary.
            # Avoid guessing for wider rows or prose with multiple spans.
            label_element, value_element = ordered
            label = _clean_label(label_element.text)
            value = _clean_value(value_element.text)
            # A recognised personal value (e.g. a name) is never promoted to an
            # always-visible label unless it is a known field name.
            label_is_value = bool(label_element.entity_type) and not field_concept(label)
            if label and value and len(label.split()) <= 5 and not is_numeric_span(label) and not label_is_value:
                fields.append(_make_field(label_element, [value_element], document_id, "table_row", label=label))
            continue
        for label_position, index in enumerate(label_indexes):
            next_index = label_indexes[label_position + 1] if label_position + 1 < len(label_indexes) else len(ordered)
            label_element = ordered[index]
            value_elements = [
                el for el in ordered[index + 1:next_index]
                if el.text.strip() and el.text.strip() not in _SEPARATOR_ONLY
            ]
            if not value_elements:
                if label_position == len(label_indexes) - 1:
                    pending_labels.append((row_index, label_element))
                continue
            field = _make_field(label_element, value_elements, document_id,
                                "inline_split" if "::label" in label_element.id else "key_value")
            # Multiline value: following unlabeled lines aligned with the value.
            if label_position == len(label_indexes) - 1:
                _extend_multiline(field, value_elements, rows, row_index, elements)
            fields.append(field)

    # Label on its own line with the value directly below (form layout).
    claimed = {fid for f in fields for fid in (*f.label_element_ids, *f.value_element_ids)}
    for row_index, label_element in pending_labels:
        value_elements = []
        previous_bottom = label_element.bbox[3]
        line_height = max(label_element.bbox[3] - label_element.bbox[1], 8.0)
        for row in rows[row_index + 1:row_index + 4]:
            candidates = [
                el for el in row
                if el.id not in claimed and el.page == label_element.page
                and el.bbox[0] >= label_element.bbox[0] - 2 * line_height
                and el.bbox[0] <= label_element.bbox[2] + 4 * line_height
            ]
            if not candidates or any(_is_label(el, None) for el in row):
                break
            if min(el.bbox[1] for el in candidates) - previous_bottom > 1.6 * line_height:
                break
            value_elements.extend(sorted(candidates, key=lambda el: el.bbox[0]))
            previous_bottom = max(el.bbox[3] for el in candidates)
            # Only continue past the first line when it visibly continues.
            if not value_elements[-1].text.rstrip().endswith(","):
                break
        if value_elements:
            field = _make_field(label_element, value_elements, document_id, "multiline")
            field.confidence = min(field.confidence, 0.85)
            fields.append(field)
            claimed.update(el.id for el in value_elements)

    # Field names are not personal data even when a recogniser fires on them
    # (Presidio tags "Email:" as PERSON), and value sensitivity also follows
    # the field type the label names.
    by_id = {el.id: el for el in elements}
    for field in fields:
        field.concept = field_concept(field.label)
        for fid in field.label_element_ids:
            el = by_id.get(fid)
            if el is None or fid in field.value_element_ids:
                continue
            # Clear only clear false positives: known field names, table
            # headers, and one-word colon labels. A multi-word label tagged as
            # personal data stays protected rather than always visible.
            one_word_label = el.text.strip().endswith(":") and len(field.label.split()) == 1
            if field.concept or one_word_label or field.source_type == "table_cell":
                el.entity_type = None
                el.sensitive_spans = []
        category = concept_category(field.concept)
        if category and not field.sensitivity:
            # Values the recogniser misses (an age, a diagnosis, a salary) are
            # still sensitive when the label names a sensitive field type.
            field.sensitivity = [category]
        elif category in _CATEGORY_MATCHES and not set(field.sensitivity) & _CATEGORY_MATCHES[category]:
            # The label names the field type outright ("Phone Number"), so a
            # conflicting recogniser guess (the phone value tagged ID_NUMBER)
            # is replaced. Protection is unchanged; only the category shown is.
            field.sensitivity = [category]
    return fields


# Recogniser categories that agree with a field type named by the label.
_CATEGORY_MATCHES = {
    "PHONE": {"PHONE"},
    "EMAIL": {"EMAIL"},
    "ADDRESS": {"ADDRESS"},
    "DATE_OF_BIRTH": {"DATE", "DATE_OF_BIRTH"},
    "PERSON": {"PERSON"},
}


def _extend_multiline(field: DocumentField, value_elements, rows, row_index, elements) -> None:
    """Append continuation lines that sit under the value and carry no label."""
    if not value_elements[-1].text.rstrip().endswith(","):
        return
    value_x0 = min(el.bbox[0] for el in value_elements)
    previous_bottom = max(el.bbox[3] for el in value_elements)
    line_height = max(_row_height(value_elements), 8.0)
    added = []
    for row in rows[row_index + 1:row_index + 3]:
        if any(_is_label(el, None) for el in row) or row[0].page != field.page:
            break
        candidates = [el for el in row if abs(el.bbox[0] - value_x0) <= 2 * line_height]
        if len(candidates) != len(row) or not candidates:
            break
        if min(el.bbox[1] for el in candidates) - previous_bottom > 1.6 * line_height:
            break
        added.extend(candidates)
        previous_bottom = max(el.bbox[3] for el in candidates)
        if not candidates[-1].text.rstrip().endswith(","):
            break
    if added:
        all_values = [*value_elements, *added]
        field.value = " ".join(_clean_value(el.text) for el in all_values)
        field.value_element_ids = [el.id for el in all_values]
        field.value_bbox = _union_bbox([el.bbox for el in all_values])
        field.full_bbox = _union_bbox([field.label_bbox, field.value_bbox])
        field.sensitivity = sorted({*field.sensitivity, *(el.entity_type for el in added if el.entity_type)})
        field.source_type = "multiline"


def select_requested_field_element_ids(
    fields: list[DocumentField],
    query: str,
    semantic_element_ids: set[str] | None = None,
) -> set[str]:
    """Resolve requested field labels to only their label and value spans."""
    from agents.field_matcher import match_fields

    semantic_element_ids = semantic_element_ids or set()
    match = match_fields(fields, query)
    by_id = {f.field_id: f for f in fields}
    selected: set[str] = set()
    for fid in match.selected_field_ids:
        selected.update(field_element_ids(by_id[fid]))
    if selected:
        return selected

    # No wording match: accept fields whose value spans were selected by an
    # already-validated semantic decision, or whose value the user typed.
    query_tokens = {t for t in normalize_tokens(query) if t not in FILLER_WORDS}
    for field in fields:
        if field.field_id in match.excluded_field_ids:
            continue
        value_tokens = set(normalize_tokens(field.value))
        query_matches_value = bool(query_tokens) and query_tokens.issubset(value_tokens)
        model_selected_value = bool(semantic_element_ids.intersection(field.value_element_ids))
        if model_selected_value or query_matches_value:
            selected.update(field_element_ids(field))
    return selected


def field_element_ids(field: DocumentField) -> set[str]:
    """Every element that must stay visible to disclose this field in context."""
    return {*field.label_element_ids, *field.value_element_ids, *field.row_label_element_ids}


def query_explicitly_matches_value(query: str, value: str) -> bool:
    """Whether the user typed the value itself, independent of its label."""
    query_tokens = {
        token for token in normalize_tokens(query)
        if token not in FILLER_WORDS
    }
    value_tokens = set(normalize_tokens(value))
    return bool(query_tokens) and query_tokens.issubset(value_tokens)
