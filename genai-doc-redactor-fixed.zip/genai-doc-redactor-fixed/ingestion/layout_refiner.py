"""Refine estimated label/value boundaries using the rendered page pixels.

When an OCR engine (or a PDF span) returns ``Name: Rahul Kumar`` as one box,
``split_inline_key_value_spans`` estimates the label/value split from
character counts. Proportional fonts make that estimate drift, so a mask can
clip the label or leave value pixels uncovered. Here each estimated boundary
is snapped to the nearest blank column gap in the image. If no clear gap is
found near the estimate, the conservative estimate is kept.
"""
from __future__ import annotations

import numpy as np
from PIL import Image

from ingestion.document_model import DocumentElement


def _blank_runs(ink: np.ndarray, min_width: int) -> list[tuple[int, int]]:
    runs, start = [], None
    for x, has_ink in enumerate(ink):
        if not has_ink and start is None:
            start = x
        elif has_ink and start is not None:
            if x - start >= min_width:
                runs.append((start, x))
            start = None
    return runs


def snap_split_boundaries(elements: list[DocumentElement], image: Image.Image) -> int:
    """Adjust split label/value boxes in place; returns the number snapped.

    Element coordinates must be in the pixel space of ``image``.
    """
    groups: dict[str, list[DocumentElement]] = {}
    for el in elements:
        if "::label" in el.id or "::value" in el.id:
            groups.setdefault(el.id.split("::", 1)[0], []).append(el)
    if not groups:
        return 0

    gray = np.asarray(image.convert("L"))
    snapped = 0
    for parts in groups.values():
        parts.sort(key=lambda el: el.bbox[0])
        x0 = max(0, int(min(el.bbox[0] for el in parts)))
        x1 = min(gray.shape[1], int(max(el.bbox[2] for el in parts)) + 1)
        y0 = max(0, int(min(el.bbox[1] for el in parts)))
        y1 = min(gray.shape[0], int(max(el.bbox[3] for el in parts)) + 1)
        if x1 - x0 < 4 or y1 - y0 < 4:
            continue
        region = gray[y0:y1, x0:x1]
        background = np.median(region)
        ink = (np.abs(region.astype(int) - int(background)) > 60).any(axis=0)
        height = y1 - y0
        runs = _blank_runs(ink, max(2, int(height * 0.18)))
        if not runs:
            continue
        total_chars = max(sum(len(el.text) for el in parts), 1)
        char_width = (x1 - x0) / total_chars
        for left, right in zip(parts, parts[1:]):
            estimate = left.bbox[2] - x0
            nearby = [run for run in runs if abs((run[0] + run[1]) / 2 - estimate) <= 2.5 * char_width + 4]
            if not nearby:
                continue
            gap = min(nearby, key=lambda run: abs((run[0] + run[1]) / 2 - estimate))
            left.bbox = [left.bbox[0], left.bbox[1], float(x0 + gap[0]), left.bbox[3]]
            right.bbox = [float(x0 + gap[1]), right.bbox[1], right.bbox[2], right.bbox[3]]
            snapped += 1
    return snapped
