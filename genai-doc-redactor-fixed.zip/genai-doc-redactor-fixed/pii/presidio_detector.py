from __future__ import annotations
import logging
import re
from presidio_analyzer import AnalyzerEngine, RecognizerResult
from ingestion.document_model import DocumentElement
from utils.logging_utils import get_logger

logger = get_logger("pii_detector")

# Presidio and spaCy log the analysed text at DEBUG level; never let document
# content reach the logs, whatever the application log level is.
for _name in ("presidio-analyzer", "presidio-anonymizer", "spacy"):
    logging.getLogger(_name).setLevel(logging.WARNING)

_analyzer: AnalyzerEngine | None = None

ENTITY_MAP = {
    "PERSON": "PERSON",
    "EMAIL_ADDRESS": "EMAIL",
    "PHONE_NUMBER": "PHONE",
    "LOCATION": "ADDRESS",
    "DATE_TIME": "DATE",
    "CREDIT_CARD": "CREDIT_CARD",
    "IBAN_CODE": "BANK_ACCOUNT",
    "US_BANK_NUMBER": "BANK_ACCOUNT",
    "US_SSN": "ID_NUMBER",
    "US_PASSPORT": "PASSPORT",
    "US_DRIVER_LICENSE": "DRIVER_LICENSE",
    "UK_NHS": "ID_NUMBER",
    "IP_ADDRESS": "IP_ADDRESS",
    "NRP": "ORGANIZATION",
    "MEDICAL_LICENSE": "MEDICAL_INFORMATION",
}

SUPPORTED_ENTITIES = [
    "PERSON", "EMAIL_ADDRESS", "PHONE_NUMBER", "LOCATION",
    "DATE_TIME", "CREDIT_CARD", "IBAN_CODE", "US_BANK_NUMBER",
    "US_SSN", "US_PASSPORT", "US_DRIVER_LICENSE", "UK_NHS",
    "IP_ADDRESS", "NRP", "MEDICAL_LICENSE",
]


def _get_analyzer() -> AnalyzerEngine:
    global _analyzer
    if _analyzer is None:
        _analyzer = AnalyzerEngine()
    return _analyzer


# Only digits, in two or more space-separated groups ("4827 1936 5041").
_DIGIT_GROUPS = re.compile(r"\d+(?:\s+\d+)+")


def _corrected(text: str, result: RecognizerResult) -> RecognizerResult:
    """Fix a common recogniser mistake without weakening protection.

    spaCy tags long digit groups such as "4827 1936 5041" as DATE_TIME (it
    reads "1936" as a year). A value made only of digit groups, with no month,
    weekday or date punctuation, is an identifier number: it is reclassified
    (and stays protected), not dropped.
    """
    if result.entity_type != "DATE_TIME":
        return result
    value = text.strip()
    if _DIGIT_GROUPS.fullmatch(value) and sum(ch.isdigit() for ch in value) >= 8:
        return RecognizerResult("US_SSN", result.start, result.end, result.score)  # maps to ID_NUMBER
    return result


def detect_pii_in_elements(elements: list[DocumentElement]) -> list[DocumentElement]:
    """Annotate document elements with detected PII entity types."""
    analyzer = _get_analyzer()
    annotated = 0

    for element in elements:
        if not element.text.strip():
            continue
        results: list[RecognizerResult] = analyzer.analyze(
            text=element.text,
            entities=SUPPORTED_ENTITIES,
            language="en",
        )
        results = [_corrected(element.text, r) for r in results]
        if results:
            best = max(results, key=lambda r: r.score)
            mapped = ENTITY_MAP.get(best.entity_type, best.entity_type)
            element.entity_type = mapped
            element.sensitive_spans = sorted({
                (max(0, int(result.start)), min(len(element.text), int(result.end)))
                for result in results
                if result.end > result.start
            })
            annotated += 1

    logger.info("PII detection: annotated %d of %d elements", annotated, len(elements))
    return elements
