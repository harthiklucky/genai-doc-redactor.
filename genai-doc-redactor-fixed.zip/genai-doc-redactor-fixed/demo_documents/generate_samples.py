"""Generate synthetic demo documents for testing and demonstration."""
from __future__ import annotations
import sys
from pathlib import Path

# Allow running from project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

OUTPUT_DIR = Path(__file__).parent


def create_medical_report():
    path = OUTPUT_DIR / "medical_report.pdf"
    doc = SimpleDocTemplate(str(path), pagesize=letter,
                            topMargin=0.75*inch, bottomMargin=0.75*inch)
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle("Title2", parent=styles["Title"], fontSize=18, spaceAfter=20)
    heading_style = ParagraphStyle("Heading", parent=styles["Heading2"], fontSize=13, spaceAfter=8)
    normal = styles["Normal"]

    elements = []
    elements.append(Paragraph("MEDICAL REPORT", title_style))
    elements.append(Paragraph("City General Hospital", normal))
    elements.append(Paragraph("123 Healthcare Ave, Medical City, MC 45678", normal))
    elements.append(Paragraph("Phone: (555) 234-5678", normal))
    elements.append(Spacer(1, 20))

    elements.append(Paragraph("Patient Information", heading_style))
    patient_data = [
        ["Patient Name:", "John Michael Doe"],
        ["Date of Birth:", "March 15, 1985"],
        ["Patient ID:", "PT-2024-88421"],
        ["Phone:", "(555) 987-6543"],
        ["Email:", "john.doe@email.com"],
        ["Address:", "456 Oak Street, Apt 12B, Springfield, IL 62704"],
        ["Insurance ID:", "INS-HB-992341"],
    ]
    t = Table(patient_data, colWidths=[2*inch, 4*inch])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (1, 0), (1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    elements.append(t)
    elements.append(Spacer(1, 20))

    elements.append(Paragraph("Clinical Information", heading_style))
    elements.append(Paragraph("<b>Attending Physician:</b> Dr. Sarah Williams, MD", normal))
    elements.append(Paragraph("<b>Date of Visit:</b> January 15, 2024", normal))
    elements.append(Paragraph("<b>Department:</b> Internal Medicine", normal))
    elements.append(Spacer(1, 10))

    elements.append(Paragraph("<b>Diagnosis:</b> Type 2 Diabetes Mellitus (E11.9)", normal))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph("<b>Presenting Symptoms:</b> Increased thirst, frequent urination, fatigue, blurred vision for the past 3 weeks.", normal))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph("<b>Lab Results:</b> Fasting blood glucose: 186 mg/dL (High), HbA1c: 8.2% (High), Cholesterol: 220 mg/dL", normal))
    elements.append(Spacer(1, 10))

    elements.append(Paragraph("Prescribed Medication", heading_style))
    med_data = [
        ["Medication", "Dosage", "Frequency"],
        ["Metformin", "500mg", "Twice daily with meals"],
        ["Lisinopril", "10mg", "Once daily"],
        ["Atorvastatin", "20mg", "Once daily at bedtime"],
    ]
    t2 = Table(med_data, colWidths=[2*inch, 1.5*inch, 2.5*inch])
    t2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4472C4")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(t2)
    elements.append(Spacer(1, 15))

    elements.append(Paragraph("<b>Follow-up:</b> Return in 3 months for blood glucose monitoring.", normal))
    elements.append(Spacer(1, 20))
    elements.append(Paragraph("Dr. Sarah Williams, MD", normal))
    elements.append(Paragraph("Internal Medicine Department", normal))

    doc.build(elements)
    print(f"Created: {path}")


def create_invoice():
    path = OUTPUT_DIR / "invoice.pdf"
    doc = SimpleDocTemplate(str(path), pagesize=letter,
                            topMargin=0.75*inch, bottomMargin=0.75*inch)
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle("InvTitle", parent=styles["Title"], fontSize=20, spaceAfter=6)
    heading_style = ParagraphStyle("InvH", parent=styles["Heading2"], fontSize=12, spaceAfter=8)
    normal = styles["Normal"]

    elements = []
    elements.append(Paragraph("INVOICE", title_style))
    elements.append(Paragraph("TechSupply Corp.", normal))
    elements.append(Paragraph("789 Commerce Blvd, Suite 200, Business City, TX 75001", normal))
    elements.append(Spacer(1, 20))

    info_data = [
        ["Invoice Number:", "INV-2024-07823"],
        ["Invoice Date:", "February 20, 2024"],
        ["Due Date:", "March 20, 2024"],
        ["Payment Terms:", "Net 30"],
    ]
    t = Table(info_data, colWidths=[2*inch, 3*inch])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(t)
    elements.append(Spacer(1, 15))

    elements.append(Paragraph("Bill To:", heading_style))
    elements.append(Paragraph("<b>Jane Smith</b>", normal))
    elements.append(Paragraph("Smith Enterprises LLC", normal))
    elements.append(Paragraph("321 Customer Lane, Suite 5", normal))
    elements.append(Paragraph("Buyerville, CA 90210", normal))
    elements.append(Paragraph("Email: jane.smith@smithenterprises.com", normal))
    elements.append(Paragraph("Phone: (555) 321-9876", normal))
    elements.append(Spacer(1, 15))

    elements.append(Paragraph("Order Details", heading_style))
    items_data = [
        ["Item", "Description", "Qty", "Unit Price", "Total"],
        ["LAP-PRO-15", "Laptop Pro 15-inch", "2", "$1,299.00", "$2,598.00"],
        ["MON-UW-34", "UltraWide Monitor 34\"", "2", "$549.00", "$1,098.00"],
        ["KB-MECH-01", "Mechanical Keyboard", "4", "$89.00", "$356.00"],
        ["MS-ERG-02", "Ergonomic Mouse", "4", "$45.00", "$180.00"],
        ["DOCK-USB-C", "USB-C Docking Station", "2", "$199.00", "$398.00"],
    ]
    t2 = Table(items_data, colWidths=[1.2*inch, 2*inch, 0.6*inch, 1.2*inch, 1.2*inch])
    t2.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2E75B6")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(t2)
    elements.append(Spacer(1, 10))

    totals = [
        ["", "", "", "Subtotal:", "$4,630.00"],
        ["", "", "", "Tax (8.25%):", "$381.98"],
        ["", "", "", "Shipping:", "$75.00"],
        ["", "", "", "Total Due:", "$5,086.98"],
    ]
    t3 = Table(totals, colWidths=[1.2*inch, 2*inch, 0.6*inch, 1.2*inch, 1.2*inch])
    t3.setStyle(TableStyle([
        ("FONTNAME", (3, -1), (4, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("ALIGN", (3, 0), (-1, -1), "RIGHT"),
        ("LINEABOVE", (3, -1), (-1, -1), 1, colors.black),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(t3)
    elements.append(Spacer(1, 20))

    elements.append(Paragraph("<b>Payment Method:</b> Credit Card ending in 4532", normal))
    elements.append(Paragraph("<b>Bank Account:</b> Chase Business - Acct #****7891", normal))

    doc.build(elements)
    print(f"Created: {path}")


def create_employee_record():
    path = OUTPUT_DIR / "employee_record.pdf"
    doc = SimpleDocTemplate(str(path), pagesize=letter,
                            topMargin=0.75*inch, bottomMargin=0.75*inch)
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle("EmpTitle", parent=styles["Title"], fontSize=18, spaceAfter=20)
    heading_style = ParagraphStyle("EmpH", parent=styles["Heading2"], fontSize=12, spaceAfter=8)
    normal = styles["Normal"]

    elements = []
    elements.append(Paragraph("EMPLOYEE RECORD", title_style))
    elements.append(Paragraph("Acme Corporation - Human Resources", normal))
    elements.append(Spacer(1, 20))

    elements.append(Paragraph("Personal Information", heading_style))
    personal_data = [
        ["Employee Name:", "Robert James Anderson"],
        ["Employee ID:", "EMP-2019-04521"],
        ["SSN:", "***-**-4589"],
        ["Date of Birth:", "July 22, 1990"],
        ["Address:", "789 Maple Drive, Oakville, OH 43050"],
        ["Phone:", "(555) 456-7890"],
        ["Email:", "r.anderson@acmecorp.com"],
        ["Emergency Contact:", "Lisa Anderson - (555) 456-7891"],
    ]
    t = Table(personal_data, colWidths=[2*inch, 4*inch])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(t)
    elements.append(Spacer(1, 15))

    elements.append(Paragraph("Employment Details", heading_style))
    emp_data = [
        ["Department:", "Engineering"],
        ["Position:", "Senior Software Engineer"],
        ["Hire Date:", "March 1, 2019"],
        ["Employment Type:", "Full-time"],
        ["Manager:", "David Chen"],
        ["Office Location:", "Building A, Floor 3"],
    ]
    t2 = Table(emp_data, colWidths=[2*inch, 4*inch])
    t2.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(t2)
    elements.append(Spacer(1, 15))

    elements.append(Paragraph("Compensation", heading_style))
    comp_data = [
        ["Base Salary:", "$125,000.00 per year"],
        ["Bonus Target:", "15% of base salary"],
        ["Last Review:", "January 2024 - Exceeds Expectations"],
        ["Stock Options:", "500 shares vesting over 4 years"],
    ]
    t3 = Table(comp_data, colWidths=[2*inch, 4*inch])
    t3.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(t3)
    elements.append(Spacer(1, 15))

    elements.append(Paragraph("Benefits", heading_style))
    elements.append(Paragraph("Health Insurance: Blue Cross Blue Shield - Plan: Family Premium", normal))
    elements.append(Paragraph("401(k): Contributing 8% with 4% employer match", normal))
    elements.append(Paragraph("PTO Balance: 18 days remaining", normal))
    elements.append(Spacer(1, 15))

    elements.append(Paragraph("Bank Details (Direct Deposit)", heading_style))
    elements.append(Paragraph("Bank: First National Bank", normal))
    elements.append(Paragraph("Routing: ****4521", normal))
    elements.append(Paragraph("Account: ****8834", normal))

    doc.build(elements)
    print(f"Created: {path}")


if __name__ == "__main__":
    create_medical_report()
    create_invoice()
    create_employee_record()
    print("\nAll demo documents created successfully!")
