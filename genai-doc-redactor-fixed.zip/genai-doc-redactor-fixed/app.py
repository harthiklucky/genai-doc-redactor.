"""Privacy-Preserving Document Agent — Streamlit UI."""
import sys
import hashlib
from html import escape
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import streamlit as st
from PIL import Image
import io
import json
import re
import uuid

from config import LOCAL_ONLY, OLLAMA_MODEL, OLLAMA_BASE_URL, RETENTION_MINUTES, UPLOAD_DIR
from utils import network_guard

# Local-only mode goes on before any other module can open a connection.
if LOCAL_ONLY:
    network_guard.activate_local_only()

from utils.file_utils import validate_file, save_upload, cleanup_temp, get_temp_path
from utils.retention import delete_files, purge_expired
from agents.llm_client import LLMClient
from agents.field_matcher import display_label
from pipeline import process_document, PipelineResult
from batch import MAX_BATCH_FILES, process_batch
from redaction.watermark import trace_file
from utils.ui_state import clear_result, request_signature, result_is_current, store_result

UPLOAD_TYPES = ["pdf", "docx", "png", "jpg", "jpeg"]


@st.cache_data(ttl=60, show_spinner=False)
def _purge_tick() -> int:
    """Delete expired uploads/outputs, at most once a minute."""
    return purge_expired()


def _track(path) -> None:
    """Remember files this browser session created, for "Delete my files now"."""
    if path:
        st.session_state.setdefault("my_files", []).append(str(path))


def _take_file(path) -> bytes | None:
    """Read a generated file into memory and delete it from disk."""
    if not path or not Path(path).exists():
        return None
    data = Path(path).read_bytes()
    if not delete_files([path]):
        _track(path)  # could not delete now; retention or "Delete my files" will
    return data


def _request_run(reviewed_ids=None, reviewed_visuals=None) -> None:
    st.session_state["reviewed_ids"] = reviewed_ids
    st.session_state["reviewed_visuals"] = reviewed_visuals
    st.session_state["run_requested"] = True


def _apply_review(nonce: str, field_ids: list[str], visual_ids: list[str] = ()) -> None:
    _request_run(
        {fid for fid in field_ids if st.session_state.get(f"review_{nonce}_{fid}")},
        {vid for vid in visual_ids if st.session_state.get(f"review_{nonce}_{vid}")},
    )


RISK_ICONS = {"High": "🔴", "Medium": "🟠", "Low": "🟢", "None": "⚪"}


def _delete_my_files() -> None:
    files = list(st.session_state.pop("my_files", []))
    files.append(st.session_state.pop("saved_upload_path", None))
    delete_files(files)
    for key in ("upload_digest", "ingest_cache", "reviewed_ids", "reviewed_visuals", "batch_result"):
        st.session_state.pop(key, None)
    clear_result(st.session_state)
    st.session_state["uploader_nonce"] = st.session_state.get("uploader_nonce", 0) + 1
    st.session_state["files_deleted"] = True


def _render_docx_preview(path: Path) -> list:
    from ingestion.docx_processor import docx_to_pdf
    from ingestion.pdf_processor import render_pdf_pages
    temp_pdf = get_temp_path(".pdf")
    try:
        docx_to_pdf(path, temp_pdf)
        return render_pdf_pages(temp_pdf, dpi=150)
    finally:
        temp_pdf.unlink(missing_ok=True)


@st.cache_data(ttl=30, show_spinner=False)
def _ollama_status(model_name: str):
    """Cache a short local Ollama health check across Streamlit reruns."""
    try:
        ok, message = LLMClient(provider="ollama", model=model_name).check_connection()
        if ok:
            available = message.partition(": ")[2].split(", ")
            if model_name not in available:
                return False, f"Ollama is running, but {model_name} is not installed locally."
        return ok, message
    except Exception:
        return False, "Ollama is unavailable. Start the local Ollama server to use AI analysis."

# ──────────────────── Page config ────────────────────
st.set_page_config(
    page_title="Context-Aware Privacy Agent",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────── Custom CSS ────────────────────
st.markdown("""
<style>
    .main-header {
        text-align: center;
        padding: 1rem 0 0.5rem 0;
    }
    .main-header h1 {
        font-size: 2rem;
        font-weight: 700;
    }
    .main-header p {
        color: #666;
        font-size: 1.05rem;
    }
    .stMetric > div {
        background: #f8f9fa;
        border-radius: 8px;
        padding: 0.75rem;
    }
    .redact-badge {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.85em;
        font-weight: 600;
        margin: 2px 4px;
    }
    .badge-redacted { background: #fecaca; color: #991b1b; }
    .badge-visible  { background: #bbf7d0; color: #166534; }
    .step-box {
        background: #f0f4ff;
        border-left: 4px solid #4472C4;
        padding: 0.75rem 1rem;
        border-radius: 0 6px 6px 0;
        margin-bottom: 0.5rem;
        color: #1f2937;
    }
</style>
""", unsafe_allow_html=True)

# ──────────────────── Header ────────────────────
st.markdown("""
<div class="main-header">
    <h1>🛡️ Context-Aware Privacy-Securing Agent</h1>
    <p>Upload a document, ask a question, and the AI will reveal only what you need — everything else stays protected.</p>
</div>
""", unsafe_allow_html=True)

_purge_tick()
uploader_nonce = st.session_state.get("uploader_nonce", 0)

# ──────────────────── Sidebar ────────────────────
with st.sidebar:
    st.header("⚙️ Settings")

    work_mode = st.radio(
        "Mode", ["Single document", "Batch (many files)", "Trace a copy"], horizontal=True,
        help="Batch applies one question to many files and returns one ZIP. "
             "Trace a copy finds out who a leaked protected copy was made for.",
    )
    batch_mode = work_mode.startswith("Batch")
    trace_mode = work_mode.startswith("Trace")

    st.subheader("1. Upload Document")
    if batch_mode or trace_mode:
        uploaded_file = None
        st.caption("Upload in the main panel.")
    else:
        uploaded_file = st.file_uploader(
            "Drag & drop or browse",
            type=UPLOAD_TYPES,
            help="Supported: PDF (including scanned), Word (DOCX), PNG, JPG/JPEG",
            key=f"uploader_{uploader_nonce}",
        )

    st.divider()
    st.subheader("2. Privacy mode")
    privacy_mode = st.selectbox(
        "Privacy mode", ["Strict", "Maximum", "Standard"], index=0,
        help="Strict keeps only requested fields. Maximum also hides non-matching spans when text boundaries are uncertain. Standard can retain non-sensitive sibling fields from a matching row for context.",
    )
    st.caption(
        "Strict: only requested fields are disclosed; other labels stay readable. "
        "Maximum: other labels are hidden too, and sensitive values are never disclosed on model judgement alone. "
        "Standard: also shows non-sensitive values on the requested row, and allows requests for all fields."
    )
    style_label = st.selectbox(
        "Redaction style", ["Solid Mask", "Blur", "Replacement Text"], index=0,
        help="Blur is rendered from synthetic noise, not from the original pixels, so it cannot be reversed.",
    )
    redaction_mode = {"Solid Mask": "blackout", "Blur": "blur", "Replacement Text": "replacement"}[style_label]

    st.divider()
    st.subheader("3. LLM Provider")
    provider = "ollama"
    model = st.text_input("Ollama model", value=OLLAMA_MODEL)
    llm_mode_label = st.selectbox(
        "AI analysis",
        ["Auto (use the model when needed)", "Always use the model", "Off (deterministic only)"],
        index=0,
        help="Auto answers clearly named fields deterministically and asks the local model only for "
             "requests that do not name a field directly. Each model call can take about a minute on CPU.",
    )
    llm_mode = {"Auto": "Auto", "Always": "Always", "Off": "Off"}[llm_mode_label.split()[0]]
    st.caption(f"Local server: {OLLAMA_BASE_URL}. Document content stays on this machine's Ollama server.")

    connected, status_message = _ollama_status(model)
    if connected:
        st.success(f"● Ollama connected · {model}")
    else:
        st.warning(f"○ Ollama unavailable · {model}")
        st.caption(status_message)

    # Connection check
    if st.button("🔌 Test Connection"):
        client = LLMClient(provider=provider, model=model)
        ok, msg = client.check_connection()
        if ok:
            st.success(msg)
        else:
            st.error(msg)

    st.divider()
    st.subheader("4. Privacy & local processing")
    if network_guard.is_enabled():
        st.success("🔒 Local-only mode is on")
        st.caption(
            "Text recognition, PII detection, the AI model and file generation all run on this "
            "computer. Connections to anything outside this machine are blocked "
            f"({network_guard.blocked_count()} blocked so far)."
        )
    else:
        st.warning("Local-only mode is off (LOCAL_ONLY=false in .env).")
    verify_output = st.checkbox(
        "Verify output with OCR before release", value=True,
        help="Reads the protected pages back with local OCR and withholds the file if any protected "
             "value is still readable. Adds roughly 10-30 s per page on CPU. A check of the file's "
             "embedded text always runs.",
    )
    st.caption(
        "Protected files are held in this browser session's memory and removed from disk as soon "
        "as they are made. "
        + (f"Uploaded originals are deleted after {RETENTION_MINUTES} minutes."
           if RETENTION_MINUTES > 0 else "Automatic deletion of uploads is off (RETENTION_MINUTES=0).")
    )
    st.markdown("**Traceable copy** (optional)")
    recipient = st.text_input(
        "Who is this copy for?", placeholder="e.g. Acme Bank KYC desk", max_chars=120,
        help="Adds an invisible mark to every protected page. If the copy leaks, 'Trace a copy' tells you "
             "who it was made for. The name is stored only on this computer.",
    ).strip()
    st.button("🗑️ Delete my files now", on_click=_delete_my_files,
              help="Deletes this session's uploaded originals and generated outputs from this computer.")
    if st.session_state.pop("files_deleted", False):
        st.success("Your uploaded and generated files were deleted.")

    st.divider()
    st.subheader("ℹ️ How It Works")
    st.markdown("""
<div class="step-box"><b>Step 1</b> — Upload a PDF, Word file or image</div>
<div class="step-box"><b>Step 2</b> — Ask what you need from it</div>
<div class="step-box"><b>Step 3</b> — AI decides what's safe to show</div>
<div class="step-box"><b>Step 4</b> — Download the protected version</div>
""", unsafe_allow_html=True)

# ──────────────────── Main area ────────────────────

if trace_mode:
    st.subheader("🔎 Trace a copy")
    st.caption(
        "Upload a protected file made by this app with a recipient name. The invisible mark is read on this "
        "computer and looked up in its local ledger. Works on the PDF, DOCX, PNG, JPG or ZIP as it was "
        "produced; photos of a screen, printouts and resized copies are not supported."
    )
    suspect = st.file_uploader("Protected file", type=["pdf", "docx", "png", "jpg", "jpeg", "zip"],
                               key=f"trace_uploader_{uploader_nonce}")
    if suspect is not None:
        temp = get_temp_path(Path(suspect.name).suffix.lower() or ".bin")
        temp.write_bytes(suspect.getvalue())
        try:
            with st.spinner("Reading the trace mark..."):
                found = trace_file(temp)
        finally:
            temp.unlink(missing_ok=True)
        if found.get("found"):
            st.success(f"This copy was made for **{escape(found['recipient'])}**.")
            st.markdown(
                f"- Created: {found['created']}\n- Document type: {found['document_type']}\n"
                f"- Format: {found['output_format']} · {found['pages']} page(s)\n- Trace ID: `{found['trace_id']}`"
            )
        else:
            st.warning(found.get("reason", "No trace mark found."))
    st.stop()

if batch_mode:
    st.subheader("📚 Batch processing")
    st.caption(
        f"Ask one question of up to {MAX_BATCH_FILES} documents. Each file is processed on this computer "
        "with the settings in the sidebar, and you get one ZIP with the protected files, a privacy "
        "audit per file, and answers.csv."
    )
    batch_files = st.file_uploader(
        "Documents", type=UPLOAD_TYPES, accept_multiple_files=True,
        key=f"batch_uploader_{uploader_nonce}",
    )
    batch_query = st.text_area(
        "Question for every document", placeholder="e.g., What is the invoice total and invoice date?",
        max_chars=1000, height=80,
    )
    batch_format = st.selectbox("Output format", ["PDF", "DOCX", "PNG", "JPG"], key="batch_format")
    if st.button("🔍 Protect all files", type="primary", disabled=not batch_files):
        st.session_state.pop("batch_result", None)
        if not batch_query.strip():
            st.warning("Please enter a question for the documents.")
            st.stop()
        saved, problems = [], []
        for item in batch_files[:MAX_BATCH_FILES]:
            ok, message = validate_file(item.name, item.size)
            if ok:
                path = save_upload(item.name, item.getvalue())
                _track(path)
                saved.append((item.name, path))
            else:
                problems.append(f"{item.name}: {message}")
        if len(batch_files) > MAX_BATCH_FILES:
            problems.append(f"Only the first {MAX_BATCH_FILES} files were processed.")
        bar = st.progress(0.0, text="Starting...")

        def _progress(done, total, name):
            bar.progress(done / total, text=f"Processing {done + 1} of {total}: {name}" if name else "Done")

        try:
            batch = process_batch(
                saved, batch_query, progress=_progress,
                privacy_mode=privacy_mode, redaction_mode=redaction_mode, output_format=batch_format,
                llm_provider=provider, llm_model=model, llm_mode=llm_mode, verify_output=verify_output,
                recipient=recipient or None,
            )
        finally:
            # The originals are not needed once their protected copies exist.
            delete_files(path for _, path in saved)
        zip_bytes = _take_file(batch.zip_path)
        st.session_state["batch_result"] = (batch, problems, zip_bytes)

    if "batch_result" in st.session_state:
        batch, problems, zip_bytes = st.session_state["batch_result"]
        for problem in problems:
            st.warning(problem)
        if batch.rows:
            done = sum(r.status == "protected" for r in batch.rows)
            st.success(f"{done} of {len(batch.rows)} file(s) protected.")
            st.dataframe(
                [{"File": r.file_name, "Status": r.status, "Answer": r.answer or r.message,
                  "Disclosed fields": r.disclosed_fields, "Pages": r.pages, "Seconds": r.seconds}
                 for r in batch.rows],
                width="stretch", hide_index=True,
            )
        if zip_bytes:
            st.download_button(
                "⬇️ Download protected files (ZIP)", data=zip_bytes,
                file_name="protected_documents.zip", mime="application/zip", width="stretch",
            )
    st.stop()

if uploaded_file is not None:
    # Validate
    valid, err_msg = validate_file(uploaded_file.name, uploaded_file.size)
    if not valid:
        st.error(err_msg)
        st.stop()

    # Save each upload only once per session. Streamlit reruns this script for
    # most UI interactions, and saving on every rerun would duplicate private files.
    file_bytes = uploaded_file.getvalue()
    upload_digest = hashlib.sha256(
        (Path(uploaded_file.name).suffix.lower() + "\0").encode("utf-8") + file_bytes
    ).hexdigest()
    if st.session_state.get("upload_digest") != upload_digest:
        previous_path = st.session_state.get("saved_upload_path")
        if previous_path:
            previous = Path(previous_path)
            if previous.parent.resolve() == UPLOAD_DIR.resolve():
                previous.unlink(missing_ok=True)
        clear_result(st.session_state)
        st.session_state.pop("ingest_cache", None)
        st.session_state["reviewed_ids"] = None
        st.session_state["upload_digest"] = upload_digest
        st.session_state["saved_upload_path"] = str(save_upload(uploaded_file.name, file_bytes))
    saved_path = Path(st.session_state["saved_upload_path"])
    if not saved_path.exists():
        # Removed by the retention purge while the page stayed open.
        saved_path = save_upload(uploaded_file.name, file_bytes)
        st.session_state["saved_upload_path"] = str(saved_path)

    # Show original preview
    st.subheader("📄 Original Document Preview")
    ext = Path(uploaded_file.name).suffix.lower()
    if ext in (".png", ".jpg", ".jpeg"):
        preview_img = Image.open(io.BytesIO(file_bytes))
        st.image(preview_img, caption="Original Image", width="stretch")
    elif ext in (".pdf", ".docx"):
        from ingestion.pdf_processor import render_pdf_pages
        try:
            if ext == ".docx":
                st.caption("Word documents are shown in a simplified layout of their text and tables.")
                preview_pages = _render_docx_preview(saved_path)
            else:
                preview_pages = render_pdf_pages(saved_path, dpi=150)
            if len(preview_pages) == 1:
                st.image(preview_pages[0], caption="Original — Page 1", width="stretch")
            else:
                tabs = st.tabs([f"Page {i+1}" for i in range(min(len(preview_pages), 10))])
                for i, tab in enumerate(tabs):
                    with tab:
                        st.image(preview_pages[i], caption=f"Page {i+1}", width="stretch")
        except Exception:
            st.info("PDF preview unavailable. Processing will still work.")

    st.divider()

    # Query input
    st.subheader("💬 What do you need from this document?")
    user_query = st.text_area(
        "Enter your question",
        placeholder="e.g., Show me the patient's diagnosis and medication.",
        help="Recognized fields are shown at value level. For unstructured text or tables where OCR cannot find a safe cell boundary, the relevant line or row may be kept as context.",
        height=80,
        max_chars=1000,
        label_visibility="collapsed",
    )
    output_format = st.selectbox(
        "Output format",
        ["PDF", "DOCX", "PNG", "JPG"],
        help="Multi-page PNG/JPG results are packaged as a ZIP with one protected image per page.",
    )

    col_btn, col_space = st.columns([1, 3])
    with col_btn:
        st.button("🔍 Analyze & Protect", type="primary", width="stretch",
                  on_click=_request_run)

    reviewed_ids = st.session_state.get("reviewed_ids")
    reviewed_visuals = st.session_state.get("reviewed_visuals")
    signature = request_signature(
        upload_digest, user_query, privacy_mode, redaction_mode, output_format, model, llm_mode,
        reviewed_field_ids=reviewed_ids, verify_output=verify_output,
        reviewed_visual_ids=reviewed_visuals, recipient=recipient,
    )

    if st.session_state.pop("run_requested", False):
        clear_result(st.session_state)
        if not user_query.strip():
            st.warning("Please enter a question about the document.")
            st.stop()

        # Run pipeline
        with st.status("Processing document...", expanded=True) as status:
            if reviewed_ids is not None:
                st.write("✏️ Applying your reviewed selection...")
            else:
                st.write("📥 Extracting text, layout and fields...")
                st.write("🕵️ Detecting sensitive information...")
                if llm_mode != "Off":
                    st.write("🤖 Interpreting your request (the local model is used if needed)...")
            if verify_output:
                st.write("🔎 Verifying the protected file with OCR...")

            result: PipelineResult = process_document(
                file_path=saved_path,
                user_query=user_query,
                redaction_mode=redaction_mode,
                llm_provider=provider,
                llm_model=model,
                output_format=output_format,
                privacy_mode=privacy_mode,
                llm_mode=llm_mode,
                disclose_field_ids=reviewed_ids,
                disclose_visual_ids=reviewed_visuals,
                recipient=recipient or None,
                verify_output=verify_output,
                ingest_cache=st.session_state.setdefault("ingest_cache", {}),
            )
            # Keep the protected file in this session's memory only; nothing
            # generated stays on disk after the run.
            result.output_name = result.output_path.name if result.output_path else ""
            result.output_bytes = _take_file(result.output_path)

            if result.error:
                status.update(label="❌ Error", state="error")
                st.error(result.error)
                st.stop()

            st.write("✅ Redaction complete!")
            status.update(label="✅ Processing complete!", state="complete")

        # Store result in session state for persistence
        store_result(st.session_state, result, signature, user_query)
        st.session_state["result_nonce"] = uuid.uuid4().hex[:8]

    # ──────────────────── Results ────────────────────
    # A result is shown only for the exact document, question and settings
    # that produced it; any change requires a new analysis.
    if "result" in st.session_state and not result_is_current(st.session_state, signature):
        clear_result(st.session_state)
        st.session_state["reviewed_ids"] = None
        st.session_state["reviewed_visuals"] = None
        st.info("The question or settings changed. Click **Analyze & Protect** to update the answer and protected file.")

    if "result" in st.session_state:
        result: PipelineResult = st.session_state["result"]
        query = st.session_state.get("user_query", "")

        st.divider()

        # Metrics row
        summary = result.privacy_summary
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Sensitive found", summary.get("sensitive_detected", 0))
        m2.metric("Disclosed", summary.get("disclosed_sensitive", 0))
        m3.metric("Protected", summary.get("protected_sensitive", 0))
        m4.metric("Pages", summary.get("pages", 0))
        m5.metric("Processing Time", f"{result.processing_time:.1f}s")
        st.caption(
            f"Sensitive-value protection: {summary.get('protection_ratio', 1.0):.0%} · "
            f"Average extraction confidence: {summary.get('mean_extraction_confidence', 0.0):.0%} · "
            f"Mode: {summary.get('privacy_mode', 'Strict')}"
        )

        st.divider()

        # AI Answer
        findings = result.security_findings
        if findings:
            with st.container(border=True):
                st.error(
                    "⚠️ This document looks crafted to manipulate an AI. The suspicious text was ignored and "
                    "never disclosed; the local AI model was not consulted for this document."
                    if any(f["kind"] != "invisible_text" for f in findings) else
                    "⚠️ This document contains text a reader cannot see. It was removed before processing, "
                    "so it could not answer questions or steer the AI."
                )
                for f in findings[:8]:
                    where = f"page {f['page']}" if f["page"] else "inside a QR code / barcode"
                    kind = {"instruction": "Instruction to the AI", "code_instruction": "Instruction in a code",
                            "invisible_text": "Invisible text"}.get(f["kind"], f["kind"])
                    st.markdown(f"- **{kind}** ({where}): {escape(f['reason'])} — "
                                f"<code>{escape(f['excerpt'][:90])}</code>", unsafe_allow_html=True)

        st.subheader("🤖 AI Answer")
        st.caption(f"Document type: {result.document_type}")
        # Document values are shown verbatim: escape Markdown (``$`` would
        # otherwise start LaTeX in amounts) and keep one value per line.
        answer_md = re.sub(r"([\\`*_{}\[\]<>()#+!|~$-])", r"\\\1", result.decision.answer)
        st.info(answer_md.replace("\n", "  \n"))
        if result.derived_answers:
            st.caption("🔐 Answered without revealing the full field: " + "; ".join(
                f"{escape(d.label)} was computed from {escape(d.source_label)}, which stays hidden"
                for d in result.derived_answers
            ) + ".")
        risk = result.risk or {}
        if risk:
            icon = RISK_ICONS.get(risk.get("level", "None"), "⚪")
            with st.expander(f"{icon} Re-identification risk: **{risk['level']}** ({risk['score']}/100)",
                             expanded=risk.get("level") in ("High", "Medium")):
                st.progress(min(max(int(risk.get("score", 0)), 0), 100) / 100)
                for reason in risk.get("reasons", []):
                    st.markdown(f"- {escape(reason)}")
                direct = any(f.get("bits") == "direct identifier" for f in risk.get("factors", []))
                if risk.get("identifying_bits") and not direct:
                    st.caption(f"Estimated identifying information: {risk['identifying_bits']} bits "
                               "(about 28+ bits single out one person in a population of 1.4 billion).")
                for tip in risk.get("suggestions", []):
                    st.markdown(f"💡 {escape(tip)}")
        if result.visual_regions:
            shown = [r for r in result.visual_regions if r.region_id in result.visual_disclosed]
            hidden = [r for r in result.visual_regions if r.region_id not in result.visual_disclosed]
            parts = []
            if hidden:
                parts.append("hidden: " + ", ".join(sorted({r.label.lower() for r in hidden})))
            if shown:
                parts.append("shown: " + ", ".join(sorted({r.label.lower() for r in shown})))
            st.caption("🖼️ Photos, codes and signatures — " + "; ".join(parts)
                       + ". Ask for one by name (e.g. \"show the photo\") to include it.")
        if result.trace:
            st.caption(f"🔏 Traceable copy for **{escape(result.trace['recipient'])}** "
                       f"(trace ID `{result.trace['trace_id']}`).")
        st.caption(f"**Your question:** {query}")
        st.caption(f"**Selected output:** {result.output_format} · **AI analysis:** {result.decision.llm_status}")

        diag = result.query_diagnostics
        if diag.get("requested_segments"):
            with st.expander("How your request was interpreted", expanded=True):
                status_icon = {"matched": "✅", "not_found": "❔", "ambiguous": "⚠️"}
                method_text = {
                    "exact_label": "field label", "alias": "field type synonym",
                    "partial_label": "partial label match", "table_row": "table row",
                    "llm_semantic": "local model (validated)", "text_line": "text line",
                    "all_requested": "all fields (Standard mode)",
                    "manual": "your review",
                    "derived": "computed answer",
                    "visual": "photo / code / signature",
                }
                for seg in diag["requested_segments"]:
                    if seg["status"] == "matched":
                        target = ", ".join(seg["matched_fields"]) or "matching text line"
                        detail = f"→ **{escape(target)}** via {method_text.get(seg['match_method'], seg['match_method'])}"
                    elif seg["status"] == "ambiguous":
                        detail = "→ ambiguous: " + escape(", ".join(seg["candidates"])) + " (nothing disclosed)"
                    else:
                        detail = "→ not found in the document"
                    st.markdown(f"{status_icon.get(seg['status'], '')} “{escape(seg['request'])}” {detail}")
                if diag.get("excluded_fields"):
                    st.markdown("🚫 Excluded on request: " + escape(", ".join(diag["excluded_fields"])))
                for note in diag.get("validation_notes", []):
                    st.caption(note)
                if diag.get("llm_reasoning"):
                    st.caption(f"Model explanation: {diag['llm_reasoning']}")

        if result.fields or result.visual_regions:
            nonce = st.session_state.get("result_nonce", "0")
            with st.expander("✏️ Review and adjust what is disclosed", expanded=False):
                st.caption(
                    "Tick exactly the fields you want visible, then apply. Only field names are listed "
                    "here, never their values. A reviewed selection replaces the automatic one "
                    "(unlabelled text lines are not included)."
                )
                # A form, so ticking boxes does not rerun the page; the
                # selection is applied once, on submit.
                with st.form(key=f"review_form_{nonce}", border=False):
                    names = [display_label(f) for f in result.fields]
                    seen: dict[str, int] = {}
                    for field, name in zip(result.fields, names):
                        if names.count(name) > 1:
                            seen[name] = seen.get(name, 0) + 1
                            name = f"{name} #{seen[name]}"
                        extra = f" · {', '.join(field.sensitivity)}" if field.sensitivity else ""
                        st.checkbox(
                            f"{name} (page {field.page}){extra}",
                            value=field.field_id in result.selected_field_ids,
                            key=f"review_{nonce}_{field.field_id}",
                        )
                    for index, region in enumerate(result.visual_regions, start=1):
                        st.checkbox(
                            f"{region.label} #{index} (page {region.page})",
                            value=region.region_id in result.visual_disclosed,
                            key=f"review_{nonce}_{region.region_id}",
                        )
                    st.form_submit_button(
                        "Apply my selection", on_click=_apply_review,
                        args=(nonce, [f.field_id for f in result.fields],
                              [r.region_id for r in result.visual_regions]),
                    )

        st.divider()

        # Before / After comparison
        st.subheader("📊 Before / After Comparison")

        if result.original_images and result.redacted_images:
            num_pages = min(len(result.original_images), len(result.redacted_images))

            if num_pages == 1:
                col_orig, col_redact = st.columns(2)
                with col_orig:
                    st.markdown("**Original Document**")
                    st.image(result.original_images[0], width="stretch")
                with col_redact:
                    st.markdown("**🛡️ AI-Protected Document**")
                    st.image(result.redacted_images[0], width="stretch")
            else:
                page_tabs = st.tabs([f"Page {i+1}" for i in range(min(num_pages, 10))])
                for i, tab in enumerate(page_tabs):
                    with tab:
                        c1, c2 = st.columns(2)
                        with c1:
                            st.markdown("**Original**")
                            st.image(result.original_images[i], width="stretch")
                        with c2:
                            st.markdown("**🛡️ Protected**")
                            st.image(result.redacted_images[i], width="stretch")

        st.divider()

        # Privacy Summary
        st.subheader("🔒 Privacy Summary")

        col_vis, col_red = st.columns(2)
        with col_vis:
            st.markdown("**✅ Visible (shown to user)**")
            if summary.get("visible_fields"):
                for f in summary["visible_fields"]:
                    st.markdown(
                        f'<span class="redact-badge badge-visible">{escape(str(f["category"]))}</span> '
                        f'{escape(str(f["reason"]))}',
                        unsafe_allow_html=True,
                    )
            else:
                st.caption("No fields marked visible.")

        with col_red:
            st.markdown("**🚫 Sensitive fields**")
            if summary.get("redacted_fields"):
                for f in summary["redacted_fields"][:15]:  # cap display
                    st.markdown(
                        f'<span class="redact-badge badge-redacted">{escape(str(f["category"]))}</span> '
                        f'{escape(str(f["reason"]))}',
                        unsafe_allow_html=True,
                    )
                remaining = len(summary["redacted_fields"]) - 15
                if remaining > 0:
                    st.caption(f"...and {remaining} more fields redacted.")
            else:
                st.caption("No fields redacted.")

        # Categories overview
        if summary.get("categories_hidden"):
            st.markdown("**Categories hidden:** " + ", ".join(
                f'`{c}`' for c in summary["categories_hidden"]
            ))

        st.divider()

        # Explainability
        st.subheader("💡 Redaction Explainability")
        if result.decision and result.decision.decisions:
            with st.expander("View AI decision reasoning", expanded=False):
                visible_decisions = [d for d in result.decision.decisions if d.action.is_keep()]
                redact_decisions = [d for d in result.decision.decisions if d.action.should_redact()]

                if visible_decisions:
                    st.markdown("**Why these were shown:**")
                    shown = {}
                    for d in visible_decisions:
                        if d.category == "FIELD_LABEL":
                            continue
                        field_label = next((f.label for f in result.fields if d.field_id in f.label_element_ids or d.field_id in f.value_element_ids), "Matching text line")
                        shown.setdefault(field_label, d.reason)
                    for field_label, reason in list(shown.items())[:10]:
                        st.markdown(f"- **{escape(field_label)}** — {escape(reason)}.")
                    label_count = sum(1 for d in visible_decisions if d.category == "FIELD_LABEL")
                    if label_count:
                        st.markdown(f"- {label_count} field label(s) kept readable for context (values protected).")

                if redact_decisions:
                    st.markdown("**Why these were hidden or blurred:**")
                    for d in redact_decisions[:10]:
                        # Never display fragments of data classified as sensitive.
                        field_label = next((f.label for f in result.fields if d.field_id in f.value_element_ids), "")
                        prefix = f"{escape(field_label)} " if field_label else ""
                        st.markdown(f"- {prefix}**{d.category}** — {d.reason}")

        with st.expander("Privacy audit", expanded=False):
            st.caption("Audit details contain labels, categories, and actions; they do not include protected values.")
            st.json(result.audit_report)
            st.download_button(
                "Download privacy audit (JSON)",
                data=json.dumps(result.audit_report, ensure_ascii=False, indent=2).encode("utf-8"),
                file_name="privacy_audit.json",
                mime="application/json",
            )

        st.divider()

        # Downloads
        st.subheader("📥 Downloads")
        output_bytes = getattr(result, "output_bytes", None)
        output_name = getattr(result, "output_name", "")
        if output_bytes:
            mime_by_suffix = {
                ".pdf": "application/pdf",
                ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                ".png": "image/png",
                ".jpg": "image/jpeg",
                ".zip": "application/zip",
            }
            st.download_button(
                f"⬇️ Download Protected {result.output_format}"
                + (" pages (ZIP)" if output_name.lower().endswith(".zip") else ""),
                data=output_bytes,
                file_name=output_name,
                mime=mime_by_suffix.get(Path(output_name).suffix.lower(), "application/octet-stream"),
                width="stretch",
            )
            check = result.leak_check or {}
            if check.get("status") == "passed":
                how = "embedded text and OCR read-back" if check.get("ocr_checked") else "embedded text"
                st.caption(
                    f"✅ Output check passed: {check.get('values_checked', 0)} protected value(s) "
                    f"were not found in the file ({how})."
                )
        disclosed_values = {
            display_label(f): f.value for f in result.fields if f.field_id in result.selected_field_ids
        }
        st.download_button(
            "⬇️ Download answer (JSON)",
            data=json.dumps({"answer": result.decision.answer, "fields": disclosed_values},
                            ensure_ascii=False, indent=2).encode("utf-8"),
            file_name="answer.json", mime="application/json", width="stretch",
            help="Only the values disclosed for your question.",
        )

        # Cleanup
        cleanup_temp()

else:
    old_upload = st.session_state.pop("saved_upload_path", None)
    st.session_state.pop("upload_digest", None)
    clear_result(st.session_state)
    if old_upload:
        old_path = Path(old_upload)
        if old_path.parent.resolve() == UPLOAD_DIR.resolve():
            old_path.unlink(missing_ok=True)

    # Landing state
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("### 📄 Upload")
        st.markdown("Drop a PDF, Word document, PNG, or JPG containing sensitive information.")
    with col2:
        st.markdown("### 💬 Ask")
        st.markdown("Tell the AI what information you need from the document.")
    with col3:
        st.markdown("### 🛡️ Protect")
        st.markdown("Get a redacted version with only the relevant info visible.")

    st.markdown("---")
    st.markdown("#### Example Queries")
    examples = [
        ("Medical Report", "Show me the patient's diagnosis and medication."),
        ("Invoice", "What is the invoice total and invoice date?"),
        ("Employee Record", "What is the employee's salary and department?"),
        ("General", "Show me the order details but hide all customer information."),
    ]
    for doc_type, query in examples:
        st.markdown(f"- **{doc_type}:** *\"{query}\"*")
