"""Tests for OCR text extraction (uses a synthetic image)."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from PIL import Image, ImageDraw, ImageFont


def _create_text_image(text: str = "Hello World 12345", size=(400, 100)) -> Image.Image:
    img = Image.new("RGB", size, "white")
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("arial.ttf", 28)
    except (OSError, IOError):
        font = ImageFont.load_default()
    draw.text((20, 30), text, fill="black", font=font)
    return img


def test_easyocr_extracts_text():
    try:
        from ocr.easyocr_engine import EasyOCREngine
    except ImportError:
        pytest.skip("EasyOCR not installed")

    img = _create_text_image("Invoice Total 5000")
    engine = EasyOCREngine()
    elements = engine.extract(img, page_num=1)

    assert len(elements) > 0
    all_text = " ".join(el.text for el in elements).lower()
    assert "invoice" in all_text or "total" in all_text or "5000" in all_text

    for el in elements:
        assert len(el.bbox) == 4
        assert el.bbox[0] < el.bbox[2]
        assert el.bbox[1] < el.bbox[3]
        assert el.page == 1
        assert el.confidence > 0


def test_easyocr_element_ids_are_unique():
    try:
        from ocr.easyocr_engine import EasyOCREngine
    except ImportError:
        pytest.skip("EasyOCR not installed")

    img = _create_text_image("Name: John Doe Email: test@mail.com")
    engine = EasyOCREngine()
    elements = engine.extract(img, page_num=1)
    ids = [el.id for el in elements]
    assert len(ids) == len(set(ids)), "Element IDs must be unique"


def test_ocr_empty_image():
    try:
        from ocr.easyocr_engine import EasyOCREngine
    except ImportError:
        pytest.skip("EasyOCR not installed")

    img = Image.new("RGB", (200, 100), "white")
    engine = EasyOCREngine()
    elements = engine.extract(img, page_num=1)
    assert len(elements) <= 2
