"""Tests for the document model."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ingestion.document_model import DocumentElement, DocumentPage, DocumentRepresentation


def test_document_element_creation():
    el = DocumentElement(id="field_001", text="John Doe", bbox=[10, 20, 100, 40], page=1)
    assert el.id == "field_001"
    assert el.text == "John Doe"
    assert el.bbox == [10, 20, 100, 40]
    assert el.confidence == 1.0


def test_document_element_bbox_tuple():
    el = DocumentElement(id="f1", text="test", bbox=[10.5, 20.5, 100.5, 40.5])
    assert el.bbox_tuple == (10.5, 20.5, 100.5, 40.5)


def test_sensitive_spans_are_removed_from_safe_text():
    el = DocumentElement(
        id="f1",
        text="Name: Jane Doe",
        bbox=[0, 0, 100, 20],
        entity_type="PERSON",
        sensitive_spans=[(6, 14)],
    )
    assert el.text_without_sensitive_spans() == "Name: "


def test_document_page():
    elements = [
        DocumentElement(id="f1", text="Hello", bbox=[0, 0, 50, 20]),
        DocumentElement(id="f2", text="World", bbox=[0, 25, 50, 45]),
    ]
    page = DocumentPage(page=1, width=612, height=792, elements=elements)
    assert page.page == 1
    assert len(page.elements) == 2


def test_document_representation():
    el = DocumentElement(id="f1", text="Test", bbox=[0, 0, 50, 20], page=1)
    page = DocumentPage(page=1, width=100, height=100, elements=[el])
    doc = DocumentRepresentation(
        document_id="doc1", filename="test.pdf", file_type="pdf", pages=[page]
    )
    assert doc.full_text() == "Test"
    assert doc.get_element_by_id("f1") == el
    assert doc.get_element_by_id("nonexistent") is None
    assert len(doc.all_elements()) == 1


def test_empty_document():
    doc = DocumentRepresentation(
        document_id="empty", filename="empty.pdf", file_type="pdf", pages=[]
    )
    assert doc.full_text() == ""
    assert doc.all_elements() == []
