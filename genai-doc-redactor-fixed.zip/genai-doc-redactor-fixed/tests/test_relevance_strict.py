"""Strict query relevance and table understanding tests matching academic specifications."""
from __future__ import annotations
import json
import pytest
from ingestion.document_model import DocumentElement, DocumentPage, DocumentRepresentation
from agents.relevance import (
    find_relevant_field_ids,
    extract_answer_from_keep_fields,
    group_rows,
    score_row_match,
    normalize_token,
    _query_kind,
)
from agents.privacy_agent import _parse_llm_response, analyze_document
from agents.schemas import RedactionAction


@pytest.fixture
def representative_medical_table() -> list[DocumentElement]:
    """Representative medical table matching the project specification:
    kidney                      | 11  | 45.8
    lung                        | 35  | 13.3
    prostate                    | 9   | 37.5
    digestive                   | 123 | 46.6
    brain tumors                | 3   | 1.1
    other hematological tumors  | 14  | 4.3
    rheumatological disorders   | 33  | 2.7
    other tumors                | 7   | 2.7
    """
    return [
        # Row 1: kidney
        DocumentElement(id="row1_label", text="kidney", bbox=[40, 40, 120, 65], page=1),
        DocumentElement(id="row1_count", text="11", bbox=[130, 40, 160, 65], page=1),
        DocumentElement(id="row1_pct", text="45.8", bbox=[170, 40, 230, 65], page=1),

        # Row 2: lung
        DocumentElement(id="row2_label", text="lung", bbox=[40, 75, 120, 100], page=1),
        DocumentElement(id="row2_count", text="35", bbox=[130, 75, 160, 100], page=1),
        DocumentElement(id="row2_pct", text="13.3", bbox=[170, 75, 230, 100], page=1),

        # Row 3: prostate
        DocumentElement(id="row3_label", text="prostate", bbox=[40, 110, 120, 135], page=1),
        DocumentElement(id="row3_count", text="9", bbox=[130, 110, 160, 135], page=1),
        DocumentElement(id="row3_pct", text="37.5", bbox=[170, 110, 230, 135], page=1),

        # Row 4: digestive
        DocumentElement(id="row4_label", text="digestive", bbox=[40, 145, 120, 170], page=1),
        DocumentElement(id="row4_count", text="123", bbox=[130, 145, 160, 170], page=1),
        DocumentElement(id="row4_pct", text="46.6", bbox=[170, 145, 230, 170], page=1),

        # Row 5: brain tumors
        DocumentElement(id="row5_label", text="brain tumors", bbox=[40, 180, 140, 205], page=1),
        DocumentElement(id="row5_count", text="3", bbox=[150, 180, 170, 205], page=1),
        DocumentElement(id="row5_pct", text="1.1", bbox=[180, 180, 230, 205], page=1),

        # Row 6: other hematological tumors
        DocumentElement(id="row6_label", text="other hematological tumors", bbox=[40, 215, 220, 240], page=1),
        DocumentElement(id="row6_count", text="14", bbox=[230, 215, 250, 240], page=1),
        DocumentElement(id="row6_pct", text="4.3", bbox=[260, 215, 300, 240], page=1),

        # Row 7: rheumatological disorders
        DocumentElement(id="row7_label", text="rheumatological disorders", bbox=[40, 250, 210, 275], page=1),
        DocumentElement(id="row7_count", text="33", bbox=[220, 250, 240, 275], page=1),
        DocumentElement(id="row7_pct", text="2.7", bbox=[250, 250, 290, 275], page=1),

        # Row 8: other tumors
        DocumentElement(id="row8_label", text="other tumors", bbox=[40, 285, 140, 310], page=1),
        DocumentElement(id="row8_count", text="7", bbox=[150, 285, 170, 310], page=1),
        DocumentElement(id="row8_pct", text="2.7", bbox=[180, 285, 220, 310], page=1),
    ]


# ─────────────────────────────────────────────────────────────────────────────
# Test 1: "kidney score"
# ─────────────────────────────────────────────────────────────────────────────

def test_kidney_score_discloses_the_whole_matching_line(representative_medical_table):
    query = "kidney score"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)

    # A match shows every cell on the same line, including count and score.
    assert "row1_label" in matched_ids
    assert "row1_count" in matched_ids
    assert "row1_pct" in matched_ids

    # Must NOT disclose unrelated rows
    assert "row2_label" not in matched_ids
    assert "row5_label" not in matched_ids
    assert "row6_label" not in matched_ids
    assert "row8_label" not in matched_ids

    answer = extract_answer_from_keep_fields(query, representative_medical_table, matched_ids)
    assert answer == "45.8%"


def test_single_word_match_discloses_every_field_on_its_line(representative_medical_table):
    matched_ids = find_relevant_field_ids(representative_medical_table, "kidney")
    assert {"row1_label", "row1_count", "row1_pct"}.issubset(matched_ids)
    assert not ({"row2_label", "row2_count", "row2_pct"} & matched_ids)


def test_matching_table_row_also_keeps_nearby_column_headings():
    elements = [
        DocumentElement(id="h1", text="Category", bbox=[40, 40, 110, 60]),
        DocumentElement(id="h2", text="Count", bbox=[150, 40, 195, 60]),
        DocumentElement(id="h3", text="Result", bbox=[250, 40, 300, 60]),
        DocumentElement(id="label", text="BirthCertificate", bbox=[40, 75, 145, 95]),
        DocumentElement(id="count", text="1", bbox=[150, 75, 170, 95]),
        DocumentElement(id="result", text="Issued", bbox=[250, 75, 300, 95]),
    ]
    matched_ids = find_relevant_field_ids(elements, "birth certificate")
    assert {"h1", "h2", "h3", "label", "count", "result"}.issubset(matched_ids)


# ─────────────────────────────────────────────────────────────────────────────
# Test 2: "brain tumor"
# ─────────────────────────────────────────────────────────────────────────────

def test_brain_tumor_relevance(representative_medical_table):
    query = "brain tumor"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)

    # Must match brain tumors row only
    assert "row5_label" in matched_ids
    assert "row5_pct" in matched_ids

    # Must NOT match unrelated rows
    assert "row6_label" not in matched_ids  # other hematological tumors
    assert "row8_label" not in matched_ids  # other tumors
    assert "row2_label" not in matched_ids  # lung
    assert "row3_label" not in matched_ids  # prostate
    assert "row7_label" not in matched_ids  # rheumatological disorders

    answer = extract_answer_from_keep_fields(query, representative_medical_table, matched_ids)
    assert answer == "1.1%"


# ─────────────────────────────────────────────────────────────────────────────
# Test 3: "lung score"
# ─────────────────────────────────────────────────────────────────────────────

def test_lung_score_relevance(representative_medical_table):
    query = "lung score"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)

    assert "row2_label" in matched_ids
    assert "row2_pct" in matched_ids
    assert "row2_count" in matched_ids

    # Reject other rows
    assert "row1_label" not in matched_ids
    assert "row3_label" not in matched_ids

    answer = extract_answer_from_keep_fields(query, representative_medical_table, matched_ids)
    assert answer == "13.3%"


# ─────────────────────────────────────────────────────────────────────────────
# Test 4: "other hematological tumors"
# ─────────────────────────────────────────────────────────────────────────────

def test_other_hematological_tumors_relevance(representative_medical_table):
    query = "other hematological tumors"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)

    # Must match ONLY the "other hematological tumors" row
    assert "row6_label" in matched_ids
    assert "row6_pct" in matched_ids

    # Must NOT match "other tumors" or "brain tumors" or "rheumatological disorders"
    assert "row8_label" not in matched_ids  # other tumors
    assert "row5_label" not in matched_ids  # brain tumors
    assert "row7_label" not in matched_ids  # rheumatological disorders

    answer = extract_answer_from_keep_fields(query, representative_medical_table, matched_ids)
    assert answer == "4.3%"


# ─────────────────────────────────────────────────────────────────────────────
# Test 5: "prostate score"
# ─────────────────────────────────────────────────────────────────────────────

def test_prostate_score_relevance(representative_medical_table):
    query = "prostate score"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)

    assert "row3_label" in matched_ids
    assert "row3_pct" in matched_ids
    assert "row3_count" in matched_ids

    answer = extract_answer_from_keep_fields(query, representative_medical_table, matched_ids)
    assert answer == "37.5%"


# ─────────────────────────────────────────────────────────────────────────────
# Test 6: Exact table-row matching precedence ("other tumors")
# ─────────────────────────────────────────────────────────────────────────────

def test_other_tumors_exact_precedence(representative_medical_table):
    query = "other tumors"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)

    # "other tumors" must match row8 ("other tumors"), NOT row6 ("other hematological tumors")
    assert "row8_label" in matched_ids
    assert "row8_pct" in matched_ids
    assert "row6_label" not in matched_ids  # other hematological tumors must be excluded
    assert "row5_label" not in matched_ids  # brain tumors must be excluded


# ─────────────────────────────────────────────────────────────────────────────
# Test 7: Singular / Plural matching
# ─────────────────────────────────────────────────────────────────────────────

def test_singular_plural_normalization():
    assert normalize_token("tumors") == "tumor"
    assert normalize_token("tumor") == "tumor"
    assert normalize_token("scores") == "score"
    assert normalize_token("disorders") == "disorder"
    assert normalize_token("diagnoses") == "diagnosis"
    assert normalize_token("addresses") == "address"  # handles ss correctly


def test_measure_hints_match_whole_normalized_tokens():
    assert _query_kind("corporate record") == "general"
    assert _query_kind("percentages") == "score"
    assert _query_kind("invoice totals") == "amount"


def test_phrase_match_does_not_match_inside_an_unrelated_word():
    row = [DocumentElement(id="heart", text="heart", bbox=[0, 0, 50, 20])]
    assert score_row_match(row, "art") == 0.0


def test_singular_plural_query_matching(representative_medical_table):
    # Query with singular "disorder" should match plural row "rheumatological disorders"
    query = "rheumatological disorder"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)
    assert "row7_label" in matched_ids
    assert "row7_pct" in matched_ids
    assert "row6_label" not in matched_ids


# ─────────────────────────────────────────────────────────────────────────────
# Test 8: Generic keyword rejection
# ─────────────────────────────────────────────────────────────────────────────

def test_generic_keyword_does_not_select_unrelated_rows(representative_medical_table):
    # "brain" with generic word "cancer" should still find "brain tumors"
    # and strictly reject all other tumor rows.
    query = "brain cancer"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)
    assert "row5_label" in matched_ids
    assert "row6_label" not in matched_ids
    assert "row8_label" not in matched_ids


# ─────────────────────────────────────────────────────────────────────────────
# Test 9: Malformed LLM response handling
# ─────────────────────────────────────────────────────────────────────────────

def test_malformed_llm_response_graceful_recovery(representative_medical_table):
    malformed_raw = "Sorry, I cannot answer. Here is some text {not json at all"
    all_ids = {e.id for e in representative_medical_table}

    decision = _parse_llm_response(
        malformed_raw,
        all_ids,
        elements=representative_medical_table,
        user_query="kidney score",
    )

    # Must NOT crash; must apply deterministic fallback
    assert decision is not None
    actions = {d.field_id: d.action for d in decision.decisions}
    assert actions["row1_label"] == RedactionAction.KEEP
    assert actions["row1_pct"] == RedactionAction.KEEP
    assert actions["row1_count"] == RedactionAction.KEEP
    assert actions["row2_label"] == RedactionAction.HIDE
    assert decision.answer.strip() == "45.8%"


# ─────────────────────────────────────────────────────────────────────────────
# Test 10: Empty relevance result
# ─────────────────────────────────────────────────────────────────────────────

def test_empty_relevance_result(representative_medical_table):
    query = "completely nonexistent organ or test xyz"
    matched_ids = find_relevant_field_ids(representative_medical_table, query)
    assert len(matched_ids) == 0

    all_ids = {e.id for e in representative_medical_table}
    decision = _parse_llm_response(
        json.dumps({"answer": "", "relevant_field_ids": []}),
        all_ids,
        elements=representative_medical_table,
        user_query=query,
    )
    # Everything should be hidden or redacted, nothing visible
    visible_count = sum(1 for d in decision.decisions if d.action.is_keep())
    assert visible_count == 0
    assert "No relevant information found" in decision.answer


# ─────────────────────────────────────────────────────────────────────────────
# Multi-page row grouping isolation
# ─────────────────────────────────────────────────────────────────────────────

def test_multipage_row_grouping_isolation():
    elements = [
        DocumentElement(id="p1_a", text="Patient Name", bbox=[40, 50, 120, 70], page=1),
        DocumentElement(id="p1_b", text="Alice", bbox=[140, 50, 200, 70], page=1),
        DocumentElement(id="p2_a", text="Invoice Number", bbox=[40, 50, 120, 70], page=2),
        DocumentElement(id="p2_b", text="INV-999", bbox=[140, 50, 200, 70], page=2),
    ]
    rows = group_rows(elements)
    # Should produce 2 distinct rows (one per page), not merge across pages!
    assert len(rows) == 2
    assert {e.id for e in rows[0]} == {"p1_a", "p1_b"}
    assert {e.id for e in rows[1]} == {"p2_a", "p2_b"}
