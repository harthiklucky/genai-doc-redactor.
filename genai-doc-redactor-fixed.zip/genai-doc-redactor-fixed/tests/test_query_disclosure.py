"""Regression tests for natural-language query -> field -> disclosure.

All documents are synthetic. The local model is never called: tests use
``llm_mode="Off"`` or replace ``LLMClient.generate`` with a scripted fake.
"""
from __future__ import annotations

import io
import json
import re
from pathlib import Path
from zipfile import ZipFile

import pytest
from PIL import Image

import pipeline
from agents import llm_client
from agents.field_matcher import match_fields
from ingestion.document_model import DocumentElement
from ingestion.field_extractor import extract_document_fields, split_inline_key_value_spans
from redaction.image_redactor import selective_disclosure_image
from utils.ui_state import clear_result, request_signature, result_is_current, store_result

fitz = pytest.importorskip("pymupdf")

PERSON = [
    "Name: Rahul Kumar",
    "Age: 24",
    "Phone: 9876543210",
    "Email: rahul@example.com",
    "Address: Coimbatore, Tamil Nadu",
    "Date of Birth: 15/08/2002",
]
VALUES = {
    "name": "Rahul Kumar", "age": "24", "phone": "9876543210",
    "email": "rahul@example.com", "address": "Coimbatore, Tamil Nadu", "dob": "15/08/2002",
}


def make_pdf(path: Path, pages: list[list[str]], x: float = 72, step: float = 28) -> Path:
    doc = fitz.open()
    for lines in pages:
        page = doc.new_page()
        for i, line in enumerate(lines):
            if isinstance(line, tuple):  # (text, x, y) for explicit layouts
                page.insert_text((line[1], line[2]), line[0], fontsize=12)
            else:
                page.insert_text((x, 100 + i * step), line, fontsize=13)
    doc.save(path)
    doc.close()
    return path


@pytest.fixture(scope="module")
def person_pdf(tmp_path_factory) -> Path:
    return make_pdf(tmp_path_factory.mktemp("docs") / "person.pdf", [PERSON])


def run(path: Path, query: str, **kwargs) -> pipeline.PipelineResult:
    kwargs.setdefault("llm_mode", "Off")
    kwargs.setdefault("output_format", "PNG")
    result = pipeline.process_document(path, query, **kwargs)
    assert result.error is None, result.error
    return result


def disclosed_texts(result) -> set[str]:
    by_id = {el.id: el for el in result.document.all_elements()}
    return {by_id[d.field_id].text for d in result.decision.decisions if d.action.is_keep()}


def disclosed_values(result) -> set[str]:
    """Values (not labels) visible in the protected output."""
    keep = {d.field_id for d in result.decision.decisions if d.action.is_keep()}
    return {
        f.value for f in result.fields
        if keep.issuperset(f.value_element_ids)
    }


def protected_values(result) -> set[str]:
    return {f.value for f in result.fields} - disclosed_values(result)


# ─── A–E: field selection ────────────────────────────────────────────────────

def test_a_address_selection(person_pdf):
    result = run(person_pdf, "I only need the address")
    assert result.decision.answer == VALUES["address"]
    assert VALUES["phone"] not in result.decision.answer
    assert VALUES["name"] not in result.decision.answer
    assert disclosed_values(result) == {VALUES["address"]}
    assert {VALUES["name"], VALUES["phone"], VALUES["email"], VALUES["dob"], VALUES["age"]} <= protected_values(result)
    # The label stays readable together with every other label.
    assert {"Address:", "Name:", "Phone:"} <= disclosed_texts(result)


@pytest.mark.parametrize("query", [
    "Give me the address.",
    "What is the address?",
    "I need the person's address.",
    "Show only the address.",
    "Extract the address field.",
    "Tell me the residential address.",
    "Return the address field only.",
    "I want the patient's address.",
    "Give me only the address.",
])
def test_b_address_paraphrases(person_pdf, query):
    result = run(person_pdf, query)
    assert disclosed_values(result) == {VALUES["address"]}
    assert result.decision.answer == VALUES["address"]


def test_c_phone_selection(person_pdf):
    result = run(person_pdf, "What is the phone number?")
    assert result.decision.answer == VALUES["phone"]
    assert disclosed_values(result) == {VALUES["phone"]}


def test_d_date_of_birth(person_pdf):
    result = run(person_pdf, "Give me the date of birth.")
    assert result.decision.answer == VALUES["dob"]
    assert disclosed_values(result) == {VALUES["dob"]}


def test_e_multiple_fields(person_pdf):
    result = run(person_pdf, "Give me the address and phone number.")
    assert disclosed_values(result) == {VALUES["address"], VALUES["phone"]}
    assert "Address: Coimbatore, Tamil Nadu" in result.decision.answer
    assert "Phone: 9876543210" in result.decision.answer
    assert VALUES["email"] not in result.decision.answer


def test_email_address_phrase_selects_only_email(person_pdf):
    """'email address' names one field; it must not also disclose Address."""
    result = run(person_pdf, "Show me the email address.")
    assert disclosed_values(result) == {VALUES["email"]}
    assert result.decision.answer == VALUES["email"]


def test_name_and_address(person_pdf):
    result = run(person_pdf, "Give me the name and address.")
    assert disclosed_values(result) == {VALUES["name"], VALUES["address"]}


# ─── F–G: missing and ambiguous ──────────────────────────────────────────────

def test_f_missing_field_is_reported_not_fabricated(person_pdf):
    result = run(person_pdf, "What is the passport number?")
    assert "not found" in result.decision.answer.lower()
    assert "passport" in result.decision.answer.lower()
    assert disclosed_values(result) == set()
    assert not any(v in result.decision.answer for v in VALUES.values())


def test_g_ambiguous_query_discloses_nothing(tmp_path):
    pdf = make_pdf(tmp_path / "amb.pdf", [[
        "Patient Name: Anita Sharma", "Doctor Name: Vikram Rao", "Ward: 7",
    ]])
    result = run(pdf, "What is the name?")
    assert disclosed_values(result) == set()
    assert "more than one field" in result.decision.answer
    assert "Anita" not in result.decision.answer and "Vikram" not in result.decision.answer
    # A qualified request is not ambiguous.
    assert disclosed_values(run(pdf, "What is the doctor's name?")) == {"Vikram Rao"}


# ─── H–I: model output validation ────────────────────────────────────────────

class FakeLLM:
    """Scripted stand-in for the Ollama call: picks fields by label."""

    def __init__(self, labels=(), raw=None, extra_ids=(), confidence=0.9):
        self.labels, self.raw, self.extra_ids, self.confidence = labels, raw, extra_ids, confidence
        self.calls = 0

    def __call__(self, client, system_prompt, user_prompt):
        self.calls += 1
        if self.raw is not None:
            return self.raw
        ids = [
            m.group(1) for label in self.labels
            for m in [re.search(rf'\[(F\d+)\][^\n]*label="{re.escape(label)}"', user_prompt)] if m
        ]
        return json.dumps({
            "answer": "model text", "relevant_field_ids": ids + list(self.extra_ids),
            "reasoning": "scripted", "confidence": self.confidence,
        })


def with_llm(monkeypatch, fake: FakeLLM) -> FakeLLM:
    def generate(self, system_prompt, user_prompt):
        return fake(self, system_prompt, user_prompt)
    monkeypatch.setattr(llm_client.LLMClient, "generate", generate)
    return fake


@pytest.mark.parametrize("raw", [
    "Sorry, I cannot help {not json",
    "",
    '{"relevant_field_ids": "F1"}',
    '["F1", "F2"]',
    '{"answer": 5, "relevant_field_ids": ["F1"]}',
])
def test_h_malformed_llm_output_is_safe(monkeypatch, person_pdf, raw):
    with_llm(monkeypatch, FakeLLM(raw=raw))
    # Model consulted because no field matches the wording.
    result = run(person_pdf, "Where does this person live?", llm_mode="Auto")
    assert disclosed_values(result) == set()
    assert "deterministic" in result.decision.llm_status.lower()
    # A clear request still works when the model output is garbage.
    result = run(person_pdf, "I only need the address", llm_mode="Always")
    assert disclosed_values(result) == {VALUES["address"]}


def test_h_llm_unavailable_falls_back(monkeypatch, person_pdf):
    def down(*args, **kwargs):
        raise ConnectionError("Cannot connect to Ollama")
    monkeypatch.setattr(llm_client.LLMClient, "generate", down)
    result = run(person_pdf, "What is the phone number?", llm_mode="Always")
    assert result.decision.answer == VALUES["phone"]
    assert "unavailable" in result.decision.llm_status.lower()


def test_i_hallucinated_ids_are_rejected(monkeypatch, person_pdf):
    with_llm(monkeypatch, FakeLLM(extra_ids=["F99", "field_9999", "p1:made_up"]))
    result = run(person_pdf, "Where does this person live?", llm_mode="Auto")
    assert disclosed_values(result) == set()
    assert "nonexistent" in result.decision.llm_status


def test_model_cannot_override_an_exact_field_match(monkeypatch, person_pdf):
    """The original bug: the model picks Name for an address request."""
    fake = with_llm(monkeypatch, FakeLLM(labels=["Name"]))
    result = run(person_pdf, "I only need the address", llm_mode="Always")
    assert fake.calls == 1
    assert result.decision.answer == VALUES["address"]
    assert disclosed_values(result) == {VALUES["address"]}


def test_model_pick_contradicting_a_named_field_type_is_rejected(monkeypatch, person_pdf):
    with_llm(monkeypatch, FakeLLM(labels=["Phone"]))
    result = run(person_pdf, "What is the passport number?", llm_mode="Auto")
    assert disclosed_values(result) == set()
    assert "not found" in result.decision.answer


def test_validated_semantic_selection_answers_paraphrase(monkeypatch, person_pdf):
    fake = with_llm(monkeypatch, FakeLLM(labels=["Address"]))
    result = run(person_pdf, "Where does this person live?", llm_mode="Auto")
    assert fake.calls == 1
    assert result.decision.answer == VALUES["address"]
    assert disclosed_values(result) == {VALUES["address"]}
    # Maximum mode does not disclose a sensitive value on model judgement alone.
    result = run(person_pdf, "Where does this person live?", llm_mode="Auto", privacy_mode="Maximum")
    assert disclosed_values(result) == set()


def test_low_confidence_model_selection_is_not_used(monkeypatch, person_pdf):
    with_llm(monkeypatch, FakeLLM(labels=["Address"], confidence=0.3))
    result = run(person_pdf, "Where does this person live?", llm_mode="Auto")
    assert disclosed_values(result) == set()


def test_auto_mode_skips_model_for_resolved_requests(monkeypatch, person_pdf):
    fake = with_llm(monkeypatch, FakeLLM(labels=["Address"]))
    run(person_pdf, "What is the address?", llm_mode="Auto")
    assert fake.calls == 0


# ─── J–K: tables and multi-page ──────────────────────────────────────────────

INVOICE_PAGE = [
    ("INVOICE", 72, 60),
    ("Invoice Number: INV-2024-0042", 72, 90),
    ("Customer: Meera Iyer", 72, 115),
    ("Item", 72, 160), ("Qty", 260, 160), ("Price", 360, 160),
    ("Widget", 72, 185), ("2", 260, 185), ("$10.00", 360, 185),
    ("Gadget", 72, 210), ("1", 260, 210), ("$25.00", 360, 210),
    ("Total: $45.00", 72, 260),
]


@pytest.fixture(scope="module")
def invoice_pdf(tmp_path_factory) -> Path:
    return make_pdf(tmp_path_factory.mktemp("inv") / "invoice.pdf", [INVOICE_PAGE])


def test_j_single_table_cell(invoice_pdf):
    result = run(invoice_pdf, "What is the price of the gadget?")
    texts = disclosed_texts(result)
    assert "$25.00" in result.decision.answer
    assert {"$25.00", "Gadget", "Price"} <= texts
    assert "$10.00" not in texts and "Widget" not in texts
    assert "1" not in texts  # the gadget's quantity cell
    assert "Meera Iyer" not in texts


def test_invoice_number_and_total(invoice_pdf):
    result = run(invoice_pdf, "Show the invoice number and total")
    assert disclosed_values(result) == {"INV-2024-0042", "$45.00"}
    assert "Meera Iyer" in protected_values(result)


def test_k_multipage_other_page_stays_protected(tmp_path):
    pdf = make_pdf(tmp_path / "multi.pdf", [
        ["Name: Rahul Kumar", "Phone: 9876543210"],
        ["Address: Coimbatore, Tamil Nadu", "SSN: 078-05-1120"],
    ])
    result = run(pdf, "I only need the address", output_format="PDF")
    assert disclosed_values(result) == {VALUES["address"]}
    assert {"Rahul Kumar", "9876543210", "078-05-1120"} <= protected_values(result)
    assert len(result.redacted_images) == 2
    with fitz.open(result.output_path) as out:
        assert len(out) == 2


# ─── L–M: output formats and redaction integrity ─────────────────────────────

@pytest.mark.parametrize("fmt,magic,suffix", [
    ("PDF", b"%PDF", ".pdf"),
    ("DOCX", b"PK", ".docx"),
    ("PNG", b"\x89PNG", ".png"),
    ("JPG", b"\xff\xd8\xff", ".jpg"),
])
def test_l_output_format_produces_that_file_type(person_pdf, fmt, magic, suffix):
    result = run(person_pdf, "I only need the address", output_format=fmt)
    assert result.output_path.suffix == suffix
    data = result.output_path.read_bytes()
    assert data.startswith(magic)
    if fmt in ("PNG", "JPG"):
        image = Image.open(io.BytesIO(data))
        image.verify()
        assert image.format == ("PNG" if fmt == "PNG" else "JPEG")
    if fmt == "DOCX":
        with ZipFile(io.BytesIO(data)) as package:
            assert "word/document.xml" in package.namelist()
            assert any(name.startswith("word/media/") for name in package.namelist())
        docx = pytest.importorskip("docx")
        assert len(docx.Document(str(result.output_path)).inline_shapes) == 1


def test_l_multipage_raster_is_zip_of_requested_format(tmp_path):
    pdf = make_pdf(tmp_path / "two.pdf", [["Name: A B"], ["Phone: 9876543210"]])
    result = run(pdf, "phone", output_format="JPG")
    assert result.output_path.suffix == ".zip"
    with ZipFile(result.output_path) as bundle:
        names = bundle.namelist()
        assert names == ["protected_page_001.jpg", "protected_page_002.jpg"]
        assert all(bundle.read(n).startswith(b"\xff\xd8\xff") for n in names)


def test_m_protected_values_absent_from_exports(person_pdf):
    protected = [VALUES[k] for k in ("name", "phone", "email", "dob")]
    pdf = run(person_pdf, "I only need the address", output_format="PDF").output_path
    raw = pdf.read_bytes()
    assert not any(v.encode() in raw for v in protected)
    with fitz.open(pdf) as out:
        assert out[0].get_text().strip() == ""  # image-only: nothing to extract
        assert not any(v for v in out.metadata.values() if v and "Rahul" in v)
    docx_path = run(person_pdf, "I only need the address", output_format="DOCX").output_path
    with ZipFile(docx_path) as package:
        for name in package.namelist():
            if name.endswith((".xml", ".rels")):
                body = package.read(name)
                assert not any(v.encode() in body for v in [*protected, VALUES["address"]])


def test_m_ocr_cannot_read_protected_values(person_pdf):
    """Run OCR over the protected PNG: only the requested value is readable."""
    from ocr.easyocr_engine import EasyOCREngine
    result = run(person_pdf, "I only need the address", output_format="PNG")
    text = " ".join(el.text for el in EasyOCREngine().extract(Image.open(result.output_path)))
    compact = re.sub(r"\s", "", text)
    assert "Coimbatore" in text
    assert "Address" in text
    for value in ("9876543210", "rahul@example", "RahulKumar", "15/08/2002"):
        assert value not in compact


@pytest.mark.parametrize("mode", ["blur", "replacement", "blackout"])
def test_m_protected_region_holds_no_source_pixels(mode):
    """The protected patch is identical whatever text was underneath."""
    box = [20, 10, 200, 40]
    patches = []
    for secret in ("9876543210", "1111111111"):
        img = Image.new("RGB", (240, 60), "white")
        from PIL import ImageDraw
        ImageDraw.Draw(img).text((25, 15), secret, fill="black")
        out = selective_disclosure_image(
            img, [], mode=mode, protected_elements=[DocumentElement(id="v", text=secret, bbox=box)]
        )
        patches.append(out.crop((17, 7, 203, 43)).tobytes())
    assert patches[0] == patches[1]


def test_m_padding_never_reveals_a_hidden_neighbouring_line():
    img = Image.new("RGB", (200, 60), "black")
    kept = DocumentElement(id="k", text="Email:", bbox=[10, 30, 80, 50])
    hidden = DocumentElement(id="h", text="Buyerville", bbox=[10, 10, 120, 29])
    out = selective_disclosure_image(img, [kept], padding=4, hidden_elements=[hidden])
    assert _pixels(out.crop((10, 10, 120, 29))) == {(255, 255, 255)}
    assert out.getpixel((40, 40)) == (0, 0, 0)  # the disclosed label itself


def test_redaction_style_changes_output(person_pdf):
    images = {
        mode: run(person_pdf, "I only need the address", redaction_mode=mode).redacted_images[0].tobytes()
        for mode in ("blackout", "blur", "replacement")
    }
    assert len(set(images.values())) == 3


# ─── N: UI state ─────────────────────────────────────────────────────────────

def test_n_any_input_change_invalidates_displayed_result():
    base = dict(upload_digest="d1", query="address", privacy_mode="Strict", redaction_mode="blackout",
                output_format="PDF", model="qwen2.5:7b", llm_mode="Auto")
    state: dict = {}
    sig = request_signature(**base)
    store_result(state, object(), sig, base["query"])
    assert result_is_current(state, sig)
    for key, value in [("upload_digest", "d2"), ("query", "phone"), ("privacy_mode", "Maximum"),
                       ("redaction_mode", "blur"), ("output_format", "DOCX"),
                       ("model", "other"), ("llm_mode", "Off")]:
        assert not result_is_current(state, request_signature(**{**base, key: value})), key
    assert result_is_current(state, request_signature(**{**base, "query": "  address "}))
    clear_result(state)
    assert not result_is_current(state, sig)


def test_n_each_run_writes_a_new_output_file(person_pdf):
    first = run(person_pdf, "I only need the address", output_format="PNG").output_path
    first_bytes = first.read_bytes()
    second = run(person_pdf, "What is the phone number?", output_format="PNG").output_path
    assert first != second
    assert first.read_bytes() == first_bytes


# ─── Privacy modes, layouts, generic fields, robustness ──────────────────────

def test_maximum_mode_hides_other_labels(person_pdf):
    result = run(person_pdf, "I only need the address", privacy_mode="Maximum")
    texts = disclosed_texts(result)
    assert texts == {"Address:", VALUES["address"]}


def test_standard_mode_honours_all_except(person_pdf):
    result = run(person_pdf, "Show everything except the phone and email", privacy_mode="Standard")
    assert VALUES["phone"] in protected_values(result) and VALUES["email"] in protected_values(result)
    assert {VALUES["name"], VALUES["address"], VALUES["dob"]} <= disclosed_values(result)
    strict = run(person_pdf, "Show everything except the phone", privacy_mode="Strict")
    assert disclosed_values(strict) == set()
    assert "Strict mode discloses only fields named" in strict.decision.answer


def test_exclusion_inside_a_request(person_pdf):
    result = run(person_pdf, "Give me the address and phone but not the email")
    assert disclosed_values(result) == {VALUES["address"], VALUES["phone"]}


def test_diagnosis_and_test_result(tmp_path):
    pdf = make_pdf(tmp_path / "med.pdf", [[
        "MEDICAL REPORT", "Patient Name: Anita Sharma", "Patient ID: PT-88421",
        "Diagnosis: Type 2 Diabetes", "Test Result: HbA1c 7.2 percent", "Medication: Metformin 500mg",
    ]])
    result = run(pdf, "What are the patient's diagnosis and test result?")
    assert disclosed_values(result) == {"Type 2 Diabetes", "HbA1c 7.2 percent"}
    assert "Diagnosis: Type 2 Diabetes" in result.decision.answer
    assert {"Anita Sharma", "PT-88421", "Metformin 500mg"} <= protected_values(result)


@pytest.mark.parametrize("label,value,query", [
    ("Employee Number", "EMP-4471", "What is the employee number?"),
    ("Employee ID", "EMP-4471", "Give me the employee number"),
    ("Department", "Finance", "Which department?"),
    ("Salary", "Rs 85,000", "What is the salary?"),
    ("Transaction Date", "03/02/2024", "Show the transaction date"),
    ("Certificate Number", "CERT-9981", "I need the certificate number"),
    ("Tax Amount", "Rs 1,250", "What is the tax amount?"),
    ("Account Identifier", "ACC-55-0193", "Return the account identifier"),
    ("Invoice Total", "Rs 66,000", "Show the invoice total"),
    ("Mobile No.", "9123456780", "What is the phone number?"),
    ("DOB", "01/01/1990", "Give me the date of birth"),
])
def test_generic_field_matching(label, value, query):
    lines = [f"{label}: {value}", "Name: Test Person", "Reference Code: ZX-1"]
    elements = split_inline_key_value_spans([
        DocumentElement(id=f"e{i}", text=t, bbox=[10, 10 + 30 * i, 400, 30 + 30 * i])
        for i, t in enumerate(lines)
    ])
    fields = extract_document_fields(elements)
    match = match_fields(fields, query)
    chosen = [f for f in fields if f.field_id in match.selected_field_ids]
    assert [f.value for f in chosen] == [value]


def test_shared_generic_word_does_not_select_unrelated_field():
    elements = split_inline_key_value_spans([
        DocumentElement(id="a", text="Phone Number: 9876543210", bbox=[0, 0, 300, 20]),
        DocumentElement(id="b", text="Email Address: x@example.com", bbox=[0, 30, 300, 50]),
    ])
    fields = extract_document_fields(elements)
    assert match_fields(fields, "What is the passport number?").selected_field_ids == set()
    assert match_fields(fields, "What is the home address?").selected_field_ids == set()


def test_label_value_without_colon_and_multiline_value(tmp_path):
    pdf = make_pdf(tmp_path / "form.pdf", [[
        ("Phone 9876543210", 72, 100),
        ("Address:", 72, 140),
        ("12 Lake View Road,", 72, 160),
        ("Coimbatore, Tamil Nadu", 72, 180),
        ("Email: rahul@example.com", 72, 220),
    ]])
    result = run(pdf, "What is the address?")
    assert result.decision.answer == "12 Lake View Road, Coimbatore, Tamil Nadu"
    assert "rahul@example.com" in protected_values(result)
    assert run(pdf, "phone").decision.answer == "9876543210"


def test_scanned_image_input(tmp_path):
    from PIL import ImageDraw, ImageFont
    img = Image.new("RGB", (900, 300), "white")
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("arial.ttf", 26)
    except OSError:
        pytest.skip("Arial font unavailable for the synthetic scan")
    for i, line in enumerate(["Name: Rahul Kumar", "Phone: 9876543210", "Address: Coimbatore, Tamil Nadu"]):
        draw.text((40, 30 + i * 70), line, fill="black", font=font)
    path = tmp_path / "scan.png"
    img.save(path)
    result = run(path, "I only need the address")
    assert "Coimbatore" in result.decision.answer
    assert "9876543210" not in result.decision.answer
    assert not any("9876543210" in v for v in disclosed_values(result))


def test_invalid_inputs_return_clear_errors(tmp_path, person_pdf):
    assert pipeline.process_document(person_pdf, "   ").error.startswith("Please enter")
    assert "too long" in pipeline.process_document(person_pdf, "a" * 1001).error
    bad = tmp_path / "notes.txt"
    bad.write_text("Name: x")
    assert "Unsupported file type" in pipeline.process_document(bad, "name").error
    assert "Unsupported output format" in pipeline.process_document(person_pdf, "name", output_format="TIFF").error
    blank = tmp_path / "blank.pdf"
    doc = fitz.open()
    doc.new_page()
    doc.save(blank)
    doc.close()
    # A blank page goes through OCR and yields no text.
    assert pipeline.process_document(blank, "name", llm_mode="Off").error


def test_logs_do_not_contain_document_values(person_pdf, caplog, capsys):
    caplog.set_level("DEBUG")
    run(person_pdf, "Give me the address and phone number.")
    logged = caplog.text + capsys.readouterr().out
    for value in VALUES.values():
        if len(value) > 3:
            assert value not in logged


def _pixels(image) -> set:
    """Distinct RGB colours of an image (without Pillow's deprecated getdata)."""
    import numpy as np
    return {tuple(px) for px in np.asarray(image.convert("RGB")).reshape(-1, 3).tolist()}
