"""Tests for PII detection."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from ingestion.document_model import DocumentElement
from pii.presidio_detector import detect_pii_in_elements


def _make_element(id: str, text: str) -> DocumentElement:
    return DocumentElement(id=id, text=text, bbox=[0, 0, 100, 20])


def test_detect_person_name():
    elements = [_make_element("f1", "John Michael Doe")]
    result = detect_pii_in_elements(elements)
    assert result[0].entity_type == "PERSON"


def test_detect_email():
    elements = [_make_element("f1", "john.doe@example.com")]
    result = detect_pii_in_elements(elements)
    assert result[0].entity_type == "EMAIL"


def test_detect_phone():
    elements = [_make_element("f1", "(555) 987-6543")]
    result = detect_pii_in_elements(elements)
    assert result[0].entity_type == "PHONE"


def test_no_pii_in_normal_text():
    elements = [_make_element("f1", "Invoice Total")]
    result = detect_pii_in_elements(elements)
    # Should not be tagged or tagged as something non-personal
    assert result[0].entity_type is None or result[0].entity_type not in ("PERSON", "EMAIL", "PHONE")


def test_multiple_elements():
    elements = [
        _make_element("f1", "Jane Smith"),
        _make_element("f2", "Diagnosis: Type 2 Diabetes"),
        _make_element("f3", "jane@example.com"),
    ]
    result = detect_pii_in_elements(elements)
    types = [el.entity_type for el in result]
    assert "PERSON" in types
    assert "EMAIL" in types
