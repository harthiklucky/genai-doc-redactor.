"""Tests for the privacy agent parsing and decision logic."""
import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ingestion.document_model import DocumentElement
from agents.schemas import PrivacyDecisionResponse, FieldDecision, RedactionAction
from agents.privacy_agent import _parse_llm_response, _fallback_response


def test_parse_valid_json():
    raw = json.dumps({
        "answer": "The diagnosis is Type 2 Diabetes.",
        "decisions": [
            {"field_id": "field_001", "action": "VISIBLE", "category": "DIAGNOSIS", "reason": "Requested"},
            {"field_id": "field_002", "action": "REDACT", "category": "PERSON", "reason": "Not needed"},
        ],
        "summary": "Showed diagnosis, hid name.",
    })
    elements = [
        DocumentElement(id="field_001", text="Type 2 Diabetes Mellitus", bbox=[0, 0, 40, 20]),
        DocumentElement(id="field_002", text="John Smith", bbox=[0, 30, 40, 50], entity_type="PERSON"),
    ]
    result = _parse_llm_response(
        raw, {"field_001", "field_002"}, elements=elements, user_query="diagnosis"
    )
    assert isinstance(result, PrivacyDecisionResponse)
    # The UI answer comes from the approved field, not free-form model text.
    assert result.answer == "Type 2 Diabetes Mellitus"
    assert len(result.decisions) == 2
    actions = {d.field_id: d.action for d in result.decisions}
    assert actions["field_001"].is_keep()
    assert actions["field_002"] == RedactionAction.REDACT


def test_parse_json_in_code_fence():
    raw = '```json\n{"answer":"test","decisions":[],"summary":"ok"}\n```'
    result = _parse_llm_response(raw, set())
    assert "No relevant information" in result.answer


def test_parse_with_extra_text():
    raw = 'Here is my analysis:\n{"answer":"result","decisions":[],"summary":"done"}\nEnd.'
    result = _parse_llm_response(raw, set())
    assert "No relevant information" in result.answer


def test_unapproved_model_answer_is_never_returned():
    raw = json.dumps({
        "answer": "The patient's SSN is 123-45-6789.",
        "relevant_field_ids": [],
        "decisions": [],
    })
    result = _parse_llm_response(raw, {"f1"}, user_query="unmatched query")
    assert "123-45-6789" not in result.answer
    assert "No relevant information" in result.answer


def test_model_answer_is_not_used_when_approved_field_text_is_unavailable():
    raw = json.dumps({
        "answer": "The patient's SSN is 123-45-6789.",
        "relevant_field_ids": ["f1"],
    })
    elements = [DocumentElement(id="f1", text="", bbox=[0, 0, 40, 20])]
    result = _parse_llm_response(
        raw, {"f1"}, elements=elements, user_query="patient identifier"
    )
    assert "123-45-6789" not in result.answer
    assert "unavailable" in result.answer


def test_requested_sensitive_field_is_disclosed_and_unrequested_sensitive_fields_stay_redacted():
    elements = [
        DocumentElement(id="label", text="Name", bbox=[0, 0, 40, 20]),
        DocumentElement(id="name", text="Jane Doe", bbox=[50, 0, 110, 20], entity_type="PERSON"),
        DocumentElement(id="phone_label", text="Phone", bbox=[0, 30, 40, 50]),
        DocumentElement(id="phone", text="9876543210", bbox=[50, 30, 130, 50], entity_type="PHONE"),
    ]
    raw = json.dumps({"answer": "The name is Jane Doe.", "relevant_field_ids": ["label", "name"]})
    result = _parse_llm_response(
        raw, {el.id for el in elements}, elements=elements, user_query="name"
    )
    actions = {decision.field_id: decision.action for decision in result.decisions}
    assert actions["label"] == RedactionAction.KEEP
    assert actions["name"] == RedactionAction.KEEP
    assert actions["phone"] == RedactionAction.REDACT
    assert "Jane Doe" in result.answer
    assert "9876543210" not in result.answer


def test_parse_invalid_json_fallback():
    raw = "This is not valid JSON at all"
    result = _parse_llm_response(raw, {"f1", "f2"})
    # Fallback should redact everything
    assert len(result.decisions) == 2
    for d in result.decisions:
        assert d.action == RedactionAction.REDACT


def test_uncertain_defaults_to_redact():
    raw = json.dumps({
        "answer": "test",
        "decisions": [
            {"field_id": "f1", "action": "UNCERTAIN", "category": "UNKNOWN", "reason": "unclear"},
        ],
        "summary": "test",
    })
    result = _parse_llm_response(raw, {"f1"})
    assert result.decisions[0].action == RedactionAction.REDACT


def test_unmentioned_fields_default_to_redact():
    raw = json.dumps({
        "answer": "test",
        "decisions": [
            {"field_id": "f1", "action": "VISIBLE", "category": "DATA", "reason": "needed"},
        ],
        "summary": "test",
    })
    result = _parse_llm_response(raw, {"f1", "f2", "f3"})
    actions = {d.field_id: d.action for d in result.decisions}
    assert actions["f1"].is_keep()
    assert actions["f2"] == RedactionAction.REDACT
    assert actions["f3"] == RedactionAction.REDACT


def test_fallback_response():
    result = _fallback_response({"f1", "f2"})
    assert len(result.decisions) == 2
    for d in result.decisions:
        assert d.action == RedactionAction.REDACT
        assert d.category == "SAFETY_FALLBACK"


def test_unmentioned_non_sensitive_fields_are_ignored():
    elements = [
        DocumentElement(id="f1", text="diagnosis", bbox=[0, 0, 40, 20]),
        DocumentElement(id="f2", text="table header", bbox=[0, 30, 80, 50]),
        DocumentElement(id="f3", text="John Smith", bbox=[0, 60, 80, 80], entity_type="PERSON"),
    ]
    raw = json.dumps({
        "answer": "unknown",
        "decisions": [
            {"field_id": "f1", "action": "KEEP", "category": "DATA", "reason": "needed"},
        ],
        "summary": "test",
    })
    result = _parse_llm_response(raw, {"f1", "f2", "f3"}, elements=elements, user_query="diagnosis")
    actions = {d.field_id: d.action for d in result.decisions}
    assert actions["f1"] == RedactionAction.KEEP
    assert actions["f2"] == RedactionAction.IGNORE
    assert actions["f3"] == RedactionAction.REDACT


def test_uncertain_non_sensitive_is_ignored():
    elements = [
        DocumentElement(id="f1", text="lab panel", bbox=[0, 0, 40, 20]),
    ]
    raw = json.dumps({
        "answer": "test",
        "decisions": [
            {"field_id": "f1", "action": "UNCERTAIN", "category": "UNKNOWN", "reason": "unclear"},
        ],
        "summary": "test",
    })
    result = _parse_llm_response(raw, {"f1"}, elements=elements, user_query="kidney score")
    assert result.decisions[0].action == RedactionAction.IGNORE
