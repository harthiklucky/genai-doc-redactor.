"""Synthetic coverage for generic key/value disclosure and output containers."""
from __future__ import annotations

from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

import pytest
from PIL import Image, ImageDraw

from agents.privacy_agent import apply_context_aware_policy
from agents.schemas import LLMSemanticResult
from ingestion.document_model import DocumentElement
from ingestion.field_extractor import (
    extract_document_fields,
    select_requested_field_element_ids,
    split_inline_key_value_spans,
)
from agents.relevance import find_relevant_field_ids
from redaction.docx_redactor import images_to_docx
from redaction.image_redactor import selective_disclosure_image
from redaction.output_writer import images_to_raster_output
from redaction.pdf_redactor import images_to_pdf


def test_inline_key_value_spans_get_separate_boxes():
    source = DocumentElement(id="raw", text="Invoice Total: ₹66,000", bbox=[10, 10, 250, 34])
    parts = split_inline_key_value_spans([source])
    assert [part.text for part in parts] == ["Invoice Total:", "₹66,000"]
    # The value box slightly overlaps the estimated delimiter boundary so a
    # redaction covers the full value when OCR only supplied one whole-line box.
    assert parts[1].bbox[0] < parts[0].bbox[2]
    assert parts[1].bbox[2] > parts[0].bbox[2]


@pytest.mark.parametrize("text,label,value", [
    ("Name - Rahul", "Name", "Rahul"),
    ("Name — Rahul", "Name", "Rahul"),
    ("Patient Name    Rahul", "Patient Name", "Rahul"),
    ("Phone     :     9876543210", "Phone", "9876543210"),
    ("Invoice Total | ₹25,500", "Invoice Total", "₹25,500"),
])
def test_inline_field_fallback_supports_clear_non_colon_boundaries(text, label, value):
    parts = split_inline_key_value_spans([
        DocumentElement(id="source", text=text, bbox=[0, 0, 300, 24], confidence=0.82)
    ])
    fields = extract_document_fields(parts)
    assert len(fields) == 1
    assert (fields[0].label, fields[0].value) == (label, value)
    assert fields[0].confidence == 0.82


def test_separate_ocr_label_and_value_become_generic_document_field():
    elements = [
        DocumentElement(id="label", text="Account Number:", bbox=[10, 10, 100, 30], page=2),
        DocumentElement(id="value", text="1234567890", bbox=[105, 10, 180, 30], page=2, entity_type="BANK_ACCOUNT"),
    ]
    fields = extract_document_fields(elements)
    assert len(fields) == 1
    assert (fields[0].label, fields[0].value, fields[0].page) == ("Account Number", "1234567890", 2)
    assert fields[0].label_bbox and fields[0].value_bbox
    assert fields[0].sensitivity == ["BANK_ACCOUNT"]


def test_two_cell_table_row_becomes_a_field_value_pair():
    elements = [
        DocumentElement(id="label", text="Invoice Total", bbox=[10, 10, 100, 30]),
        DocumentElement(id="value", text="₹25,500", bbox=[110, 10, 180, 30]),
    ]
    fields = extract_document_fields(elements)
    assert len(fields) == 1
    assert (fields[0].label, fields[0].value, fields[0].source_type) == (
        "Invoice Total", "₹25,500", "table_row"
    )


@pytest.mark.parametrize("label,value", [
    ("Name", "Lucky"),
    ("DOB", "15-08-2004"),
    ("Phone", "9876543210"),
    ("Email", "lucky@example.com"),
    ("Address", "Coimbatore"),
    ("Invoice Total", "₹66,000"),
    ("Diagnosis", "Diabetes"),
    ("Blood Group", "O+"),
    ("Department", "Engineering"),
    ("Score", "45.8%"),
])
def test_generic_field_extraction_supports_arbitrary_labels(label, value):
    combined = DocumentElement(id="source", text=f"{label}: {value}", bbox=[0, 0, 300, 24])
    parts = split_inline_key_value_spans([combined])
    fields = extract_document_fields(parts)
    assert len(fields) == 1
    assert fields[0].label == label
    assert fields[0].value == value


@pytest.mark.parametrize("label,query", [
    ("Name", "What is the name?"),
    ("DOB", "What is the DOB?"),
    ("Phone", "What is the phone number?"),
    ("Email", "What is the email?"),
    ("Address", "What is the address?"),
    ("Invoice Total", "What is the invoice total?"),
    ("Diagnosis", "What is the diagnosis?"),
])
def test_common_query_forms_select_the_generic_field_value(label, query):
    source = DocumentElement(id="source", text=f"{label}: ExampleValue", bbox=[0, 0, 300, 24])
    elements = split_inline_key_value_spans([source])
    fields = extract_document_fields(elements)
    selected = select_requested_field_element_ids(fields, query)
    assert selected == set(fields[0].label_element_ids + fields[0].value_element_ids)


def test_paragraph_query_keeps_matching_text_line_only():
    elements = [
        DocumentElement(id="wanted", text="The report says kidney function is stable.", bbox=[0, 0, 300, 24]),
        DocumentElement(id="other", text="Account number 1234567890", bbox=[0, 40, 300, 64]),
    ]
    assert find_relevant_field_ids(elements, "kidney function") == {"wanted"}


def test_semantically_selected_sensitive_value_can_be_kept():
    elements = [
        DocumentElement(id="label", text="Name:", bbox=[10, 10, 60, 30]),
        DocumentElement(id="value", text="Lucky", bbox=[65, 10, 110, 30], entity_type="PERSON"),
        DocumentElement(id="phone-label", text="Phone:", bbox=[10, 40, 65, 60]),
        DocumentElement(id="phone-value", text="9876543210", bbox=[70, 40, 150, 60], entity_type="PHONE"),
    ]
    decision = apply_context_aware_policy(
        LLMSemanticResult(answer="Lucky", relevant_field_ids=["label", "value"]),
        elements,
        "Who is the person's name?",
    )
    actions = {item.field_id: item.action.value for item in decision.decisions}
    assert actions["label"] == "KEEP"
    assert actions["value"] == "KEEP"
    assert actions["phone-value"] == "REDACT"
    assert "Lucky" in decision.answer
    assert "9876543210" not in decision.answer


def test_query_keeps_only_requested_value_on_a_multi_field_line():
    source = DocumentElement(
        id="line",
        text="Name: Lucky, Age: 21, Phone: 9876543210",
        bbox=[0, 0, 360, 24],
    )
    elements = split_inline_key_value_spans([source])
    fields = extract_document_fields(elements)
    selected = select_requested_field_element_ids(fields, "What is the name?")
    assert selected == set(fields[0].label_element_ids + fields[0].value_element_ids)
    assert not selected.intersection(fields[1].value_element_ids + fields[2].value_element_ids)


def test_protected_value_is_replaced_and_label_remains_visible():
    image = Image.new("RGB", (220, 70), "white")
    ImageDraw.Draw(image).text((10, 10), "Phone:", fill="black")
    ImageDraw.Draw(image).text((80, 10), "9876543210", fill="black")
    label = DocumentElement(id="label", text="Phone:", bbox=[8, 8, 60, 30])
    value = DocumentElement(id="value", text="9876543210", bbox=[78, 8, 165, 30])

    protected = selective_disclosure_image(
        image, [label], protected_elements=[value], padding=1
    )
    assert protected.crop((8, 8, 60, 30)).tobytes() == image.crop((8, 8, 60, 30)).tobytes()
    assert _pixels(protected.crop((78, 8, 165, 30))) == {(0, 0, 0)}
    assert protected.getpixel((200, 50)) == (255, 255, 255)


def test_replacement_text_redaction_draws_only_on_clean_output_canvas():
    image = Image.new("RGB", (180, 50), "white")
    value = DocumentElement(id="value", text="sensitive", bbox=[20, 10, 150, 34])
    protected = selective_disclosure_image(
        image, [], mode="replacement", protected_elements=[value], padding=0
    )
    assert protected.getpixel((25, 15)) == (0, 0, 0)
    assert protected.getpixel((170, 40)) == (255, 255, 255)


def test_png_jpg_and_multipage_raster_outputs(tmp_path: Path):
    pages = [Image.new("RGB", (40, 30), "white"), Image.new("RGB", (40, 30), "black")]
    png = images_to_raster_output(pages[:1], tmp_path / "protected.png", "PNG")
    jpg = images_to_raster_output(pages[:1], tmp_path / "protected.jpg", "JPG")
    bundle = images_to_raster_output(pages, tmp_path / "protected.png", "PNG")
    assert png.suffix == ".png" and Image.open(png).size == (40, 30)
    assert jpg.suffix == ".jpg" and Image.open(jpg).size == (40, 30)
    with ZipFile(bundle) as archive:
        assert archive.namelist() == ["protected_page_001.png", "protected_page_002.png"]


def test_pdf_is_built_from_protected_pixels_only(tmp_path: Path):
    protected = Image.new("RGB", (80, 60), "white")
    output = images_to_pdf([protected], tmp_path / "protected.pdf")
    assert output.exists()
    assert b"LuckySensitiveText" not in output.read_bytes()
    fitz = pytest.importorskip("pymupdf")
    with fitz.open(output) as pdf:
        assert len(pdf) == 1
        assert pdf[0].get_text().strip() == ""


def test_docx_is_new_image_only_document_without_source_text(tmp_path: Path):
    pytest.importorskip("docx")
    output = images_to_docx([Image.new("RGB", (80, 60), "white")], tmp_path / "protected.docx")
    assert output.exists()
    with ZipFile(output) as archive:
        xml_parts = [archive.read(name) for name in archive.namelist() if name.endswith(".xml")]
    assert xml_parts
    assert all(b"LuckySensitiveText" not in part for part in xml_parts)


def _pixels(image) -> set:
    """Distinct RGB colours of an image (without Pillow's deprecated getdata)."""
    import numpy as np
    return {tuple(px) for px in np.asarray(image.convert("RGB")).reshape(-1, 3).tolist()}
