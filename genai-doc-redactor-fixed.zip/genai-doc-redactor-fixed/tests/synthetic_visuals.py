"""Synthetic ID-card pages with a photo, QR code, barcode and signature.

All data is fictional. The portrait is scikit-image's bundled public-domain
"astronaut" sample (NASA); the QR code is made with OpenCV; the EAN-13
barcode and the signature are drawn here.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

_L = ["0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011"]
_R = ["".join("1" if c == "0" else "0" for c in code) for code in _L]
_G = [code[::-1] for code in _R]
_PARITY = ["LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"]


def ean13(digits12: str, module: int = 3, height: int = 90) -> Image.Image:
    total = sum(int(d) * (3 if i % 2 else 1) for i, d in enumerate(digits12))
    digits = digits12 + str((10 - total % 10) % 10)
    bits = "101"
    for d, parity in zip(digits[1:7], _PARITY[int(digits[0])]):
        bits += (_L if parity == "L" else _G)[int(d)]
    bits += "01010" + "".join(_R[int(d)] for d in digits[7:]) + "101"
    quiet = 10
    width = (len(bits) + 2 * quiet) * module
    image = Image.new("L", (width, height + 2 * module * 4), 255)
    draw = ImageDraw.Draw(image)
    for i, bit in enumerate(bits):
        if bit == "1":
            x = (quiet + i) * module
            draw.rectangle([x, module * 4, x + module - 1, module * 4 + height], fill=0)
    return image.convert("RGB")


def qr(text: str, size: int = 220) -> Image.Image:
    import cv2
    code = cv2.QRCodeEncoder.create().encode(text)
    code = np.pad(code, 4, constant_values=255)
    return Image.fromarray(code).resize((size, size), Image.NEAREST).convert("RGB")


def portrait(size: tuple[int, int] = (260, 320)) -> Image.Image:
    from skimage import data
    face = Image.fromarray(data.astronaut()).crop((130, 10, 330, 250))
    return face.resize(size)


def _font(size: int):
    for name in ("arial.ttf", "DejaVuSans.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


ROWS = [
    ("Full Name", "Ananya Mehta"),
    ("Date of Birth", "14 August 1998"),
    ("Gender", "Female"),
    ("Address", "42 Lakeview Road, Coimbatore, Tamil Nadu 641018"),
    ("Phone Number", "+91 90000 12345"),
]


def card_png(path: Path, extra_lines: list[str] | None = None) -> Path:
    """A scanned-style card (PNG): text, photo, QR code, barcode, signature."""
    page = Image.new("RGB", (1700, 1100), "white")
    draw = ImageDraw.Draw(page)
    draw.text((80, 60), "DEMO TEST IDENTITY CARD", fill="black", font=_font(44))
    for i, (label, value) in enumerate(ROWS):
        y = 180 + i * 80
        draw.text((80, y), label, fill="black", font=_font(32))
        draw.text((420, y), value, fill="black", font=_font(32))
    for i, line in enumerate(extra_lines or []):
        draw.text((80, 620 + i * 50), line, fill="black", font=_font(26))
    page.paste(portrait(), (1340, 150))
    page.paste(qr("DEMO ID 4827 1936 5041"), (1360, 620))
    page.paste(ean13("890123456789"), (80, 900))
    draw.text((900, 900), "Signature", fill="black", font=_font(30))
    xs = np.linspace(1080, 1330, 60)
    ys = 920 + 18 * np.sin(xs / 9.0) + 10 * np.cos(xs / 23.0)
    draw.line(list(zip(xs, ys)), fill="black", width=4)
    page.save(path)
    return path


def card_pdf(path: Path, hidden_text: str | None = None, visible_extra: str | None = None) -> Path:
    """A text PDF card with an embedded photo and QR code."""
    import io
    import pymupdf as fitz
    doc = fitz.open()
    pdf_page = doc.new_page(width=842, height=595)
    pdf_page.insert_text((40, 50), "DEMO TEST IDENTITY CARD", fontsize=20)
    for i, (label, value) in enumerate(ROWS):
        y = 110 + i * 34
        pdf_page.insert_text((40, y), label, fontsize=13)
        pdf_page.insert_text((200, y), value, fontsize=13)
    if visible_extra:
        pdf_page.insert_text((40, 330), visible_extra, fontsize=11)
    if hidden_text:
        # White, tiny text: invisible to a reader, visible to text extraction.
        pdf_page.insert_text((40, 360), hidden_text, fontsize=6, color=(1, 1, 1))
    for image, rect in ((portrait(), fitz.Rect(640, 80, 780, 250)), (qr("DEMO ID 4827"), fitz.Rect(660, 330, 780, 450))):
        buffer = io.BytesIO()
        image.save(buffer, "PNG")
        pdf_page.insert_image(rect, stream=buffer.getvalue())
    doc.save(path)
    doc.close()
    return path
