"""Tests for local-only processing, retention, DOCX input, reviewed selections,
the ingestion cache, the output leak check and batch mode.

All documents are synthetic and the local model is never called.
"""
from __future__ import annotations

import csv
import io
import json
import os
import socket
import time
import tomllib
import zipfile
from pathlib import Path

import pytest

import pipeline
from agents.llm_client import LLMClient
from batch import process_batch
from redaction.leak_check import verify_protected_output
from utils import network_guard, retention
from utils.file_utils import validate_file
from utils.ui_state import request_signature

fitz = pytest.importorskip("pymupdf")
docx = pytest.importorskip("docx")

ROOT = Path(__file__).parent.parent
PERSON = [
    "Name: Rahul Kumar",
    "Phone: 9876543210",
    "Email: rahul@example.com",
    "Address: Coimbatore, Tamil Nadu",
    "Date of Birth: 15/08/2002",
]
SECRET_VALUES = ["Rahul Kumar", "9876543210", "rahul@example.com", "15/08/2002"]


def make_pdf(path: Path, lines: list[str]) -> Path:
    doc = fitz.open()
    page = doc.new_page()
    for i, line in enumerate(lines):
        page.insert_text((72, 100 + i * 28), line, fontsize=13)
    doc.save(path)
    doc.close()
    return path


def make_docx(path: Path) -> Path:
    document = docx.Document()
    document.add_heading("Customer Profile", 1)
    for line in PERSON:
        document.add_paragraph(line)
    table = document.add_table(rows=3, cols=3)
    rows = [("Item", "Quantity", "Price"), ("Ergonomic Mouse", "2", "$40.00"), ("USB Hub", "1", "$25.50")]
    for r, row in enumerate(rows):
        for c, value in enumerate(row):
            table.cell(r, c).text = value
    document.save(path)
    return path


@pytest.fixture(scope="module")
def person_pdf(tmp_path_factory) -> Path:
    return make_pdf(tmp_path_factory.mktemp("local") / "person.pdf", PERSON)


@pytest.fixture(scope="module")
def person_docx(tmp_path_factory) -> Path:
    return make_docx(tmp_path_factory.mktemp("local") / "profile.docx")


def run(path: Path, query: str, **kwargs) -> pipeline.PipelineResult:
    kwargs.setdefault("llm_mode", "Off")
    kwargs.setdefault("output_format", "PNG")
    result = pipeline.process_document(path, query, **kwargs)
    assert result.error is None, result.error
    return result


# ── Local-only network guard ──────────────────────────────────────────────

@pytest.mark.parametrize("host,local", [
    ("localhost", True), ("127.0.0.1", True), ("127.8.9.1", True), ("::1", True), ("[::1]", True),
    (None, True), ("app.localhost", True),
    ("example.com", False), ("8.8.8.8", False), ("192.168.1.10", False), ("ollama.example.org", False),
])
def test_is_local_host(host, local):
    assert network_guard.is_local_host(host) is local


@pytest.fixture
def guard():
    was_enabled = network_guard.is_enabled()
    network_guard.enable()
    try:
        yield network_guard
    finally:
        if not was_enabled:
            network_guard.disable()


def test_guard_blocks_dns_and_connections_outside_this_machine(guard):
    before = guard.blocked_count()
    with pytest.raises(network_guard.NonLocalConnectionBlocked):
        socket.getaddrinfo("example.com", 443)
    with pytest.raises(network_guard.NonLocalConnectionBlocked):
        socket.create_connection(("93.184.216.34", 80), timeout=1)
    assert guard.blocked_count() == before + 2


def test_guard_blocks_http_libraries(guard):
    requests = pytest.importorskip("requests")
    with pytest.raises(requests.exceptions.ConnectionError):
        requests.get("https://example.com", timeout=2)


def test_guard_allows_loopback(guard):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    try:
        port = server.getsockname()[1]
        socket.getaddrinfo("localhost", port)
        client = socket.create_connection(("127.0.0.1", port), timeout=2)
        client.close()
    finally:
        server.close()


def test_guard_can_be_disabled():
    network_guard.enable()
    network_guard.disable()
    assert not network_guard.is_enabled()
    network_guard._audit("socket.getaddrinfo", ("example.com", 80, 0, 0, 0))  # no exception


def test_llm_client_refuses_remote_ollama(monkeypatch):
    from agents import llm_client
    monkeypatch.setattr(llm_client, "OLLAMA_BASE_URL", "http://203.0.113.5:11434")
    with pytest.raises(ValueError, match="loopback"):
        LLMClient()


def test_easyocr_never_downloads_by_default():
    import config
    assert config.ALLOW_MODEL_DOWNLOADS is False or os.getenv("ALLOW_MODEL_DOWNLOADS")
    source = (ROOT / "ocr" / "easyocr_engine.py").read_text(encoding="utf-8")
    assert "download_enabled=ALLOW_MODEL_DOWNLOADS" in source


def test_streamlit_serves_this_machine_only_and_sends_no_usage_stats():
    settings = tomllib.loads((ROOT / ".streamlit" / "config.toml").read_text(encoding="utf-8"))
    assert settings["server"]["address"] == "127.0.0.1"
    assert settings["browser"]["gatherUsageStats"] is False


def test_pipeline_runs_with_guard_on(guard, person_pdf):
    before = guard.blocked_count()
    result = run(person_pdf, "I only need the address")
    assert result.decision.answer == "Coimbatore, Tamil Nadu"
    assert guard.blocked_count() == before  # nothing tried to leave the machine


# ── Retention ─────────────────────────────────────────────────────────────

def test_purge_removes_only_expired_files(tmp_path, monkeypatch):
    uploads, outputs, temp = (tmp_path / n for n in ("uploads", "outputs", "temp"))
    for folder in (uploads, outputs, temp):
        folder.mkdir()
    monkeypatch.setattr(retention, "_managed_dirs", lambda: (uploads, outputs, temp))
    old, new, keep = uploads / "old.pdf", outputs / "new.pdf", outputs / ".gitkeep"
    for path in (old, new, keep):
        path.write_bytes(b"x")
    hour_ago = time.time() - 3600
    os.utime(old, (hour_ago, hour_ago))
    os.utime(keep, (hour_ago, hour_ago))
    assert retention.purge_expired(max_age_minutes=30) == 1
    assert not old.exists() and new.exists() and keep.exists()
    assert retention.purge_expired(max_age_minutes=0) == 0  # disabled


def test_delete_files_stays_inside_app_folders(tmp_path, monkeypatch):
    uploads = tmp_path / "uploads"
    uploads.mkdir()
    monkeypatch.setattr(retention, "_managed_dirs", lambda: (uploads,))
    inside, outside = uploads / "a.pdf", tmp_path / "user_file.pdf"
    inside.write_bytes(b"x")
    outside.write_bytes(b"x")
    assert retention.delete_files([inside, outside, None]) == 1
    assert not inside.exists() and outside.exists()


# ── DOCX input ────────────────────────────────────────────────────────────

def test_docx_upload_is_accepted():
    assert validate_file("profile.docx", 1000) == (True, "")


def test_docx_address_query(person_docx):
    result = run(person_docx, "I only need the address", output_format="PDF")
    assert result.decision.answer == "Coimbatore, Tamil Nadu"
    assert result.document.file_type == "docx"
    assert result.leak_check["status"] == "passed"
    with fitz.open(str(result.output_path)) as pdf:
        assert "".join(page.get_text() for page in pdf).strip() == ""


def test_docx_table_and_multi_field_queries(person_docx):
    assert run(person_docx, "what is the price of the USB hub").decision.answer == "$25.50"
    answer = run(person_docx, "phone and date of birth").decision.answer
    assert "9876543210" in answer and "15/08/2002" in answer
    assert "rahul@example.com" not in answer


def test_docx_temp_layout_is_removed(person_docx):
    import config
    before = set(config.TEMP_DIR.glob("*.pdf"))
    run(person_docx, "address")
    assert set(config.TEMP_DIR.glob("*.pdf")) <= before


# ── Reviewed selection ────────────────────────────────────────────────────

def _field_id(result, label):
    return next(f.field_id for f in result.fields if f.label == label)


def test_reviewed_selection_replaces_matching(person_pdf):
    first = run(person_pdf, "I only need the address")
    phone, email = _field_id(first, "Phone"), _field_id(first, "Email")
    reviewed = run(person_pdf, "I only need the address", disclose_field_ids={phone, email, "bogus"})
    assert reviewed.selected_field_ids == {phone, email}
    assert "9876543210" in reviewed.decision.answer and "rahul@example.com" in reviewed.decision.answer
    assert "Coimbatore" not in reviewed.decision.answer
    assert reviewed.audit_report["selection"] == "reviewed by user"
    assert reviewed.query_diagnostics["requested_segments"][0]["match_method"] == "manual"


def test_reviewed_empty_selection_discloses_nothing(person_pdf):
    result = run(person_pdf, "I only need the address", disclose_field_ids=set())
    assert result.selected_field_ids == set()
    assert not any(
        d.action.is_keep() and d.category == "QUERY_RELEVANT" for d in result.decision.decisions
    )


def test_reviewed_selection_is_honoured_in_maximum_mode(person_pdf):
    first = run(person_pdf, "address")
    name = _field_id(first, "Name")
    result = run(person_pdf, "address", disclose_field_ids={name}, privacy_mode="Maximum")
    assert result.decision.answer == "Rahul Kumar"


# ── Ingestion cache ───────────────────────────────────────────────────────

def test_ingest_cache_reuses_extraction(person_pdf, tmp_path, monkeypatch):
    calls = []
    real_ingest = pipeline._ingest
    monkeypatch.setattr(pipeline, "_ingest", lambda *a: calls.append(a) or real_ingest(*a))
    cache: dict = {}
    first = run(person_pdf, "address", ingest_cache=cache)
    second = run(person_pdf, "phone number", ingest_cache=cache)
    assert len(calls) == 1
    assert first.decision.answer == "Coimbatore, Tamil Nadu"
    assert second.decision.answer == "9876543210"
    other = make_pdf(tmp_path / "other.pdf", ["Phone: 1112223333"])
    assert run(other, "phone", ingest_cache=cache).decision.answer == "1112223333"
    assert len(calls) == 2


# ── Output leak check ─────────────────────────────────────────────────────

def test_leak_check_detects_text_layer(tmp_path):
    leaky = make_pdf(tmp_path / "leaky.pdf", ["Phone: 9876543210"])
    report = verify_protected_output(leaky, [], ["9876543210"], ["Phone"])
    assert report["status"] == "failed" and report["file_leaks"] == 1


def test_leak_check_ignores_values_that_are_meant_to_be_visible(tmp_path):
    shown = make_pdf(tmp_path / "shown.pdf", ["Address: Coimbatore"])
    report = verify_protected_output(shown, [], ["Coimbatore"], ["Coimbatore"])
    assert report["status"] == "passed" and report["values_checked"] == 0


def test_leak_check_reads_docx_attributes(tmp_path):
    path = tmp_path / "leaky.docx"
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("word/document.xml", '<w:document><wp:docPr descr="Card 4111111111111111"/></w:document>')
    report = verify_protected_output(path, [], ["4111111111111111"], [])
    assert report["status"] == "failed"


def test_leak_check_report_has_no_values(person_pdf):
    result = run(person_pdf, "address", output_format="DOCX")
    assert result.leak_check["status"] == "passed"
    assert result.leak_check["values_checked"] >= 3
    flat = repr(result.leak_check) + repr(result.audit_report["output_check"])
    assert not any(value in flat for value in SECRET_VALUES)


def test_failed_leak_check_withholds_the_file(person_pdf, monkeypatch):
    monkeypatch.setattr(pipeline, "verify_protected_output", lambda *a, **k: {
        "status": "failed", "values_checked": 1, "file_leaks": 1, "ocr_checked": False, "ocr_leaks": 0,
    })
    result = pipeline.process_document(person_pdf, "address", llm_mode="Off", output_format="PDF")
    assert result.error and "Safety check failed" in result.error
    assert result.output_path is None


def test_ocr_verification_passes_on_real_output(person_pdf):
    pytest.importorskip("easyocr")
    result = run(person_pdf, "I only need the address", verify_output=True)
    assert result.leak_check["ocr_checked"] is True
    assert result.leak_check["status"] == "passed"


# ── Batch mode ────────────────────────────────────────────────────────────

def test_batch_produces_zip_with_outputs_audits_and_answers(tmp_path, person_pdf, person_docx):
    broken = tmp_path / "broken.pdf"
    broken.write_bytes(b"not a pdf")
    files = [("person.pdf", person_pdf), ("profile.docx", person_docx), ("broken.pdf", broken)]
    seen = []
    batch = process_batch(
        files, "I only need the address", progress=lambda d, t, n: seen.append((d, t)),
        llm_mode="Off", output_format="PDF",
    )
    assert [r.status for r in batch.rows] == ["protected", "protected", "failed"]
    assert seen[-1] == (3, 3)
    with zipfile.ZipFile(batch.zip_path) as archive:
        names = set(archive.namelist())
        assert {"protected/person_protected.pdf", "protected/profile_protected.pdf",
                "audit/person_protected.json", "audit/profile_protected.json", "answers.csv"} <= names
        rows = list(csv.DictReader(io.StringIO(archive.read("answers.csv").decode("utf-8"))))
    assert [r["answer"] for r in rows[:2]] == ["Coimbatore, Tamil Nadu"] * 2
    assert rows[2]["status"] == "failed"
    batch.zip_path.unlink()


def test_batch_names_do_not_collide(tmp_path, person_pdf):
    batch = process_batch(
        [("a.pdf", person_pdf), ("a.pdf", person_pdf)], "phone", llm_mode="Off", output_format="PNG",
    )
    with zipfile.ZipFile(batch.zip_path) as archive:
        protected = sorted(n for n in archive.namelist() if n.startswith("protected/"))
    assert protected == ["protected/a_protected.png", "protected/a_protected_2.png"]
    batch.zip_path.unlink()


# ── UI state ──────────────────────────────────────────────────────────────

def test_signature_tracks_review_and_verification():
    base = dict(upload_digest="d", query="address", privacy_mode="Strict", redaction_mode="blackout",
                output_format="PDF", model="m", llm_mode="Auto")
    plain = request_signature(**base)
    assert request_signature(**base, reviewed_field_ids={"a"}) != plain
    assert request_signature(**base, reviewed_field_ids=set()) != plain
    assert request_signature(**base, reviewed_field_ids={"a", "b"}) == request_signature(
        **base, reviewed_field_ids={"b", "a"})
    assert request_signature(**base, verify_output=True) != plain


# ── Labels that end in a qualifier word ───────────────────────────────────

def test_multiword_label_above_value_is_not_split(tmp_path):
    """"Phone Number" on its own line is one label, not label "Phone" + value "Number"."""
    card = make_pdf(tmp_path / "card.pdf", [
        "Full Name", "Ananya Mehta", "Phone Number", "+91 90000 12345",
        "Email Address", "ananya.mehta.demo@example.com",
    ])
    result = run(card, "What is the phone number?")
    assert result.decision.answer == "+91 90000 12345"
    labels = {f.label for f in result.fields}
    assert {"Phone Number", "Email Address"} <= labels
    assert run(card, "email").decision.answer == "ananya.mehta.demo@example.com"


def test_label_plus_value_on_one_line_still_splits():
    from ingestion.field_extractor import _lexicon_split
    assert _lexicon_split("Phone 9876543210")[:2] == ("Phone", "9876543210")
    assert _lexicon_split("Phone Number") is None
    assert _lexicon_split("Email Address") is None


# ── OCR quirks on scanned forms ───────────────────────────────────────────

def test_semicolon_inside_value_is_not_a_label_separator():
    from ingestion.document_model import DocumentElement
    from ingestion.field_extractor import split_inline_key_value_spans
    el = DocumentElement(id="e1", text="42 Lakeview Road, Green Park; Coimbatore, Tamil Nadu 641018",
                         bbox=[0, 0, 600, 20])
    assert [e.text for e in split_inline_key_value_spans([el])] == [el.text]
    named = DocumentElement(id="e2", text="Phone; 9876543210", bbox=[0, 0, 300, 20])
    assert len(split_inline_key_value_spans([named])) == 2  # a real field word still splits


def test_question_lines_in_a_document_are_never_answers(tmp_path):
    doc = make_pdf(tmp_path / "faq.pdf", [
        "Suggested test queries", "What is the address?", "What is the passport number?",
        "This page lists questions only and contains no personal values at all.",
    ])
    for query in ("I only need the address", "passport number"):
        answer = run(doc, query).decision.answer
        assert "?" not in answer.replace("'", "") or "not found" in answer, answer
        assert "What is" not in answer


# ── Local REST API ────────────────────────────────────────────────────────

@pytest.fixture
def api_client(monkeypatch):
    pytest.importorskip("httpx")
    from starlette.testclient import TestClient
    import api
    monkeypatch.setattr(api, "API_TOKEN", "")
    return api, TestClient(api.app)


def test_api_health_reports_local_only(api_client):
    api, client = api_client
    body = client.get("/health").json()
    assert body["status"] == "ok" and body["local_only"] is True


def test_api_protect_returns_answer_and_file_and_keeps_nothing(api_client, person_pdf):
    import base64
    import config
    api, client = api_client
    before = set(config.UPLOAD_DIR.iterdir()) | set(config.OUTPUT_DIR.iterdir())
    with open(person_pdf, "rb") as handle:
        response = client.post("/protect", files={"file": ("person.pdf", handle, "application/pdf")},
                               data={"question": "I only need the address", "ai_mode": "Off",
                                     "verify_output": "false", "output_format": "PDF"})
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["answer"] == "Coimbatore, Tamil Nadu"
    assert body["disclosed_fields"] == {"Address": "Coimbatore, Tamil Nadu"}
    assert body["output_check"]["status"] == "passed"
    assert base64.b64decode(body["file_base64"])[:4] == b"%PDF"
    assert "Rahul" not in json.dumps(body["audit"])
    after = set(config.UPLOAD_DIR.iterdir()) | set(config.OUTPUT_DIR.iterdir())
    assert after <= before  # upload and output were deleted


def test_api_validates_input(api_client):
    api, client = api_client
    assert client.post("/protect", data={"question": "x"}).status_code == 400
    bad = client.post("/protect", files={"file": ("a.exe", b"MZ", "application/octet-stream")},
                      data={"question": "address"})
    assert bad.status_code == 400 and "Unsupported" in bad.json()["error"]


def test_api_token_is_enforced_when_set(api_client, monkeypatch):
    api, client = api_client
    monkeypatch.setattr(api, "API_TOKEN", "s3cret")
    assert client.get("/health").status_code == 401
    assert client.get("/health", headers={"Authorization": "Bearer s3cret"}).status_code == 200


def test_api_refuses_non_loopback_host():
    import api
    assert api._is_loopback("127.0.0.1") and api._is_loopback("localhost")
    assert not api._is_loopback("0.0.0.0")


# ── PII category corrections ──────────────────────────────────────────────

def test_digit_group_ids_are_not_dates():
    from ingestion.document_model import DocumentElement
    from pii.presidio_detector import detect_pii_in_elements
    els = [DocumentElement(id=str(i), text=t, bbox=[0, 0, 1, 1])
           for i, t in enumerate(["4827 1936 5041", "14 August 1998", "15/08/2002"])]
    types = [e.entity_type for e in detect_pii_in_elements(els)]
    assert types == ["ID_NUMBER", "DATE", "DATE"]


def test_label_named_field_type_wins_over_conflicting_guess(person_pdf):
    result = run(person_pdf, "phone")
    phone = next(f for f in result.fields if f.label == "Phone")
    assert phone.sensitivity == ["PHONE"]
