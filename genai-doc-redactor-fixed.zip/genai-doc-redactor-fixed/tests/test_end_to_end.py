"""End-to-end tests using synthetic documents (no LLM required)."""
import sys
import json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import numpy as np
from PIL import Image, ImageDraw
from ingestion.document_model import DocumentElement, DocumentPage, DocumentRepresentation
from agents.schemas import PrivacyDecisionResponse, FieldDecision, RedactionAction
from agents.privacy_agent import _parse_llm_response
from pii.presidio_detector import detect_pii_in_elements
from redaction.image_redactor import redact_image
from rendering.document_viewer import get_privacy_summary
from rendering.document_viewer import add_secure_document_heading
from utils.document_type import infer_document_type


def _build_synthetic_doc() -> DocumentRepresentation:
    """Build a synthetic medical document."""
    elements = [
        DocumentElement(id="f01", text="John Doe", bbox=[50, 50, 200, 75], page=1),
        DocumentElement(id="f02", text="March 15, 1985", bbox=[50, 80, 250, 105], page=1),
        DocumentElement(id="f03", text="(555) 987-6543", bbox=[50, 110, 250, 135], page=1),
        DocumentElement(id="f04", text="john.doe@email.com", bbox=[50, 140, 300, 165], page=1),
        DocumentElement(id="f05", text="456 Oak Street, Springfield", bbox=[50, 170, 350, 195], page=1),
        DocumentElement(id="f06", text="PT-2024-88421", bbox=[50, 200, 250, 225], page=1),
        DocumentElement(id="f07", text="Type 2 Diabetes Mellitus", bbox=[50, 260, 350, 285], page=1),
        DocumentElement(id="f08", text="Metformin 500mg", bbox=[50, 290, 250, 315], page=1),
        DocumentElement(id="f09", text="Dr. Sarah Williams", bbox=[50, 320, 250, 345], page=1),
    ]
    page = DocumentPage(page=1, width=400, height=400, elements=elements)
    return DocumentRepresentation(
        document_id="test_001", filename="test.pdf", file_type="pdf", pages=[page]
    )


def test_full_pipeline_without_llm():
    """Simulate the full pipeline using a mock LLM response."""
    doc = _build_synthetic_doc()

    # Step 1: PII detection
    detect_pii_in_elements(doc.pages[0].elements)
    pii_elements = [el for el in doc.all_elements() if el.entity_type]
    assert len(pii_elements) >= 3  # Should detect name, phone, email at minimum

    # Step 2: Simulate LLM decision (as if LLM returned this)
    mock_llm_response = json.dumps({
        "answer": "The patient has Type 2 Diabetes Mellitus and is prescribed Metformin 500mg.",
        "decisions": [
            {"field_id": "f01", "action": "REDACT", "category": "PERSON", "reason": "Personal identifier"},
            {"field_id": "f02", "action": "REDACT", "category": "DATE", "reason": "Date of birth"},
            {"field_id": "f03", "action": "REDACT", "category": "PHONE", "reason": "Contact info"},
            {"field_id": "f04", "action": "REDACT", "category": "EMAIL", "reason": "Contact info"},
            {"field_id": "f05", "action": "REDACT", "category": "ADDRESS", "reason": "Location"},
            {"field_id": "f06", "action": "REDACT", "category": "ID_NUMBER", "reason": "Patient ID"},
            {"field_id": "f07", "action": "VISIBLE", "category": "DIAGNOSIS", "reason": "Requested by user"},
            {"field_id": "f08", "action": "VISIBLE", "category": "MEDICATION", "reason": "Requested by user"},
            {"field_id": "f09", "action": "REDACT", "category": "PERSON", "reason": "Doctor name, not requested"},
        ],
        "summary": "Showed diagnosis and medication, redacted all personal identifiers.",
    })

    all_ids = {el.id for el in doc.all_elements()}
    decision = _parse_llm_response(
        mock_llm_response,
        all_ids,
        elements=doc.all_elements(),
        user_query="Show me the diagnosis and medication",
    )
    assert isinstance(decision, PrivacyDecisionResponse)
    assert len(decision.decisions) == 9

    # Verify correct decisions
    actions = {d.field_id: d.action for d in decision.decisions}
    assert actions["f07"].is_keep()   # diagnosis
    assert actions["f08"].is_keep()   # medication
    assert actions["f01"] == RedactionAction.REDACT    # name
    assert actions["f03"] == RedactionAction.REDACT    # phone

    # Step 3: Apply redaction to a synthetic image
    img = Image.new("RGB", (400, 400), "white")
    redact_ids = {d.field_id for d in decision.decisions if d.action == RedactionAction.REDACT}
    elements_to_redact = [el for el in doc.all_elements() if el.id in redact_ids]
    assert len(elements_to_redact) == 7

    redacted_img = redact_image(img, elements_to_redact, mode="blackout")
    assert redacted_img.size == (400, 400)

    # Step 4: Privacy summary
    summary = get_privacy_summary(decision)
    assert summary["visible_count"] == 2
    assert summary["redacted_count"] == 7
    assert "DIAGNOSIS" in summary["categories_shown"]
    assert "PERSON" in summary["categories_hidden"]


def test_privacy_summary_structure():
    decision = PrivacyDecisionResponse(
        answer="Test",
        decisions=[
            FieldDecision(field_id="f1", action=RedactionAction.KEEP, category="DATA", reason="needed"),
            FieldDecision(field_id="f2", action=RedactionAction.REDACT, category="PERSON", reason="PII"),
            FieldDecision(field_id="f3", action=RedactionAction.REDACT, category="EMAIL", reason="PII"),
        ],
        summary="Test summary",
    )
    summary = get_privacy_summary(decision)
    assert summary["total_fields"] == 3
    assert summary["visible_count"] == 1
    assert summary["redacted_count"] == 2
    assert "PERSON" in summary["categories_hidden"]
    assert "EMAIL" in summary["categories_hidden"]
    assert "DATA" in summary["categories_shown"]


def test_secured_document_type_heading_is_added():
    elements = [
        DocumentElement(id="title", text="CERTIFICATE OF BIRTH", bbox=[0, 0, 180, 25]),
    ]
    document_type = infer_document_type(elements)
    assert document_type == "Birth Certificate"

    image = Image.new("RGB", (200, 300), "white")
    secured = add_secure_document_heading(image, document_type)
    assert secured.width == image.width
    assert secured.height > image.height


def test_kidney_score_keeps_the_whole_matching_line():
    """A matching query keeps all fields on that line and answers with the score."""
    elements = [
        DocumentElement(id="k1", text="kidney", bbox=[40, 80, 120, 105], page=1),
        DocumentElement(id="k2", text="11", bbox=[130, 80, 160, 105], page=1),
        DocumentElement(id="k3", text="(45.8)", bbox=[170, 80, 230, 105], page=1),
        DocumentElement(id="h1", text="hemoglobin", bbox=[40, 120, 160, 145], page=1),
        DocumentElement(id="h2", text="14.2", bbox=[170, 120, 220, 145], page=1),
        DocumentElement(id="p1", text="John Doe", bbox=[40, 20, 160, 45], page=1, entity_type="PERSON"),
        DocumentElement(id="p2", text="555-0188", bbox=[170, 20, 280, 45], page=1, entity_type="PHONE"),
    ]
    page = DocumentPage(page=1, width=400, height=200, elements=elements)
    doc = DocumentRepresentation(
        document_id="kidney_001", filename="labs.png", file_type="png", pages=[page]
    )

    # Simulate the failing behavior: LLM redacts almost every OCR span.
    mock_llm_response = json.dumps({
        "answer": "Unable to determine the requested value.",
        "decisions": [
            {"field_id": "k1", "action": "REDACT", "category": "TEXT", "reason": "Not needed"},
            {"field_id": "k2", "action": "REDACT", "category": "NUMBER", "reason": "Not needed"},
            {"field_id": "k3", "action": "REDACT", "category": "NUMBER", "reason": "Not needed"},
            {"field_id": "h1", "action": "REDACT", "category": "TEXT", "reason": "Not needed"},
            {"field_id": "h2", "action": "REDACT", "category": "NUMBER", "reason": "Not needed"},
            {"field_id": "p1", "action": "REDACT", "category": "PERSON", "reason": "PII"},
            {"field_id": "p2", "action": "REDACT", "category": "PHONE", "reason": "PII"},
        ],
        "summary": "Redacted everything.",
    })

    decision = _parse_llm_response(
        mock_llm_response,
        {el.id for el in elements},
        elements=elements,
        user_query="kidney score",
    )

    visible_text = {
        el.text for el in doc.all_elements()
        if any(d.field_id == el.id and d.action.is_keep() for d in decision.decisions)
    }
    actions = {d.field_id: d.action for d in decision.decisions}

    assert "kidney" in visible_text
    assert "11" in visible_text
    assert any("45.8" in t for t in visible_text)
    assert actions["k1"] == RedactionAction.KEEP
    assert actions["k2"] == RedactionAction.KEEP
    assert actions["k3"] == RedactionAction.KEEP
    assert actions["p1"] == RedactionAction.REDACT
    assert actions["p2"] == RedactionAction.REDACT
    assert actions["h1"] == RedactionAction.IGNORE
    assert actions["h2"] == RedactionAction.IGNORE
    assert decision.answer.strip() == "45.8%"

    redact_ids = {d.field_id for d in decision.decisions if d.action.should_hide_on_render()}
    img = Image.new("RGB", (400, 200), "white")
    redacted_img = redact_image(
        img,
        [el for el in elements if el.id in redact_ids],
        mode="blackout",
    )
    assert redacted_img.size == (400, 200)




def test_brain_tumor_query_keeps_the_whole_matching_row():
    elements = [
        DocumentElement(id="b1", text="brain tumors", bbox=[40, 80, 180, 105], page=1),
        DocumentElement(id="b2", text="3", bbox=[500, 80, 530, 105], page=1),
        DocumentElement(id="b3", text="(1.1)", bbox=[550, 80, 610, 105], page=1),
        DocumentElement(id="o1", text="bone and soft tissue tumors", bbox=[40, 120, 240, 145], page=1),
        DocumentElement(id="o2", text="6", bbox=[500, 120, 530, 145], page=1),
        DocumentElement(id="o3", text="(2.3)", bbox=[550, 120, 610, 145], page=1),
    ]
    ids = {e.id for e in elements}
    raw = json.dumps({
        "answer": "1.1%",
        "decisions": [],
        "summary": "",
    })
    decision = _parse_llm_response(raw, ids, elements=elements, user_query="brain tumor")
    actions = {d.field_id: d.action for d in decision.decisions}
    assert actions["b1"] == RedactionAction.KEEP
    assert actions["b3"] == RedactionAction.KEEP
    assert actions["b2"] == RedactionAction.KEEP
    assert actions["o1"] == RedactionAction.HIDE
    assert actions["o2"] == RedactionAction.HIDE
    assert actions["o3"] == RedactionAction.HIDE
    assert decision.answer == "1.1%"

def test_kidney_score_render_hides_unrelated_content():
    """Regression: render path must hide every non-KEEP span."""
    elements = [
        DocumentElement(id="kidney", text="kidney", bbox=[40, 40, 120, 70], page=1),
        DocumentElement(id="score", text="(45.8)", bbox=[160, 40, 230, 70], page=1),
        DocumentElement(id="other", text="lung", bbox=[40, 100, 100, 130], page=1),
        DocumentElement(id="other_value", text="13.3", bbox=[160, 100, 220, 130], page=1),
    ]
    raw = json.dumps({
        "answer": "45.8%",
        "decisions": [
            {"field_id": "kidney", "action": "KEEP", "category": "TEXT", "reason": "query"},
            {"field_id": "score", "action": "KEEP", "category": "NUMBER", "reason": "query"},
            {"field_id": "other", "action": "HIDE", "category": "NON_SENSITIVE", "reason": "unrelated"},
            {"field_id": "other_value", "action": "HIDE", "category": "NON_SENSITIVE", "reason": "unrelated"},
        ],
        "summary": "Selective disclosure",
    })
    decision = _parse_llm_response(
        raw,
        {el.id for el in elements},
        elements=elements,
        user_query="kidney score",
    )

    # Simulate the pipeline's actual render selection.
    hide_ids = {
        d.field_id for d in decision.decisions
        if d.action.should_hide_on_render()
    }
    assert hide_ids == {"other", "other_value"}

    img = Image.new("RGB", (300, 180), "white")
    draw = ImageDraw.Draw(img)
    draw.rectangle([40, 40, 120, 70], fill="black")
    draw.rectangle([160, 40, 230, 70], fill="black")
    draw.rectangle([40, 100, 100, 130], fill="black")
    draw.rectangle([160, 100, 220, 130], fill="black")

    redacted = redact_image(
        img,
        [el for el in elements if el.id in hide_ids],
        mode="blackout",
    )
    arr = np.array(redacted)

    # Unrelated content is hidden.
    assert all(c == 0 for c in arr[115, 70])
    assert all(c == 0 for c in arr[115, 190])

    # Requested content remains untouched.
    assert all(c == 0 for c in arr[55, 70])  # original requested marker
    assert all(c == 0 for c in arr[55, 190])


def test_kidney_score_single_ocr_span():
    """OCR may return the whole row as one span: 'kidney 11 (45.8)'."""
    elements = [
        DocumentElement(id="row", text="kidney 11 (45.8)", bbox=[40, 80, 280, 110], page=1),
        DocumentElement(id="name", text="Jane Patient", bbox=[40, 20, 200, 45], page=1, entity_type="PERSON"),
    ]
    raw = json.dumps({
        "answer": "",
        "decisions": [
            {"field_id": "row", "action": "REDACT", "category": "TEXT", "reason": "unused"},
            {"field_id": "name", "action": "REDACT", "category": "PERSON", "reason": "PII"},
        ],
        "summary": "",
    })
    decision = _parse_llm_response(
        raw, {"row", "name"}, elements=elements, user_query="kidney score"
    )
    actions = {d.field_id: d.action for d in decision.decisions}
    assert actions["row"] == RedactionAction.KEEP
    assert actions["name"] == RedactionAction.REDACT
    assert "kidney" in elements[0].text
    assert "11" in elements[0].text
    assert "45.8" in elements[0].text
    assert decision.answer.strip() == "45.8%"
