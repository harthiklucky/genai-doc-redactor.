"""Tests for the image redaction engine."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
from PIL import Image, ImageDraw
from ingestion.document_model import DocumentElement
from redaction.image_redactor import redact_image, selective_disclosure_image


def _white_image(w=400, h=300) -> Image.Image:
    return Image.new("RGB", (w, h), (255, 255, 255))


def _make_element(id: str, bbox: list[float]) -> DocumentElement:
    return DocumentElement(id=id, text="REDACT_ME", bbox=bbox)


def test_blackout_modifies_region():
    img = _white_image()
    el = _make_element("f1", [50, 50, 150, 80])
    result = redact_image(img, [el], mode="blackout")
    arr = np.array(result)
    # The center of the redacted region should be black
    center_pixel = arr[65, 100]
    assert all(c == 0 for c in center_pixel), f"Expected black, got {center_pixel}"


def test_blackout_preserves_outside():
    img = _white_image()
    el = _make_element("f1", [50, 50, 150, 80])
    result = redact_image(img, [el], mode="blackout")
    arr = np.array(result)
    # Top-left corner should still be white
    corner = arr[5, 5]
    assert all(c == 255 for c in corner), f"Expected white, got {corner}"


def test_blur_modifies_region():
    img = _white_image()
    # Draw some black text-like content
    arr = np.array(img)
    arr[55:75, 60:140] = 0  # black rectangle simulating text
    img = Image.fromarray(arr)

    el = _make_element("f1", [50, 50, 150, 80])
    result = redact_image(img, [el], mode="blur")
    result_arr = np.array(result)
    # After blur, the hard edge should be softened (not pure 0 or 255 at boundary)
    edge_pixel = result_arr[55, 55]
    assert not all(c == 0 for c in edge_pixel), "Blur should soften edges"


def test_pixelate_modifies_region():
    img = _white_image()
    arr = np.array(img)
    arr[55:75, 60:140] = [128, 64, 32]
    img = Image.fromarray(arr)

    el = _make_element("f1", [50, 50, 150, 80])
    result = redact_image(img, [el], mode="pixelate")
    result_arr = np.array(result)
    # The region should be modified (pixelated blocks)
    assert result_arr.shape == arr.shape


def test_no_elements_returns_copy():
    img = _white_image()
    result = redact_image(img, [], mode="blackout")
    assert np.array_equal(np.array(img), np.array(result))


def test_multiple_regions():
    img = _white_image()
    elements = [
        _make_element("f1", [10, 10, 80, 30]),
        _make_element("f2", [200, 100, 350, 130]),
    ]
    result = redact_image(img, elements, mode="blackout")
    arr = np.array(result)
    assert all(c == 0 for c in arr[20, 40])    # first region
    assert all(c == 0 for c in arr[115, 275])   # second region
    assert all(c == 255 for c in arr[150, 150]) # outside both


def test_scale_factors():
    img = _white_image(800, 600)
    # Element bbox is in a coordinate system half the image size
    el = _make_element("f1", [25, 25, 75, 40])
    result = redact_image(img, [el], mode="blackout", scale_x=2.0, scale_y=2.0)
    arr = np.array(result)
    # Scaled bbox: [50, 50, 150, 80] in image coords
    assert all(c == 0 for c in arr[65, 100])



def test_selective_disclosure_hides_entire_unrelated_page():
    img = Image.new("RGB", (200, 100), "white")
    draw = ImageDraw.Draw(img)
    draw.text((10, 10), "kidney", fill="black")
    draw.text((10, 50), "unrelated secret", fill="black")
    keep = [DocumentElement(id="k", text="kidney", bbox=[8, 8, 70, 28], page=1)]

    out = selective_disclosure_image(img, keep, padding=2)

    # Requested region retains source pixels.
    assert out.getpixel((20, 18)) == img.getpixel((20, 18))
    # Unrelated content is blanked, not merely unredacted.
    assert out.getpixel((50, 58)) == (255, 255, 255)


def test_selective_disclosure_blurs_sensitive_fields_on_kept_lines():
    img = Image.new("RGB", (180, 90), "white")
    draw = ImageDraw.Draw(img)
    draw.text((10, 10), "Name", fill="black")
    draw.text((75, 10), "Jane Doe", fill="black")
    draw.text((10, 55), "Unrelated", fill="black")
    keep = [DocumentElement(id="label", text="Name", bbox=[8, 8, 50, 30])]
    sensitive = [DocumentElement(id="name", text="Jane Doe", bbox=[72, 8, 140, 30])]

    out = selective_disclosure_image(img, keep, blur_elements=sensitive, padding=2)

    assert out.crop((8, 8, 50, 30)).tobytes() == img.crop((8, 8, 50, 30)).tobytes()
    assert out.crop((72, 8, 140, 30)).tobytes() != img.crop((72, 8, 140, 30)).tobytes()
    assert out.getpixel((20, 60)) == (255, 255, 255)


def test_mixed_sensitive_ocr_field_keeps_its_label_and_blurs_only_value():
    img = Image.new("RGB", (300, 60), "white")
    draw = ImageDraw.Draw(img)
    draw.text((12, 12), "Name:", fill="black")
    draw.text((115, 12), "Jane Doe", fill="black")
    field = DocumentElement(
        id="name_line",
        text="Name: Jane Doe",
        bbox=[10, 10, 260, 32],
        entity_type="PERSON",
        sensitive_spans=[(6, 14)],
    )

    out = selective_disclosure_image(img, [field], blur_elements=[field], padding=2)

    assert out.crop((10, 10, 80, 32)).tobytes() == img.crop((10, 10, 80, 32)).tobytes()
    assert out.crop((115, 10, 220, 32)).tobytes() != img.crop((115, 10, 220, 32)).tobytes()
