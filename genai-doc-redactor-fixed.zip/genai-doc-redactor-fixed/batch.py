"""Batch mode: one question, many documents, one ZIP of protected results."""
from __future__ import annotations

import csv
import io
import json
import uuid
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from config import OUTPUT_DIR
from pipeline import process_document
from utils.logging_utils import get_logger

logger = get_logger("batch")

MAX_BATCH_FILES = 50


@dataclass
class BatchRow:
    file_name: str
    status: str  # "protected" or "failed"
    answer: str = ""
    disclosed_fields: int = 0
    pages: int = 0
    seconds: float = 0.0
    message: str = ""


@dataclass
class BatchResult:
    rows: list[BatchRow] = field(default_factory=list)
    zip_path: Path | None = None


def _unique_name(name: str, used: set[str]) -> str:
    stem, suffix = Path(name).stem, Path(name).suffix
    candidate, n = name, 2
    while candidate.lower() in used:
        candidate = f"{stem}_{n}{suffix}"
        n += 1
    used.add(candidate.lower())
    return candidate


def process_batch(
    files: list[tuple[str, Path]],
    user_query: str,
    progress=None,
    **settings,
) -> BatchResult:
    """Protect every file for the same request.

    ``files`` holds (original file name, saved path) pairs. ``settings`` are
    passed through to ``process_document`` (privacy_mode, redaction_mode,
    output_format, llm_mode, llm_model, verify_output). ``progress`` is an
    optional callback ``progress(done, total, file_name)``.
    """
    batch = BatchResult()
    if not files:
        return batch
    files = files[:MAX_BATCH_FILES]
    zip_path = OUTPUT_DIR / f"batch_protected_{uuid.uuid4().hex[:8]}.zip"
    used_names: set[str] = set()

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for index, (name, path) in enumerate(files):
            if progress:
                progress(index, len(files), name)
            result = process_document(path, user_query, **settings)
            row = BatchRow(
                file_name=name,
                status="failed" if result.error or not result.output_path else "protected",
                seconds=round(result.processing_time, 1),
                pages=len(result.redacted_images),
            )
            if row.status == "protected":
                row.answer = result.decision.answer
                row.disclosed_fields = len(result.selected_field_ids)
                out_name = _unique_name(
                    f"{Path(name).stem}_protected{result.output_path.suffix}", used_names,
                )
                archive.write(result.output_path, f"protected/{out_name}")
                audit_name = Path(out_name).with_suffix(".json").name
                archive.writestr(
                    f"audit/{audit_name}",
                    json.dumps(result.audit_report, ensure_ascii=False, indent=2),
                )
                result.output_path.unlink(missing_ok=True)
            else:
                row.message = result.error or "No protected output was produced."
            batch.rows.append(row)

        table = io.StringIO()
        writer = csv.writer(table)
        writer.writerow(["file", "status", "answer", "disclosed_fields", "pages", "seconds", "message"])
        for row in batch.rows:
            writer.writerow([row.file_name, row.status, row.answer, row.disclosed_fields,
                             row.pages, row.seconds, row.message])
        archive.writestr("answers.csv", table.getvalue())
    if progress:
        progress(len(files), len(files), "")

    batch.zip_path = zip_path
    logger.info(
        "Batch complete: %d file(s), %d protected, %d failed",
        len(batch.rows), sum(r.status == "protected" for r in batch.rows),
        sum(r.status == "failed" for r in batch.rows),
    )
    return batch
