# 🛡️ Context-Aware GenAI Privacy-Preserving Document Agent

A local-first privacy application that creates protected document copies from natural-language requests. Requested values can remain visible, recognized field labels are preserved, unrequested key/value values are protected, and unrelated page content is hidden. Choose Standard, Strict, or Maximum privacy mode and Solid Mask, Blur, or Replacement Text. The protected pages can be downloaded as PDF, DOCX, PNG, or JPG. Multi-page raster output is packaged as a ZIP containing one protected image per page.

## Problem Statement

Organizations handle documents containing sensitive personal information daily — medical records, invoices, employee files. When a user needs specific information from such a document, traditional approaches either:
1. **Show everything** — exposing unnecessary sensitive data
2. **Redact everything** — hiding information the user legitimately needs

This project solves the middle ground: **context-aware selective disclosure**, where an AI agent decides what to show based on the user's actual information need.

## Why This Matters

- **Data Minimization**: Only expose what's necessary (GDPR/HIPAA principle)
- **Contextual Privacy**: The same document field may be visible or hidden depending on the query
- **Semantic Understanding**: Goes beyond pattern matching — the AI understands *why* information is needed
- **Deterministic Enforcement**: The LLM decides, but a deterministic engine enforces — no LLM hallucination can leak data

## Architecture

```
USER QUERY + DOCUMENT
        │
        ▼
┌─────────────────────┐
│  Document Ingestion  │  PDF text extraction / Image loading
└────────┬────────────┘
         ▼
┌─────────────────────┐
│    OCR Engine        │  PaddleOCR / Tesseract (with bounding boxes)
└────────┬────────────┘
         ▼
┌─────────────────────┐
│  PII Detection       │  Microsoft Presidio (entity classification)
│  (Metadata Layer)    │
└────────┬────────────┘
         ▼
┌─────────────────────┐
│  Structured Document │  Unified field-level representation
│  Representation      │  (ID, text, bbox, entity_type, page)
└────────┬────────────┘
         ▼
┌─────────────────────┐
│  GenAI Privacy Agent │  ◄── THE CORE: LLM semantic decision-making
│  (LLM)               │  Understands query + context + sensitivity
│                       │  Returns structured JSON: VISIBLE / REDACT
└────────┬────────────┘
         ▼
┌─────────────────────┐
│  Disclosure Renderer │  Copies approved bounding boxes onto a blank page
└────────┬────────────┘
         ▼
┌─────────────────────┐
│  Output Generation   │  Redacted PDF + page images
└────────┬────────────┘
         ▼
     Streamlit UI
  (Before/After + Downloads)
```

## How GenAI Is Central

The LLM is **not** an afterthought — it is the semantic decision-making layer:

1. **Receives**: User query + structured document fields (with PII annotations)
2. **Understands**: What the user is asking for, what each field contains, and its sensitivity
3. **Decides**: For each field → VISIBLE / REDACT / UNCERTAIN
4. **Explains**: Provides reasoning for each decision
5. **Answers**: Generates an answer using only permitted information

The LLM output is **validated** (Pydantic schema), and returned IDs must exist in the extracted document. A requested sensitive value may be disclosed when it directly answers the query; unrequested sensitive values remain protected. The deterministic renderer uses a new canvas and never places an overlay on top of the original pixels. DOCX output contains only protected page images, not the source document.

For `Label: Value`, `Label - Value`, clear multi-space separators, `Label Value` for common field types (e.g. `Phone 9876543210`), labels with the value on the following line(s), two-cell rows, and header + data-row tables, the ingestion step separates label and value boxes. When OCR returns a label and value in one box, the split is first estimated from character positions and then snapped to the real whitespace gap on the page; if no clear gap exists the conservative estimate is kept.

### How a request is resolved

1. The request is split into requested parts ("address and phone number" → "address", "phone number"); text after "except", "but not", "without" … is excluded.
2. Each part is matched against extracted field labels (and synonyms of common field types such as phone/mobile, DOB/date of birth). Longer phrases win, so "email address" selects the Email field only. Every distinctive word of the request must be explained by the chosen field, so "passport number" does not match a "Phone Number" field. Several plausible candidates ("name" with Patient Name and Doctor Name) are reported as ambiguous and nothing is disclosed for them.
3. **AI analysis** setting: *Auto* (default) consults the local Qwen2.5 7B model only for parts that no label matches (e.g. "where does this person live?"); *Always* consults it on every request; *Off* never does. Model-selected IDs must exist, may never override a deterministic match or an exclusion, are rejected when they contradict a field type the request names, and are ignored below 0.6 confidence.
4. The answer is built only from the disclosed field values; missing parts are reported as not found.

Privacy modes: **Strict** (default) discloses only the requested fields and keeps other field labels readable; **Maximum** also hides other labels and never discloses a sensitive value on model judgement alone; **Standard** additionally shows non-sensitive values on the requested row and allows "everything except …" requests. The result view includes measured sensitive-field counts, extraction confidence, a concise decision explanation, and an optional audit JSON that omits user-entered query text and protected values.

## Technologies Used

| Component | Technology |
|-----------|-----------|
| **UI** | Streamlit |
| **Document Processing** | PyMuPDF (fitz) |
| **OCR** | EasyOCR (primary), PaddleOCR / Tesseract (alternatives) |
| **PII Detection** | Microsoft Presidio |
| **NLP** | spaCy (en_core_web_lg) |
| **GenAI** | Ollama (local, Qwen2.5 7B) |
| **Image Processing** | Pillow, OpenCV |
| **Validation** | Pydantic v2 |
| **PDF Generation** | Pillow PDF, ReportLab (demos) |
| **DOCX Output** | Minimal OOXML package (written with `zipfile`) containing only protected page images |
| **Testing** | pytest |

## Installation

### Prerequisites
- Python 3.10+
- [Ollama](https://ollama.com/) (for local LLM mode)

### Setup

```bash
# Clone the project
cd genai-doc-redactor

# Create virtual environment
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # Linux/Mac

# Install dependencies
pip install -r requirements.txt

# One-time model setup (the only step that uses the internet):
# EasyOCR models, the spaCy model for Presidio, and an Ollama model check
python setup_models.py

# Copy environment config
copy .env.example .env       # Windows
# cp .env.example .env       # Linux/Mac
```

### Ollama Setup

```bash
# Install Ollama from https://ollama.com/

# Pull a model (recommended: qwen2.5:7b)
ollama pull qwen2.5:7b

# Start Ollama server (if not already running)
ollama serve
```

Alternative models that work well:
- `llama3.1:8b`
- `gemma2:9b`
- `mistral:7b`

### Generate Demo Documents

```bash
python demo_documents/generate_samples.py
```

## Running the Application

```bash
python -m streamlit run app.py
```

On Windows machines where Application Control blocks `streamlit.exe`, this form (through `python`) still works.

Input formats: PDF (text or scanned), DOCX, PNG, JPG and JPEG. Output formats: PDF, DOCX, PNG and JPG. Multi-page PNG/JPG downloads are ZIP bundles.

Word documents are laid out locally as a text PDF (paragraphs and tables in document order) and then processed like any PDF. Embedded images, headers/footers, text boxes and the original fonts/spacing are not reproduced.

Then open http://localhost:8501 in your browser. The UI is served on `127.0.0.1` only (see `.streamlit/config.toml`).

### Features in the UI

- **Single document**: ask a question, get the answer and a protected copy.
- **Review and adjust what is disclosed**: after an analysis, tick or untick the extracted fields (names only, never values) and apply. Your selection replaces the automatic one.
- **Batch (many files)**: one question for up to 50 documents; download one ZIP with the protected files, a privacy audit per file and `answers.csv`.
- **Answer as JSON**: download only the disclosed values.
- **Follow-up questions are fast**: extraction for the current file is cached in memory for the browser session, so a new question skips OCR and PII detection.
- **Delete my files now**: removes this session's uploads and outputs immediately.
- **Downloads live in memory**: each protected file is read into the browser session's memory and deleted from disk as soon as it is made.

### Advanced privacy features

- **Answers that reveal less than the field** (`agents/derived_answers.py`): "Is she over 18?" → *Yes*; "How old is she?" / "age range" / "year of birth"; "Which city?" / "state" / "PIN code" from the address; "last 4 digits of the phone number" → *ending 2345* (never more than 4 digits or half the number); "email domain". Computed in code from the verified field; the field itself stays hidden in the output.
- **Re-identification risk score** (`agents/risk.py`): estimates how identifying the disclosed items are *together* (bits of identifying information; ~28+ bits single out one person in 1.4 billion). Date of birth + gender + PIN code scores **High** even with the name hidden. Shows reasons and safer alternatives ("ask for the birth year instead").
- **Photos, QR codes, barcodes, signatures** (`ingestion/visual_detector.py`): found locally with OpenCV and PyMuPDF, hidden by default with a labelled placeholder ("PHOTO HIDDEN"), shown only on request ("show the photo") or via the review checklist. The output check confirms a hidden QR code cannot be scanned from the output.
- **Hidden-instruction detector** (`agents/injection_detector.py`): flags text aimed at an AI ("ignore previous instructions", "do not redact", prompt markup) in visible text and inside QR codes, and removes invisible text (white-on-white, microscopic, off-page) before processing. For such documents the local model is not consulted and the suspicious text is never disclosed.
- **Traceable copies** (`redaction/watermark.py`): enter "Who is this copy for?" and every page gets an invisible, keyed watermark (survives the JPEG compression in PDF/JPG outputs). "Trace a copy" mode (and `POST /trace`) reads it back and names the recipient from a local ledger (`data/`, never document values).

### Local REST API

Other programs on this computer can use the same agent:

```bash
python api.py
```

It listens on `http://127.0.0.1:8600` only (it refuses another address while `LOCAL_ONLY` is on). Set `API_TOKEN` in `.env` to require `Authorization: Bearer <token>`.

- `GET /health`: local-only status and whether Ollama is reachable.
- `POST /protect` (multipart form): `file`, `question`, and optionally `privacy_mode`, `style` (solid/blur/replacement), `output_format`, `ai_mode` (Auto/Always/Off), `verify_output`, `recipient` (traceable copy). Returns the answer, the disclosed field values, computed answers, the re-identification risk, security warnings, photos/codes found, the output check, the privacy audit and the protected file as base64. The upload and the generated file are deleted before the response is sent.
- `POST /trace` (multipart form): `file` — a protected copy; returns who it was made for.

```bash
curl -F file=@demo_documents/invoice.pdf -F "question=What is the invoice total?" http://127.0.0.1:8600/protect
```

### Accuracy benchmark

```bash
python benchmark.py              # text documents
python benchmark.py --scanned    # plus scanned (OCR) copies
python benchmark.py --ai         # plus paraphrases answered by the local model
```

Each case lists the values the answer must contain and the sensitive values that must never appear; a case passes only when the answer is right, nothing forbidden is disclosed and the output check passes.

## Example Queries

### Medical Report
- "Show me the patient's diagnosis and medication."
- "What symptoms did the patient present with?"

### Invoice
- "What is the invoice total and invoice date?"
- "Show me the order details but hide all customer information."

### Employee Record
- "What is the employee's salary and department?"
- "Show me the employment details but hide personal contact information."

## Expected Outputs

For query: *"Show me the diagnosis and medication"* on a medical report:

| Field | Decision | Reason |
|-------|----------|--------|
| Patient Name | 🔴 REDACT | Personal identifier, not requested |
| Date of Birth | 🔴 REDACT | Personal identifier |
| Phone | 🔴 REDACT | Contact information |
| Email | 🔴 REDACT | Contact information |
| Patient ID | 🔴 REDACT | Identifier |
| **Diagnosis** | 🟢 **VISIBLE** | **Directly requested** |
| **Medication** | 🟢 **VISIBLE** | **Directly requested** |
| Doctor Name | 🔴 REDACT | Not requested |

## Security Design

### Privacy-First Architecture
1. **Detect** potential sensitive information (Presidio)
2. **Assign** every element a unique ID with bounding box
3. **Let GenAI select** which fields may be visible (structured JSON)
4. **Validate** the response (Pydantic, safe defaults)
5. **Enforce deterministically** using pixel-level redaction
6. The original document is **never** the final output

### Prompt Injection Resistance
- Document content is treated as **untrusted data**
- System prompt, user query, and document content are **strictly separated**
- The LLM is instructed to never follow instructions found in document content
- Privacy decisions default to REDACT when uncertain

### Everything stays on this machine

- **Local-only mode** (`LOCAL_ONLY=true`, the default): a process-wide guard (`utils/network_guard.py`, a Python audit hook on `socket.connect` and `socket.getaddrinfo`) refuses every DNS lookup and connection to anything other than this computer. The local Ollama server is reachable; nothing else is. The sidebar shows the guard status and how many attempts were blocked.
- **Local model only**: the LLM client accepts only a loopback Ollama URL and refuses to start otherwise.
- **No run-time downloads**: EasyOCR loads its models from disk with downloads disabled; Hugging Face libraries are put in offline mode. Models are fetched once by `python setup_models.py`.
- **UI not exposed to the network**: Streamlit binds to `127.0.0.1` and usage statistics are off.
- **Retention**: generated files are removed from disk as soon as they are made (the UI and API keep them in memory for download); uploaded originals are deleted after `RETENTION_MINUTES` (default 60). Batch originals are deleted as soon as the batch finishes.
- **Output check before release**: every exported file is checked for protected values in its machine-readable text (PDF text layer and metadata, DOCX/ZIP XML and attributes, image text chunks and EXIF). With "Verify output with OCR" (on by default in the UI), the protected pages are also read back with local OCR. If any protected value is found, the file is deleted and not offered for download. The check reports counts only.

Not covered by the guard: native code that opens sockets without Python's `socket` module (none of this project's processing does), and the Ollama server process itself, which is a separate program on this machine.

### Logging Safety
- The application avoids logging extracted document text or model answers in normal processing paths.
- The `SensitiveFilter` suppresses a whole log message when it contains selected credential-related words. It is not a general PII detector and does not scrub arbitrary sensitive values from messages.

## Project Structure

```
genai-doc-redactor/
├── app.py                    # Streamlit UI
├── pipeline.py               # Main processing pipeline
├── batch.py                  # Batch mode (many files, one ZIP)
├── api.py                    # Local REST API (127.0.0.1 only)
├── benchmark.py              # Accuracy benchmark on synthetic documents
├── setup_models.py           # One-time offline model setup
├── config.py                 # Configuration from .env
├── requirements.txt
├── .env.example
├── agents/
│   ├── privacy_agent.py      # GenAI decision engine
│   ├── llm_client.py         # Local Ollama client
│   ├── derived_answers.py    # Answers that reveal less than the field
│   ├── risk.py               # Re-identification risk score
│   ├── injection_detector.py # Hidden instructions / invisible text
│   ├── prompts.py            # System + user prompts
│   └── schemas.py            # Pydantic response models
├── ingestion/
│   ├── document_model.py     # Unified document representation
│   ├── pdf_processor.py      # PDF text/image extraction
│   ├── docx_processor.py     # DOCX -> local text-PDF layout
│   ├── visual_detector.py    # Photos, QR codes, barcodes, signatures
│   └── image_processor.py    # Image loading
├── ocr/
│   ├── base_ocr.py           # OCR abstraction
│   ├── easyocr_engine.py      # EasyOCR implementation (default)
│   ├── paddle_ocr.py         # PaddleOCR alternative
│   ├── tesseract_ocr.py      # Tesseract alternative
│   └── factory.py            # OCR engine factory
├── pii/
│   └── presidio_detector.py  # Presidio PII detection
├── redaction/
│   ├── image_redactor.py     # Pixel-level redaction
│   ├── pdf_redactor.py       # PDF output generation
│   ├── leak_check.py         # Post-export check for readable protected values
│   └── watermark.py          # Traceable copies (invisible watermark + ledger)
├── rendering/
│   └── document_viewer.py    # Privacy summary for UI
├── utils/
│   ├── file_utils.py         # File handling
│   ├── network_guard.py      # Local-only mode: blocks non-local connections
│   ├── retention.py          # Automatic deletion of uploads/outputs
│   ├── document_type.py      # Document-type labels for secured copies
│   └── logging_utils.py      # Safe logging
├── tests/
│   ├── test_document_model.py
│   ├── test_pii.py
│   ├── test_agent.py
│   ├── test_redaction.py
│   ├── test_ocr.py
│   └── test_end_to_end.py
├── demo_documents/
│   └── generate_samples.py   # Synthetic document generator
├── uploads/                  # Temporary upload storage
├── outputs/                  # Redacted output files
└── temp/                     # Processing temp files
```

## Running Tests

`tests/test_novel_features.py` covers derived answers, the risk score, photo/QR/barcode/signature handling, the hidden-instruction detector and traceable copies.

`tests/test_local_privacy.py` covers local-only mode, retention, DOCX input, reviewed selections, the ingestion cache, the output check and batch mode.

The regression suite for query interpretation, field selection, model-output validation, exports and redaction integrity is `tests/test_query_disclosure.py`. Tests never call Ollama (the model is disabled or replaced with a scripted fake).

```bash
# All tests
pytest tests/ -v

# Skip tests requiring OCR/LLM
pytest tests/ -v -k "not paddle"

# Specific test file
pytest tests/test_redaction.py -v
```

## Limitations

- **LLM Quality**: Redaction decisions depend on the LLM's reasoning ability. Larger models produce better results.
- **OCR Accuracy**: Scanned documents depend on OCR quality; poor scans may miss text.
- **Complex Layouts**: Tables, multi-column layouts, and overlapping elements may not redact perfectly.
- **Language**: Currently optimized for English documents.
- **Document Size**: The LLM receives at most the first 200 extracted fields. Deterministic matching examines all extracted fields, but semantic analysis is not chunked and may miss context later in a large document.
- **No Handwriting**: Handwritten documents are not supported.

## Future Improvements

- **Vision Model Integration**: Use a multimodal LLM (GPT-4V, Gemma) to directly reason about document images
- **Custom Entity Types**: Let users define domain-specific PII categories
- **Confidence Visualization**: Heat-map overlay showing redaction confidence
- **Multi-language Support**: Extend OCR and PII detection beyond English
- **Template Learning**: Learn common document layouts for faster processing
- **API Endpoint**: REST API for integration with other systems

## Demo Workflow (for Course Presentation)

1. Start the application: `python -m streamlit run app.py`
2. Upload `demo_documents/medical_report.pdf`
3. Ask: "Show me the patient's diagnosis and medication"
4. Click "Analyze & Protect"
5. Show the Before/After comparison
6. Show the Privacy Summary (what was hidden and why)
7. Show the AI's explainability reasoning
8. Download the redacted PDF
9. Repeat with invoice.pdf: "What is the invoice total and date?"
10. Repeat with employee_record.pdf: "What is the salary and department?"

This demonstrates:
- **GenAI**: Semantic query understanding + contextual decision-making
- **Computer Vision**: OCR + bounding-box redaction
- **Privacy Engineering**: Data minimization + deterministic enforcement
- **Software Architecture**: Modular pipeline with clean separation of concerns
