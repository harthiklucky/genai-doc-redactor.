from __future__ import annotations
from enum import Enum
from pydantic import BaseModel, Field, field_validator


class RedactionAction(str, Enum):
    KEEP = "KEEP"
    DISCLOSE = "DISCLOSE"  # alias of KEEP
    VISIBLE = "VISIBLE"  # alias of KEEP (legacy)
    REDACT = "REDACT"
    HIDE = "HIDE"
    IGNORE = "HIDE"  # legacy name; same render semantics as HIDE
    UNCERTAIN = "UNCERTAIN"

    def is_keep(self) -> bool:
        return self in (
            RedactionAction.KEEP,
            RedactionAction.DISCLOSE,
            RedactionAction.VISIBLE,
        )

    def should_redact(self) -> bool:
        """True for sensitive redaction (PII/PHI), not ordinary hide."""
        return self == RedactionAction.REDACT

    def should_hide_on_render(self) -> bool:
        """Anything not explicitly disclosed is hidden in the output image."""
        return not self.is_keep()


class FieldDecision(BaseModel):
    field_id: str
    action: RedactionAction
    category: str = ""
    reason: str = ""

    @field_validator("action", mode="before")
    @classmethod
    def _normalize_action(cls, value):
        if not isinstance(value, str):
            return value
        key = value.strip().upper()
        if key in ("VISIBLE", "DISCLOSE"):
            return RedactionAction.KEEP
        if key == "IGNORE":
            return RedactionAction.HIDE
        return value


class LLMSemanticResult(BaseModel):
    """Structured semantic output from Qwen2.5 7B reasoning."""
    answer: str = Field(default="", description="Answer to the user query using only permitted document information")
    relevant_field_ids: list[str] = Field(default_factory=list, description="List of OCR field IDs directly relevant to the user query")
    relevant_value_ids: list[str] = Field(default_factory=list, description="OCR element IDs containing requested values")
    reasoning: str = Field(default="", description="Brief explanation of why these fields were selected")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0, description="Model confidence score between 0.0 and 1.0")
    decisions: list[FieldDecision] = Field(default_factory=list, description="Optional field-level decisions")

    @field_validator("confidence", mode="before")
    @classmethod
    def _normalize_confidence(cls, value):
        if value is None:
            return 1.0
        try:
            return float(value)
        except (ValueError, TypeError) as exc:
            raise ValueError("confidence must be numeric") from exc


class PrivacyDecisionResponse(BaseModel):
    """Enforced final document privacy decision."""
    answer: str = Field(description="Answer to the user's question using only permitted information")
    decisions: list[FieldDecision] = Field(default_factory=list)
    summary: str = Field(default="", description="Brief summary of what was redacted and why")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0, description="Confidence score")
    semantic_field_ids: list[str] = Field(default_factory=list, description="Validated semantic selections for field resolution")
    semantic_document_field_ids: list[str] = Field(default_factory=list, description="DocumentField IDs the model selected (IDs verified to exist)")
    llm_used: bool = Field(default=False, description="Whether the local model was consulted")
    llm_status: str = Field(default="", description="Outcome of the model call, without document content")
    llm_reasoning: str = Field(default="", description="Concise model explanation of its selection")
    llm_answer_verified: bool | None = Field(default=None, description="Whether the model's answer matched a verified document value")
