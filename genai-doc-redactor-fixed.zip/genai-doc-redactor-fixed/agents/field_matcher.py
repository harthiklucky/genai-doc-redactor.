"""Query interpretation and deterministic query-to-field matching.

The matcher works on extracted ``DocumentField`` objects (label/value pairs and
table cells), not on raw OCR lines, so a request for one field can never pull
in a neighbouring value from the same line.

Matching rules, in order of precedence:

1. The query is split into requested *segments* ("address and phone number"
   -> ["address", "phone number"]); text after a negation cue ("except",
   "but not", "without" ...) becomes an excluded segment.
2. A field fully matches a segment when one of its label phrases (the label
   itself, or an alias of the field type the label denotes) is contained in
   the segment.  Longer phrases win, so "email address" resolves to an Email
   field instead of also selecting an Address field.
3. Every distinctive word of the segment must be explained by the selected
   field(s).  Soft words (descriptors such as "patient", qualifiers such as
   "residential", generic nouns such as "number") may stay unexplained.  This
   is what stops "passport number" from matching a "Phone Number" field.
4. If no field fully matches, a field whose label contains every distinctive
   word of the segment is a partial match.  More than one plausible partial
   match is reported as ambiguous and nothing is disclosed for it.

The alias lexicon only describes common field *types*; arbitrary labels such
as "Certificate Number" or "Tax Amount" are matched from their own words.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field as dc_field

from agents.relevance import normalize_token, tokenize
from ingestion.document_model import DocumentField

# Words that never identify a field: request verbs, pronouns, function words.
STOP_WORDS = {
    "a", "an", "the", "of", "for", "to", "in", "on", "at", "by", "from", "as",
    "is", "are", "was", "were", "be", "been", "am", "do", "does", "did",
    "i", "me", "my", "mine", "we", "our", "you", "your", "it", "its", "this",
    "that", "these", "those", "there", "here", "s", "he", "she", "him", "her",
    "his", "they", "them", "their", "who", "whom", "whose", "what", "whats",
    "which", "where", "when", "how", "much", "many", "can", "could", "would",
    "will", "shall", "should", "may", "might", "must", "please", "kindly",
    "just", "only", "solely", "simply", "want", "wanted", "need", "needed",
    "require", "required", "like", "give", "show", "tell", "get", "find",
    "fetch", "retrieve", "extract", "return", "display", "provide", "share",
    "reveal", "disclose", "list", "print", "output", "read", "see", "view",
    "know", "let", "check", "look", "up", "mentioned", "mention", "stated",
    "listed", "written", "shown", "given", "document", "doc", "file", "form",
    "page", "pdf", "image", "copy", "keep", "visible", "include", "including",
    "field", "fields", "value", "values", "entry", "entries", "section",
    # How the requester will use a value ("reach her by phone").
    "reach", "call", "dial", "via", "through", "using",
}

# Words that may describe a requested field without having to occur in its
# label. Descriptors say whose field it is; qualifiers say which variant of it.
DESCRIPTOR_WORDS = {
    "patient", "person", "customer", "client", "employee", "user", "applicant",
    "holder", "member", "student", "individual", "candidate", "owner",
    "recipient", "buyer", "seller", "consumer", "subscriber",
    # Document-type words: "invoice total" is the total of this invoice.
    "invoice", "receipt", "bill", "statement", "report", "certificate", "policy",
}
QUALIFIER_WORDS = {
    "full", "complete", "entire", "whole", "current", "present", "residential",
    "home", "permanent", "postal", "mailing", "registered", "official",
    "primary", "exact", "actual", "corresponding", "respective", "specific",
    "listed", "detail", "info", "information", "data", "number", "particular",
    "amount", "figure",
    # Words that only ask for the value of a measurement ("HbA1c result").
    "result", "value", "reading", "level", "score",
}
SOFT_WORDS = DESCRIPTOR_WORDS | QUALIFIER_WORDS

# Words that are too generic to select a field on their own.
GENERIC_WORDS = {"number", "date", "type", "code", "amount", "status", "detail", "info", "information", "data"}

NEGATION_CUES = (
    "except for", "except", "excluding", "exclude", "without", "but not",
    "other than", "apart from", "not", "dont", "don't", "do not", "hide",
    "mask", "redact", "remove",
)
CONJUNCTIONS = r"\band\b|\bor\b|\bplus\b|\balso\b|\bas well as\b|\balong with\b|\btogether with\b|&|,|;|/"
ALL_WORDS = {"all", "everything", "every", "entire", "whole"}

# Common field types and their synonyms.  Each entry: concept -> (sensitivity
# category, phrases).  A label is mapped to a concept when its distinctive
# words equal one of the phrases.
FIELD_CONCEPTS: dict[str, tuple[str, tuple[str, ...]]] = {
    "email": ("EMAIL", ("email", "e mail", "email address", "e mail address", "mail id", "email id", "mail address")),
    "phone": ("PHONE", ("phone", "phone number", "mobile", "mobile number", "telephone", "telephone number",
                        "tel", "contact number", "cell", "cell number", "cell phone", "mobile phone", "contact no")),
    "dob": ("DATE_OF_BIRTH", ("date of birth", "dob", "birth date", "birthday", "birth")),
    "address": ("ADDRESS", ("address", "residential address", "home address", "residence", "permanent address",
                            "postal address", "mailing address", "current address", "present address")),
    "name": ("PERSON", ("name", "full name")),
    "age": ("PERSONAL", ("age",)),
    "gender": ("PERSONAL", ("gender", "sex")),
    "passport": ("ID_NUMBER", ("passport", "passport number", "passport id")),
    "ssn": ("ID_NUMBER", ("ssn", "social security number", "social security")),
    "salary": ("FINANCIAL", ("salary", "pay", "wage", "wages", "compensation", "ctc", "monthly salary", "annual salary")),
    "total": ("FINANCIAL", ("total", "grand total", "total amount", "amount due", "total due", "balance due")),
    "account": ("FINANCIAL", ("account number", "bank account", "account id", "iban")),
    "diagnosis": ("MEDICAL", ("diagnosis", "diagnose", "condition")),
    "blood_group": ("MEDICAL", ("blood group", "blood type")),
}

_NUMBER_SYNONYMS = {"no", "num", "nbr", "id", "nr"}
# Common abbreviations in labels and column headers.
_TOKEN_SYNONYMS = {
    "qty": "quantity", "amt": "amount", "dept": "department", "addr": "address",
    "tel": "telephone", "ph": "phone", "acct": "account", "desc": "description",
    "dt": "date", "yr": "year", "approx": "approximate",
}


def canonical_tokens(text: str) -> list[str]:
    """Lowercase, singularize, drop stop words, and unify number synonyms."""
    text = re.sub(r"[’']s\b", "", text or "")
    text = re.sub(r"\be-mail\b", "email", text, flags=re.IGNORECASE)
    tokens = []
    for raw in tokenize(text):
        token = normalize_token(raw)
        token = _TOKEN_SYNONYMS.get(token, token)
        if token in _NUMBER_SYNONYMS:
            token = "number"
        if token in STOP_WORDS or not token:
            continue
        tokens.append(token)
    return tokens


def _phrase_set(phrase: str) -> frozenset[str]:
    return frozenset(canonical_tokens(phrase))


_CONCEPT_SETS: dict[str, list[frozenset[str]]] = {
    concept: [_phrase_set(p) for p in phrases if _phrase_set(p)]
    for concept, (_, phrases) in FIELD_CONCEPTS.items()
}


def _distinctive(tokens) -> set[str]:
    # Bare numbers ("1" from "HbA1c", "8.25" from a rate) never name a field.
    return {t for t in tokens if t not in SOFT_WORDS and not t[0].isdigit()}


def field_concept(label: str) -> str | None:
    """Return the field type a label denotes, e.g. "Mobile No." -> "phone"."""
    tokens = set(canonical_tokens(label))
    if not tokens:
        return None
    for candidate in (frozenset(tokens), frozenset(_distinctive(tokens))):
        if not candidate:
            continue
        for concept, sets in _CONCEPT_SETS.items():
            if candidate in sets:
                return concept
    return None


def concept_category(concept: str | None) -> str | None:
    return FIELD_CONCEPTS[concept][0] if concept in FIELD_CONCEPTS else None


def segment_concepts(tokens: set[str]) -> set[str]:
    """Field types a query segment explicitly names (used to veto LLM picks)."""
    found = set()
    for concept, sets in _CONCEPT_SETS.items():
        if any(s and s <= tokens and _distinctive(s) for s in sets):
            found.add(concept)
    return found


# ─────────────────────────────────────────────────────────────────────────────
# Query parsing
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class QuerySegment:
    text: str
    tokens: list[str]

    @property
    def token_set(self) -> set[str]:
        return set(self.tokens)

    @property
    def distinctive(self) -> set[str]:
        return _distinctive(self.tokens)


@dataclass
class QueryIntent:
    segments: list[QuerySegment] = dc_field(default_factory=list)
    excluded: list[QuerySegment] = dc_field(default_factory=list)
    wants_all: bool = False


def _split_segments(text: str) -> list[QuerySegment]:
    segments = []
    for part in re.split(CONJUNCTIONS, text, flags=re.IGNORECASE):
        part = part.strip()
        tokens = canonical_tokens(part)
        tokens = [t for t in tokens if t not in ALL_WORDS]
        if tokens:
            # Readable form for messages: the user's own words minus filler.
            # Trim filler only at the edges so "date of birth" stays intact.
            words = re.findall(r"[A-Za-z0-9][A-Za-z0-9.'’/-]*", part)
            while words and (not canonical_tokens(words[0]) or words[0].lower() in ALL_WORDS):
                words.pop(0)
            while words and (not canonical_tokens(words[-1]) or words[-1].lower() in ALL_WORDS):
                words.pop()
            segments.append(QuerySegment(text=" ".join(words).strip(".?!") or part, tokens=tokens))
    return segments


def parse_query(query: str) -> QueryIntent:
    """Split a natural-language request into requested and excluded segments."""
    text = re.sub(r"\s+", " ", (query or "").strip())
    lowered = text.lower()
    cut = len(lowered)
    for cue in NEGATION_CUES:
        match = re.search(rf"\b{re.escape(cue)}\b", lowered)
        if match and match.start() < cut:
            cut = match.start()
    positive, negative = text[:cut], text[cut:]
    if negative:
        for cue in sorted(NEGATION_CUES, key=len, reverse=True):
            negative = re.sub(rf"^\s*{re.escape(cue)}\b", "", negative, flags=re.IGNORECASE)
    wants_all = bool(ALL_WORDS & {t.lower() for t in tokenize(positive)})
    return QueryIntent(
        segments=_split_segments(positive),
        excluded=_split_segments(negative),
        wants_all=wants_all,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Field matching
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class SegmentResolution:
    segment: str
    status: str  # "matched", "not_found", "ambiguous"
    field_ids: list[str] = dc_field(default_factory=list)
    match_type: str = ""  # exact_label, alias, partial_label, table_row, llm_semantic
    confidence: float = 0.0
    candidate_labels: list[str] = dc_field(default_factory=list)


@dataclass
class FieldMatchResult:
    intent: QueryIntent
    resolutions: list[SegmentResolution] = dc_field(default_factory=list)
    excluded_field_ids: set[str] = dc_field(default_factory=set)

    @property
    def selected_field_ids(self) -> set[str]:
        ids = set()
        for res in self.resolutions:
            if res.status == "matched":
                ids.update(res.field_ids)
        return ids - self.excluded_field_ids

    @property
    def unresolved(self) -> list[SegmentResolution]:
        return [r for r in self.resolutions if r.status != "matched"]


def display_label(field: DocumentField) -> str:
    row_label = getattr(field, "row_label", "") or ""
    return f"{row_label} — {field.label}" if row_label else field.label


def _field_label_sets(field: DocumentField) -> list[tuple[frozenset[str], str]]:
    """Label phrases that identify a field, with how each one was derived."""
    row_tokens = frozenset(canonical_tokens(getattr(field, "row_label", "") or ""))
    # Numbers in a label ("Tax (8.25%)") describe it but are never asked for.
    label_tokens = frozenset(t for t in canonical_tokens(field.label) if not t[0].isdigit())
    sets = []
    if label_tokens or row_tokens:
        sets.append((label_tokens | row_tokens, "exact_label"))
    concept = field_concept(field.label)
    if concept:
        # Synonyms keep the label's descriptor: "Patient Name" may be asked
        # for as "patient's full name", but not as just "name".
        descriptors = label_tokens & DESCRIPTOR_WORDS
        for alias in _CONCEPT_SETS[concept]:
            sets.append((alias | descriptors | row_tokens, "alias"))
    return sets


def _table_cell_match(field: DocumentField, segment: set[str]) -> tuple[frozenset[str], str] | None:
    """A table cell matches when its column header is requested and every
    other distinctive word of the request identifies its row."""
    header = frozenset(t for t in canonical_tokens(field.label) if not t[0].isdigit())
    row = set(canonical_tokens(f"{field.row_label} {getattr(field, 'row_context', '')}"))
    if not header or not header <= segment:
        return None
    rest = _distinctive(segment - header)
    if not rest or not rest <= row:
        return None
    return frozenset(header | rest), "exact_label"


def _best_full_match(field: DocumentField, segment: set[str]) -> tuple[frozenset[str], str] | None:
    if field.source_type == "table_cell" and (field.row_label or getattr(field, "row_context", "")):
        return _table_cell_match(field, segment)
    best = None
    for tokens, kind in _field_label_sets(field):
        if not tokens or not tokens <= segment:
            continue
        # A generic-only label ("Number", "Date") may only answer a segment
        # whose distinctive words it fully explains.
        if not (tokens - GENERIC_WORDS) and not _distinctive(segment) <= tokens:
            continue
        if best is None or len(tokens) > len(best[0]) or (
            len(tokens) == len(best[0]) and kind == "exact_label"
        ):
            best = (tokens, kind)
    return best


def _same_value(fields: list[DocumentField]) -> bool:
    return len({re.sub(r"\s+", " ", f.value.strip().lower()) for f in fields}) == 1


def _resolve_segment(segment: QuerySegment, fields: list[DocumentField]) -> SegmentResolution:
    seg_set = segment.token_set
    distinctive = segment.distinctive

    named = segment_concepts(seg_set)

    def conflicts(f: DocumentField) -> bool:
        # A field of a different known type than the one the request names
        # ("home address" vs an "Email Address" field) is never a match.
        concept = field_concept(f.label)
        return bool(named) and concept is not None and concept not in named

    # 1. Full matches, longest label phrase first.
    full = []
    for f in fields:
        if conflicts(f):
            continue
        match = _best_full_match(f, seg_set)
        if match:
            full.append((f, match[0], match[1]))
    groups: dict[frozenset[str], list[tuple[DocumentField, frozenset[str], str]]] = {}
    for item in full:
        groups.setdefault(item[1], []).append(item)

    chosen: list[tuple[DocumentField, frozenset[str], str]] = []
    covered: set[str] = set()
    ambiguous_groups: list[list[DocumentField]] = []
    for tokens in sorted(groups, key=len, reverse=True):
        group = groups[tokens]
        # A shorter phrase already explained by a longer match adds nothing
        # ("address" inside an "email address" match).
        if covered and not _distinctive(tokens - covered):
            continue
        group_fields = [item[0] for item in group]
        same_column = (
            len(group_fields) > 1
            and all(f.source_type == "table_cell" and not f.row_label for f in group_fields)
            and len({tuple(f.label_element_ids) for f in group_fields}) == 1
        )
        if len(group_fields) > 1 and not _same_value(group_fields) and not same_column:
            ambiguous_groups.append(group_fields)
            covered |= tokens
            continue
        chosen.extend(group)
        covered |= tokens

    leftover = distinctive - covered
    if chosen and not leftover and not ambiguous_groups:
        kinds = {kind for _, _, kind in chosen}
        return SegmentResolution(
            segment=segment.text, status="matched",
            field_ids=[f.field_id for f, _, _ in chosen],
            match_type="exact_label" if kinds == {"exact_label"} else "alias",
            confidence=0.95 if kinds == {"exact_label"} else 0.9,
        )
    if ambiguous_groups and not leftover:
        candidates = [f for group in ambiguous_groups for f in group]
        labels = sorted({display_label(f) for f in candidates})
        if len(labels) == 1:
            pages = sorted({f.page for f in candidates})
            where = f"page {pages[0]}" if len(pages) == 1 else "pages " + ", ".join(map(str, pages))
            labels = [f"{labels[0]} ×{len(candidates)} on {where}"]
        return SegmentResolution(segment=segment.text, status="ambiguous", candidate_labels=labels)

    # 2. Partial matches: the label contains every distinctive query word.
    if not distinctive:
        return SegmentResolution(segment=segment.text, status="not_found")
    partial = []
    for f in fields:
        if conflicts(f):
            continue
        for tokens, kind in _field_label_sets(f):
            if distinctive <= tokens:
                # Unrequested qualifiers ("Residential" Address) are harmless;
                # an unrequested descriptor or noun ("Doctor" Name) is a
                # different field the user did not single out.
                extra = tokens - seg_set - QUALIFIER_WORDS
                partial.append((len(extra), f))
                break
    if not partial:
        return SegmentResolution(segment=segment.text, status="not_found")
    best_extra = min(extra for extra, _ in partial)
    best = [f for extra, f in partial if extra == best_extra]
    rows = {(f.page, tuple(getattr(f, "row_label_element_ids", []) or [])) for f in best}
    same_table_row = (
        len(best) > 1 and len(rows) == 1 and all(f.source_type == "table_cell" for f in best)
        and next(iter(rows))[1]
    )
    if len(best) == 1 or same_table_row or _same_value(best):
        return SegmentResolution(
            segment=segment.text, status="matched",
            field_ids=[f.field_id for f in best],
            match_type="table_row" if same_table_row else "partial_label",
            confidence=0.75 if best_extra == 0 else 0.6,
        )
    return SegmentResolution(
        segment=segment.text, status="ambiguous",
        candidate_labels=sorted({display_label(f) for f in best}),
    )


def match_fields(fields: list[DocumentField], query: str | QueryIntent) -> FieldMatchResult:
    """Resolve each requested segment of a query to extracted document fields."""
    intent = parse_query(query) if isinstance(query, str) else query
    result = FieldMatchResult(intent=intent)
    for segment in intent.excluded:
        res = _resolve_segment(segment, fields)
        if res.status == "matched":
            result.excluded_field_ids.update(res.field_ids)
        elif res.status == "ambiguous":
            # Excluding is the privacy-safe direction: exclude every candidate.
            labels = set(res.candidate_labels)
            result.excluded_field_ids.update(
                f.field_id for f in fields if display_label(f) in labels or f.label in labels
            )
    for segment in intent.segments:
        result.resolutions.append(_resolve_segment(segment, fields))
    return result


# ─────────────────────────────────────────────────────────────────────────────
# LLM selection validation
# ─────────────────────────────────────────────────────────────────────────────

def validate_llm_field_selection(
    match: FieldMatchResult,
    fields: list[DocumentField],
    llm_field_ids: list[str],
    confidence: float,
    min_confidence: float = 0.6,
) -> tuple[list[SegmentResolution], list[str]]:
    """Use validated LLM picks only for segments deterministic matching left open.

    Returns updated resolutions and a list of human-readable rejection notes.
    The LLM can never override a segment that was matched deterministically,
    select an excluded field, select a nonexistent ID, or pick a field whose
    type contradicts a field type the segment names explicitly.
    """
    by_id = {f.field_id: f for f in fields}
    notes: list[str] = []
    valid_ids = []
    for fid in llm_field_ids:
        if fid not in by_id:
            notes.append("Rejected a field ID that does not exist in the document")
        elif fid in match.excluded_field_ids:
            notes.append(f"Rejected '{display_label(by_id[fid])}': excluded by the request")
        elif fid not in valid_ids:
            valid_ids.append(fid)

    already = match.selected_field_ids
    open_resolutions = match.unresolved
    if not open_resolutions:
        extra = [fid for fid in valid_ids if fid not in already]
        if extra:
            notes.append(f"Ignored {len(extra)} model selection(s) not supported by the request wording")
        return match.resolutions, notes
    if confidence < min_confidence:
        if valid_ids:
            notes.append(f"Model confidence {confidence:.2f} is below {min_confidence:.2f}; selections not used")
        return match.resolutions, notes

    candidates = [fid for fid in valid_ids if fid not in already]
    updated = []
    for res in match.resolutions:
        if res.status == "matched":
            updated.append(res)
            continue
        named = segment_concepts(set(canonical_tokens(res.segment)))
        picks = []
        for fid in candidates:
            f = by_id[fid]
            if res.status == "ambiguous" and display_label(f) not in res.candidate_labels and f.label not in res.candidate_labels:
                continue
            concept = field_concept(f.label)
            if named and concept not in named:
                notes.append(
                    f"Rejected '{display_label(f)}' for '{res.segment}': the request names a different field type"
                )
                continue
            picks.append(fid)
        # Ambiguity is resolved only when the model commits to one candidate.
        if res.status == "ambiguous" and len(picks) != 1:
            updated.append(res)
            continue
        if picks and len(picks) <= 3:
            updated.append(SegmentResolution(
                segment=res.segment, status="matched", field_ids=picks,
                match_type="llm_semantic", confidence=round(min(confidence, 0.85), 2),
            ))
            candidates = [fid for fid in candidates if fid not in picks]
        else:
            updated.append(res)
    return updated, notes


# ─────────────────────────────────────────────────────────────────────────────
# Answer construction
# ─────────────────────────────────────────────────────────────────────────────

NOT_FOUND_ANSWER = "No relevant information found in the document for the specified query."


def build_answer(
    resolutions: list[SegmentResolution],
    fields: list[DocumentField],
    excluded_ids: set[str] | None = None,
    extra_lines: list[str] | None = None,
    low_confidence_threshold: float = 0.5,
) -> str:
    """Compose the answer only from verified, disclosed field values."""
    excluded_ids = excluded_ids or set()
    by_id = {f.field_id: f for f in fields}
    found: list[DocumentField] = []
    notes: list[str] = []
    for res in resolutions:
        if res.status == "matched":
            for fid in res.field_ids:
                if fid in by_id and fid not in excluded_ids and by_id[fid] not in found:
                    found.append(by_id[fid])
        elif res.status == "ambiguous":
            notes.append(
                f"'{res.segment}' matches more than one field ({', '.join(res.candidate_labels)}). "
                "Please specify which one; nothing was disclosed for it."
            )
        else:
            notes.append(f"'{res.segment}' was not found in the document.")

    lines = []
    extra_lines = [line for line in (extra_lines or []) if line]
    if len(found) == 1 and not extra_lines and not notes:
        lines.append(found[0].value)
    else:
        lines.extend(f"{display_label(f)}: {f.value}" for f in found)
    lines.extend(extra_lines)
    low = [display_label(f) for f in found if f.confidence and f.confidence < low_confidence_threshold]
    if low:
        notes.append(f"Low text-recognition confidence for {', '.join(low)}; verify against the original.")
    if not lines and not notes:
        return NOT_FOUND_ANSWER
    if not lines and all("not found" in n for n in notes):
        return NOT_FOUND_ANSWER if len(notes) > 1 else notes[0]
    return "\n".join(lines + notes)
