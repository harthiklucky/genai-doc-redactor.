"""Re-identification risk of what a protected copy discloses.

Hiding the name is not enough: a date of birth, gender and PIN code together
single out most people (Sweeney, 2000: 87% of the US population is unique on
5-digit ZIP, gender and date of birth). This module estimates how identifying
the disclosed items are *together*.

Method: each disclosed item contributes an estimated number of bits of
identifying information (log2 of how many distinct values it splits people
into). A population of about 1.4 billion needs ~30.4 bits to single out one
person. Direct identifiers (name, phone, email, ID numbers, full address,
photo) identify someone on their own.

The estimate is deliberately simple and conservative; it is a warning, not a
guarantee. Only item kinds are used, never values.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

POPULATION = 1.4e9
UNIQUE_BITS = math.log2(POPULATION)  # ~30.4
# Well before every person is unique, most are: at ~28 bits a combination
# singles out the large majority (DOB + gender + PIN is ~30 bits).
HIGH_BITS = 28.0
MEDIUM_BITS = 18.0

# Bits of identifying information per quasi-identifier.
QUASI_BITS = {
    "dob": 15.1,           # ~100 years x 365 days
    "postal_code": 14.2,   # ~19,000 Indian PIN codes / ~41,000 US ZIP codes
    "city": 9.0,
    "birth_year": 6.6,
    "age": 6.6,
    "state": 5.0,
    "age_band": 4.3,
    "last_digits": 4.0,    # partial number: weak on its own
    "email_domain": 3.0,
    "gender": 1.0,
    "age_check": 1.0,
}
DIRECT = {
    "name": "a name identifies the person directly",
    "email": "an email address identifies the person directly",
    "phone": "a phone number identifies the person directly",
    "address": "a full address identifies the household directly",
    "passport": "an ID number identifies the person directly",
    "ssn": "an ID number identifies the person directly",
    "account": "an account number identifies the person directly",
    "id_number": "an ID number identifies the person directly",
    "photo": "a face photo identifies the person directly",
    "signature": "a signature identifies the person directly",
    "qr": "a QR code can encode the full record",
    "barcode": "a barcode can encode an identifier",
}
SENSITIVE_ATTRIBUTES = {"MEDICAL": "health information", "FINANCIAL": "financial information"}
SUGGESTIONS = {
    "dob": "Ask 'Is the person over 18?' or for the birth year instead of the full date of birth.",
    "postal_code": "Ask for the city or state instead of the PIN / ZIP code.",
    "address": "Ask 'Which city?' instead of the full address.",
    "phone": "Ask for the last 4 digits of the phone number to confirm it.",
    "email": "Ask for the email domain if you only need the organisation.",
    "age": "Ask for the age range instead of the exact age.",
    "id_number": "Ask for the last 4 digits of the ID number to confirm it.",
}
# Recogniser categories that are direct identifiers by themselves.
_DIRECT_CATEGORIES = {
    "PERSON": "name", "EMAIL": "email", "PHONE": "phone", "ADDRESS": "address",
    "ID_NUMBER": "id_number", "PASSPORT": "id_number", "BANK_ACCOUNT": "account",
    "CREDIT_CARD": "account", "DRIVER_LICENSE": "id_number",
}
_CONCEPT_KIND = {"dob": "dob", "gender": "gender", "age": "age"}


@dataclass
class Item:
    label: str      # what was disclosed, e.g. "Date of Birth"
    kind: str       # dob, postal_code, phone, ...
    category: str = ""  # sensitivity category, for sensitive attributes


def item_for_field(label: str, concept: str | None, sensitivity: list[str]) -> Item | None:
    """Classify a disclosed field (by its type, never its value)."""
    if concept in DIRECT:
        return Item(label, concept)
    if concept in _CONCEPT_KIND:
        return Item(label, _CONCEPT_KIND[concept])
    for category in sensitivity:
        if category in _DIRECT_CATEGORIES:
            return Item(label, _DIRECT_CATEGORIES[category])
        if category == "DATE_OF_BIRTH":
            return Item(label, "dob")
    for category in sensitivity:
        if category in SENSITIVE_ATTRIBUTES:
            return Item(label, "attribute", category)
    return None


def assess(items: list[Item]) -> dict:
    """Risk level for the items disclosed together. Never contains values."""
    if not items:
        return {"level": "None", "score": 0, "identifying_bits": 0.0, "factors": [],
                "reasons": ["Nothing identifying is disclosed."], "suggestions": []}
    factors, reasons, suggestions = [], [], []
    direct = [i for i in items if i.kind in DIRECT]
    bits = 0.0
    seen_kinds = set()
    for item in items:
        if item.kind in DIRECT:
            factors.append({"item": item.label, "kind": item.kind, "bits": "direct identifier"})
        elif item.kind in QUASI_BITS:
            if item.kind not in seen_kinds:
                bits += QUASI_BITS[item.kind]
            factors.append({"item": item.label, "kind": item.kind, "bits": QUASI_BITS[item.kind]})
        elif item.kind == "attribute":
            factors.append({"item": item.label, "kind": "sensitive attribute", "bits": 0})
        seen_kinds.add(item.kind)
        tip = SUGGESTIONS.get(item.kind)
        if tip and tip not in suggestions:
            suggestions.append(tip)

    for item in direct:
        reason = DIRECT[item.kind]
        if reason not in reasons:
            reasons.append(reason[0].upper() + reason[1:] + f" ({item.label}).")
    quasi = [i.label for i in items if i.kind in QUASI_BITS]
    share = min(bits / UNIQUE_BITS, 1.0)
    if bits >= HIGH_BITS:
        reasons.append(f"Together, {', '.join(quasi)} are likely to single out one person.")
    elif bits >= MEDIUM_BITS:
        reasons.append(f"Together, {', '.join(quasi)} narrow the person down to a small group.")
    elif len(quasi) > 1:
        reasons.append(f"Together, {', '.join(quasi)} still match many people.")
    elif quasi:
        reasons.append(f"{quasi[0]} on its own matches many people.")
    sensitive = sorted({SENSITIVE_ATTRIBUTES[i.category] for i in items if i.kind == "attribute"})
    if sensitive:
        reasons.append(f"Sensitive {' and '.join(sensitive)} is disclosed; combined with an identifier it "
                       "reveals private facts about the person.")

    if direct or bits >= HIGH_BITS:
        level, score = "High", 100 if direct else max(85, round(100 * share))
    elif bits >= MEDIUM_BITS:
        level, score = "Medium", round(100 * share)
    else:
        level, score = "Low", round(100 * share)
    if sensitive and level == "Low":
        level = "Medium"
        score = max(score, 40)
    return {
        "level": level,
        "score": score,
        "identifying_bits": round(bits, 1),
        "factors": factors,
        "reasons": reasons,
        "suggestions": suggestions if level != "Low" else [],
    }
