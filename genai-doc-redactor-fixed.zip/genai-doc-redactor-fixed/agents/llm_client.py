from __future__ import annotations
import requests
from urllib.parse import urlparse
from config import (
    LLM_PROVIDER, OLLAMA_BASE_URL, OLLAMA_MODEL, OLLAMA_TIMEOUT,
)
from utils.logging_utils import get_logger

logger = get_logger("llm_client")


class LLMClient:
    def __init__(self, provider: str = None, model: str = None):
        self.provider = provider or LLM_PROVIDER
        self.model = model or OLLAMA_MODEL
        if self.provider != "ollama":
            raise ValueError("Only the local Ollama provider is supported")
        host = (urlparse(OLLAMA_BASE_URL).hostname or "").lower()
        if host not in {"localhost", "127.0.0.1", "::1"}:
            raise ValueError("Ollama must use a loopback URL so document content stays local")

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        if self.provider == "ollama":
            return self._call_ollama(system_prompt, user_prompt)
        else:
            raise ValueError("Only the local Ollama provider is supported")

    def _call_ollama(self, system_prompt: str, user_prompt: str) -> str:
        url = f"{OLLAMA_BASE_URL.rstrip('/')}/api/chat"
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "format": "json",
            "options": {
                "temperature": 0.1,
                # The structured reply is small; a low cap bounds latency.
                "num_predict": 512,
            },
        }

        try:
            resp = requests.post(url, json=payload, timeout=OLLAMA_TIMEOUT)
            if resp.status_code == 404:
                raise RuntimeError(
                    f"Model '{self.model}' is not installed in Ollama. Run: ollama pull {self.model}"
                )
            resp.raise_for_status()
            data = resp.json()
            content = data.get("message", {}).get("content", "")
            logger.info("Ollama response received (%d chars)", len(content))
            return content
        except requests.ConnectionError:
            raise ConnectionError(
                f"Cannot connect to Ollama at {OLLAMA_BASE_URL}. "
                "Make sure Ollama is running: ollama serve"
            )
        except requests.Timeout:
            raise TimeoutError(f"Ollama request timed out after {OLLAMA_TIMEOUT} seconds")
        except requests.HTTPError as exc:
            raise RuntimeError(f"Ollama returned HTTP {exc.response.status_code}") from None
        except ValueError:
            raise RuntimeError("Ollama returned a response that is not valid JSON") from None

    def check_connection(self) -> tuple[bool, str]:
        if self.provider == "ollama":
            try:
                resp = requests.get(f"{OLLAMA_BASE_URL.rstrip('/')}/api/tags", timeout=5)
                resp.raise_for_status()
                models = [m["name"] for m in resp.json().get("models", [])]
                if not models:
                    return False, "Ollama is running but no models found. Pull a model: ollama pull qwen2.5:7b"
                return True, f"Connected. Available models: {', '.join(models)}"
            except requests.ConnectionError:
                return False, f"Cannot connect to Ollama at {OLLAMA_BASE_URL}"
            except Exception as e:
                return False, f"Ollama error: {e}"
        return False, "Only the local Ollama provider is supported."
