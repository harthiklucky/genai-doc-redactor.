"""Detect documents crafted to manipulate the AI.

Two warning signs:

1. Instructions aimed at an AI ("ignore previous instructions", "you are now
   an assistant", "reveal all fields", "do not redact"...) in the visible
   text or inside a QR code / barcode.
2. Invisible text: text that a PDF contains but a reader cannot see (white
   or near-white text, microscopic text, text placed off the page). This is
   the usual way to plant hidden instructions or fake values.

What the pipeline does with findings:
  * invisible text is removed before extraction, so it can neither answer a
    question nor steer the model;
  * when instructions are found, the language model is not consulted for
    that document (deterministic matching only), and the instruction text is
    never disclosed;
  * the user sees a warning; the audit records kinds and counts only.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

import numpy as np
from PIL import Image

from ingestion.document_model import DocumentElement

_PATTERNS: list[tuple[str, re.Pattern]] = [(name, re.compile(rx, re.IGNORECASE)) for name, rx in [
    ("override instructions",
     r"\b(ignore|disregard|forget|override|bypass)\b[\w\s,]{0,30}\b(instructions?|rules|prompts?|guidelines|"
     r"directions|polic(?:y|ies)|context|safeguards?)\b"),
    ("role change",
     r"\b(you are now|you're now|act as|pretend (?:to be|you are)|roleplay as|from now on you)\b"),
    ("addressed to the AI",
     r"\b(dear|attention|note to|hey|hello)\s+(ai|assistant|chatbot|language model|llm|gpt|claude|model)\b"
     r"|\bas an ai\b|\b(ai|llm|assistant|model)\s*[:,]\s*(please\s+)?(ignore|reveal|disclose|output|print|show)"),
    ("request to reveal everything",
     # Strong verbs with "all/every/full ... data"; or any verb with words that
     # only make sense to a redaction system ("unredacted", "hidden" values).
     r"\b(reveal|disclose|dump|leak|expose|exfiltrate)\b[\w\s]{0,15}\b(all|every|entire|full|complete)\b"
     r"[\w\s]{0,15}\b(data|fields?|information|values|contents?|pii|details|records?)\b"
     r"|\b(reveal|disclose|show|output|print|return|send|dump)\b[\w\s]{0,15}\b(unredacted|hidden|redacted|"
     r"masked|protected|sensitive|private)\b[\w\s]{0,15}\b(data|fields?|information|values|text|contents?|"
     r"pii|details)\b"),
    ("request to stop protection",
     r"\b(do not|don't|never|stop|no need to)\s+(redact|mask|hide|protect|censor|anonymi[sz]e|blur)\b"
     r"|\b(disable|turn off|switch off)\s+(the\s+)?(privacy|redaction|protection|filter)"),
    ("prompt markup",
     r"<\|im_(start|end)\|>|\[/?INST\]|<<SYS>>|^\s*#{2,}\s*(system|instruction)|"
     r"^\s*(system|assistant)\s*:|\bsystem prompt\b|\bjailbreak\b|\bprompt injection\b"),
]]


@dataclass
class Finding:
    kind: str            # "instruction", "invisible_text", "code_instruction"
    reason: str          # which pattern / why invisible
    page: int
    element_ids: list[str]
    excerpt: str         # short excerpt, for the user's screen only (never logged)

    def summary(self) -> dict:
        """Audit-safe form: no document text."""
        return {"kind": self.kind, "reason": self.reason, "page": self.page}


def _instruction(text: str) -> str | None:
    for name, pattern in _PATTERNS:
        if pattern.search(text):
            return name
    return None


def _rows(elements: list[DocumentElement]) -> list[list[DocumentElement]]:
    from agents.relevance import group_rows
    return group_rows(elements)


def find_instructions(elements: list[DocumentElement], code_texts: list[str] | None = None) -> list[Finding]:
    """Instruction-like text in visible lines and in decoded QR/barcode texts."""
    findings: list[Finding] = []
    flagged: set[str] = set()
    by_page: dict[int, list[DocumentElement]] = {}
    for el in elements:
        by_page.setdefault(el.page, []).append(el)
    for page, page_elements in sorted(by_page.items()):
        rows = [sorted(row, key=lambda e: e.bbox[0]) for row in _rows(page_elements)]
        texts = [" ".join(e.text for e in row) for row in rows]
        for index, row in enumerate(rows):
            reason = _instruction(texts[index])
            candidate = row
            if not reason and index + 1 < len(rows) and not _instruction(texts[index + 1]):
                # An instruction may wrap onto the next line. Join the lines
                # only when neither matches alone, so an innocent line next to
                # an instruction ("Phone Number ...") is never flagged.
                reason = _instruction(f"{texts[index]} {texts[index + 1]}")
                candidate = row + rows[index + 1]
            if reason:
                ids = [e.id for e in candidate if e.id not in flagged]
                if ids:
                    flagged.update(ids)
                    text = " ".join(e.text for e in candidate)
                    findings.append(Finding("instruction", reason, page, ids, text[:160]))
    for text in code_texts or []:
        reason = _instruction(text)
        if reason:
            findings.append(Finding("code_instruction", reason, 0, [], text[:160]))
    return findings


def find_invisible_text(
    elements: list[DocumentElement], image: Image.Image, scale_x: float = 1.0, scale_y: float = 1.0,
) -> list[Finding]:
    """Text that has no visible ink where it is supposed to be on the page."""
    gray = np.asarray(image.convert("L"))
    h, w = gray.shape
    findings = []
    for el in elements:
        if not el.text.strip():
            continue
        x0, y0, x1, y1 = (el.bbox[0] * scale_x, el.bbox[1] * scale_y, el.bbox[2] * scale_x, el.bbox[3] * scale_y)
        reason = None
        if x1 <= 0 or y1 <= 0 or x0 >= w or y0 >= h:
            reason = "text placed outside the page"
        elif (y1 - y0) < 4:
            reason = "microscopic text"
        else:
            region = gray[max(0, int(y0)):min(h, int(y1) + 1), max(0, int(x0)):min(w, int(x1) + 1)]
            if region.size and (region < 200).mean() < 0.004:
                reason = "text with no visible ink (e.g. white on white)"
        if reason:
            planted = _instruction(el.text)
            if planted:
                reason += f"; it contains instructions to the AI ({planted})"
            findings.append(Finding("invisible_text", reason, el.page, [el.id], el.text[:160]))
    return findings
