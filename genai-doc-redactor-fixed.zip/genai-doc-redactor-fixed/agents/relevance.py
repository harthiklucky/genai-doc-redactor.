"""Query-to-field relevance matching for selective document disclosure.

Enforces deterministic, conservative matching to prevent false positives:
- Normalized token matching with singular/plural normalization
- Discriminative anchor token enforcement (e.g. 'brain', 'hematological')
- Generic words ('other', 'tumor', 'score', etc.) cannot independently select unrelated rows
- Exact phrase matches take precedence over partial/fuzzy matches
- Table row grouping is page-aware and spatial coordinate-based
- Whole-line disclosure when a line matches the query
"""
from __future__ import annotations
import re
from difflib import SequenceMatcher
from ingestion.document_model import DocumentElement
from utils.logging_utils import get_logger

logger = get_logger("relevance")

_TOKEN_RE = re.compile(r"[A-Za-z]+|\d+(?:[.,]\d+)?")
_NUMERIC_FIELD_RE = re.compile(r"^[(\[]?\s*[$€£]?\s*\d+(?:[.,]\d+)?\s*%?\s*[)\]]?$")
_PAREN_NUMBER_RE = re.compile(r"\((\d+(?:[.,]\d+)?)\)")
_PERCENT_RE = re.compile(r"(\d+(?:[.,]\d+)?)\s*%")
_DECIMAL_RE = re.compile(r"\b\d+\.\d+\b")
_INTEGER_RE = re.compile(r"^\d+$")
_CURRENCY_RE = re.compile(r"[$€£]\s*\d|(?:\d[.,]\d{2})\b")
_TABLE_HEADER_WORDS = {
    "name", "date", "number", "id", "description", "quantity", "qty", "unit",
    "price", "total", "amount", "count", "score", "percent", "percentage",
    "rate", "result", "value", "department", "salary", "dosage", "frequency",
    "type", "status", "category", "field", "measure", "code", "age", "sex",
    "gender", "address", "diagnosis", "medication", "service", "charge", "due",
    "invoice", "reference", "product", "customer", "employee", "patient",
    "subtotal", "tax", "balance", "account", "item", "term", "method",
}

# Filler words that carry no domain information
FILLER_WORDS = {
    "the", "a", "an", "of", "for", "and", "or", "to", "in", "on", "at", "is",
    "what", "whats", "show", "me", "please", "need", "from", "this", "that",
    "tell", "give", "with", "about", "how", "much", "many", "does", "did",
    "are", "was", "were", "find", "get", "which",
    # Prompt instructions describe how to disclose content; they are not
    # document terms that should also have to occur in the matched row.
    "line", "lines", "row", "rows", "table", "tables", "heading",
    "headings", "document", "documents", "preserve", "preserving",
    "blur", "blurred", "redact", "redacted", "hide", "hidden",
    "visible", "visibility", "sensitive", "secure", "showing", "containing",
    "keep", "keeping", "only", "relevant", "related", "include", "including",
    "personal", "private", "privacy", "all", "everything", "else", "stuff",
}

_DESCRIPTOR_WORDS = {"patient", "customer", "client", "employee", "person"}


def _query_targets(query: str) -> list[str]:
    """Split a natural-language request into separately requested topics.

    For example, “show the patient's diagnosis and medication” should match
    the diagnosis line and medication line independently, not require both
    words to occur in one row.
    """
    clauses = re.split(r"\b(?:and|or|also|with|plus)\b|[,;]", query or "", flags=re.IGNORECASE)
    targets = []
    for clause in clauses:
        tokens = [t for t in tokenize(clause) if normalize_token(t) not in FILLER_WORDS]
        if len(tokens) > 1:
            tokens = [t for t in tokens if normalize_token(t) not in _DESCRIPTOR_WORDS]
        if tokens:
            targets.append(" ".join(tokens))
    return targets

# Measure words that describe the type of value requested rather than entity identity
SCORE_HINTS = {"score", "percent", "percentage", "rate", "result", "%", "proportion"}
AMOUNT_HINTS = {"total", "amount", "price", "cost", "sum", "balance", "due", "subtotal", "salary", "pay"}
COUNT_HINTS = {"count", "quantity", "qty", "number"}
MEASURE_WORDS = SCORE_HINTS | AMOUNT_HINTS | COUNT_HINTS | {"value", "level"}

# Generic category words that often appear in documents and tables.
# CRITICAL: These words MUST NOT independently trigger matching of unrelated rows.
GENERIC_WORDS = {
    "other", "tumor", "tumors", "cancer", "cancers", "disorder", "disorders",
    "disease", "diseases", "condition", "conditions", "test", "tests",
    "data", "info", "information", "detail", "details", "record", "records",
    "report", "reports", "patient", "patients", "customer", "customers",
    "client", "clients", "employee", "employees", "person", "item", "items",
    "cell", "cells", "type", "types", "group", "groups",
}


def normalize_token(token: str) -> str:
    """Normalize a token: lowercased, comma replaced, singularized."""
    t = (token or "").lower().strip()
    t = t.replace(",", ".")

    # Irregular or special plurals
    irregulars = {
        "men": "man",
        "women": "woman",
        "children": "child",
        "diagnoses": "diagnosis",
        "analyses": "analysis",
    }
    if t in irregulars:
        return irregulars[t]

    # Rule-based singularization
    if len(t) > 4 and t.endswith("ies"):
        return t[:-3] + "y"
    if len(t) > 4 and t.endswith("sses"):
        return t[:-2]
    if len(t) > 4 and t.endswith("es") and (t.endswith("shes") or t.endswith("ches") or t.endswith("xes")):
        return t[:-2]
    if len(t) > 3 and t.endswith("s") and not t.endswith("ss") and not t.endswith("us") and not t.endswith("is"):
        return t[:-1]

    return t


def tokenize(text: str) -> list[str]:
    """Extract raw tokens preserving numbers."""
    # OCR or titles may join words in CamelCase (e.g. BirthCertificate).
    text = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", text or "")
    return [t.lower().replace(",", ".") for t in _TOKEN_RE.findall(text)]


def normalize_tokens(text: str) -> list[str]:
    """Tokenize and apply singular/plural normalization."""
    return [normalize_token(t) for t in tokenize(text)]


def normalize_phrase(text: str) -> str:
    """Join normalized tokens into a comparable phrase string."""
    return " ".join(normalize_tokens(text))


def partition_query(query: str) -> tuple[set[str], set[str], set[str]]:
    """Partition query tokens into:
    1. discriminative_tokens: unique domain words (e.g. 'kidney', 'brain', 'hematological')
    2. generic_tokens: generic category words (e.g. 'other', 'tumor')
    3. measure_tokens: measure hints (e.g. 'score', 'total')
    """
    raw_tokens = tokenize(query)
    norm_tokens = [normalize_token(t) for t in raw_tokens]

    discriminative = set()
    generic = set()
    measure = set()

    for raw, norm in zip(raw_tokens, norm_tokens):
        if norm in FILLER_WORDS or len(norm) <= 1:
            continue
        if norm in MEASURE_WORDS or raw in MEASURE_WORDS:
            measure.add(norm)
        elif norm in GENERIC_WORDS or raw in GENERIC_WORDS:
            generic.add(norm)
        else:
            discriminative.add(norm)

    return discriminative, generic, measure


# ─────────────────────────────────────────────────────────────────────────────
# Spatial Table Row Grouping (Page-Aware)
# ─────────────────────────────────────────────────────────────────────────────

def _vertical_overlap(a: DocumentElement, b: DocumentElement) -> float:
    """Calculate 1D vertical overlap between two bounding boxes."""
    y0 = max(a.bbox[1], b.bbox[1])
    y1 = min(a.bbox[3], b.bbox[3])
    return max(0.0, y1 - y0)


def same_row(a: DocumentElement, b: DocumentElement) -> bool:
    """Two elements belong to the same logical row if they share page and vertical line."""
    if a.page != b.page:
        return False

    h_a = max(a.bbox[3] - a.bbox[1], 8.0)
    h_b = max(b.bbox[3] - b.bbox[1], 8.0)
    overlap = _vertical_overlap(a, b)
    min_h = min(h_a, h_b)

    # Significant vertical overlap (>40% of smaller element height)
    if overlap >= 0.4 * min_h:
        return True

    # Center distance fallback
    c_a = (a.bbox[1] + a.bbox[3]) / 2.0
    c_b = (b.bbox[1] + b.bbox[3]) / 2.0
    threshold = max(h_a, h_b) * 0.65
    return abs(c_a - c_b) <= threshold


def group_rows(elements: list[DocumentElement]) -> list[list[DocumentElement]]:
    """Group elements into page-aware, spatially ordered table rows."""
    if not elements:
        return []

    # Group by page first to avoid cross-page interference
    pages: dict[int, list[DocumentElement]] = {}
    for el in elements:
        pages.setdefault(el.page, []).append(el)

    all_rows: list[list[DocumentElement]] = []

    for page_num in sorted(pages.keys()):
        remaining = list(pages[page_num])
        # Sort remaining elements primarily by Y top, then X left
        remaining.sort(key=lambda e: (e.bbox[1], e.bbox[0]))

        while remaining:
            seed = remaining.pop(0)
            row = [seed]
            kept = []
            for el in remaining:
                if same_row(seed, el):
                    row.append(el)
                else:
                    kept.append(el)
            remaining = kept
            # Inside the row, sort left to right by x0
            row.sort(key=lambda e: e.bbox[0])
            all_rows.append(row)

    # Sort all rows by page, then average Y
    all_rows.sort(key=lambda r: (r[0].page, sum(e.bbox[1] for e in r) / len(r)))
    return all_rows


def _nearby_table_header(
    rows: list[list[DocumentElement]], data_row: list[DocumentElement]
) -> list[DocumentElement] | None:
    """Find the nearest preceding text-only row that looks like column labels."""
    data_y = min(el.bbox[1] for el in data_row)
    data_page = data_row[0].page
    data_height = max((el.bbox[3] - el.bbox[1] for el in data_row), default=8.0)
    max_gap = max(80.0, min(200.0, data_height * 5))
    candidates = []

    for row in rows:
        if row is data_row or row[0].page != data_page or len(row) < 2:
            continue
        row_y = max(el.bbox[3] for el in row)
        gap = data_y - row_y
        if gap < 0 or gap > max_gap or any(is_numeric_span(el.text) for el in row):
            continue
        tokens = set(normalize_tokens(" ".join(el.text for el in row)))
        if tokens & _TABLE_HEADER_WORDS:
            candidates.append((gap, row))

    return min(candidates, key=lambda item: item[0])[1] if candidates else None


# ─────────────────────────────────────────────────────────────────────────────
# Strict Query Relevance Scoring
# ─────────────────────────────────────────────────────────────────────────────

def _query_kind(user_query: str) -> str:
    tokens = set(normalize_tokens(user_query))
    q = (user_query or "").lower()
    # Match measure hints as complete tokens. Substring checks misclassify
    # ordinary words such as "corporate" as a request for a rate/score.
    if any(h in tokens for h in SCORE_HINTS if h != "%") or "%" in q:
        return "score"
    if any(h in tokens for h in AMOUNT_HINTS):
        return "amount"
    if any(h in tokens for h in COUNT_HINTS):
        return "count"
    return "general"


def score_row_match(row: list[DocumentElement], user_query: str) -> float:
    """Score how well a table row matches the user's query.

    Returns:
        Score >= 100 for exact phrase match
        Score 50-99 for exact token matches (discriminative + generic)
        Score 0 for non-matching or false-positive rows
    """
    row_text = " ".join(el.text for el in row)
    row_norm_tokens = set(normalize_tokens(row_text))
    row_norm_phrase = normalize_phrase(row_text)

    # Identify the label text (usually first element or text elements before numbers)
    label_elements = [el for el in row if not is_numeric_span(el.text)]
    label_text = " ".join(el.text for el in label_elements) if label_elements else row_text
    label_norm_phrase = normalize_phrase(label_text)
    label_norm_tokens = set(normalize_tokens(label_text))

    discriminative, generic, measure = partition_query(user_query)
    query_content_tokens = discriminative | generic

    if not query_content_tokens and not measure:
        return 0.0

    # Clean query phrase without filler and measure words
    clean_query_tokens = [normalize_token(t) for t in tokenize(user_query)
                          if normalize_token(t) not in FILLER_WORDS
                          and normalize_token(t) not in MEASURE_WORDS]
    clean_query_phrase = " ".join(clean_query_tokens)

    # 1. Exact phrase match on row label
    if clean_query_phrase and (clean_query_phrase == label_norm_phrase):
        return 120.0

    # 2. Phrase containment (e.g. query "brain tumor" in label "brain tumors")
    clean_query_sequence = clean_query_phrase.split()
    label_sequence = label_norm_phrase.split()
    phrase_is_contained = bool(clean_query_sequence) and any(
        label_sequence[index:index + len(clean_query_sequence)] == clean_query_sequence
        for index in range(len(label_sequence) - len(clean_query_sequence) + 1)
    )
    if phrase_is_contained:
        # Prefer closer length match (penalize extra modifying words)
        length_ratio = len(clean_query_phrase) / max(len(label_norm_phrase), 1)
        return 100.0 * length_ratio

    # 3. Discriminative anchor enforcement
    # If the user specified discriminative domain words (e.g. 'kidney', 'brain', 'hematological'),
    # ALL discriminative words MUST be present in the row!
    if discriminative:
        missing_anchors = discriminative - label_norm_tokens
        if missing_anchors:
            # Check row tokens (maybe anchor is in a nearby cell in the row)
            missing_anchors = discriminative - row_norm_tokens
        if missing_anchors:
            # Does not contain the discriminative anchors -> REJECT completely!
            return 0.0

        # All discriminative anchors present. Check generic words as well.
        # (e.g. for "other hematological tumors", row must have 'other' and 'hematological')
        matched_content = query_content_tokens & label_norm_tokens
        fraction_matched = len(matched_content) / len(query_content_tokens)

        # Penalize if label has excessive unmatched words (e.g. "other tumors" vs "other hematological tumors")
        precision = len(matched_content) / max(len(label_norm_tokens), 1)
        return 50.0 + (fraction_matched * 30.0) + (precision * 20.0)

    # 4. No discriminative anchors (only generic words, e.g. query "other tumors")
    if generic:
        # Require ALL generic words of the query to be present
        if not generic.issubset(label_norm_tokens):
            return 0.0

        # If clean phrase exactly equals label phrase, high score
        if clean_query_phrase == label_norm_phrase:
            return 95.0

        # If row label has extra qualifying adjectives (like 'hematological' in 'other hematological tumors'),
        # penalize heavily when the query was only for 'other tumors'!
        extra_tokens = label_norm_tokens - generic
        if extra_tokens:
            return 30.0  # Lower score, so exact 'other tumors' wins!

        return 70.0

    # 5. Measure-only query (e.g. "invoice total")
    if measure and not query_content_tokens:
        if any(m in label_norm_tokens for m in measure):
            return 60.0

    return 0.0


def score_row_match_fuzzy(row: list[DocumentElement], user_query: str) -> float:
    """Conservative fuzzy match fallback. ONLY used if no exact match exists anywhere."""
    discriminative, generic, _ = partition_query(user_query)
    if not discriminative:
        return 0.0

    row_text = " ".join(el.text for el in row)
    tokens = set(tokenize(row_text))

    # Only fuzzy match discriminative anchors of length >= 5
    for anchor in discriminative:
        if len(anchor) < 5:
            return 0.0
        best_ratio = 0.0
        for token in tokens:
            if len(token) >= 5:
                ratio = SequenceMatcher(None, anchor, token).ratio()
                if ratio > best_ratio:
                    best_ratio = ratio
        if best_ratio < 0.85:
            return 0.0

    return 40.0


# ─────────────────────────────────────────────────────────────────────────────
# Value Cell Selection
# ─────────────────────────────────────────────────────────────────────────────

def is_numeric_span(text: str) -> bool:
    stripped = (text or "").strip()
    if not stripped:
        return False
    if _NUMERIC_FIELD_RE.match(stripped):
        return True
    if _PAREN_NUMBER_RE.search(stripped):
        return True
    return False


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def find_relevant_field_ids(elements: list[DocumentElement], user_query: str) -> set[str]:
    """Deterministically identify OCR elements to KEEP for the given user query.

    Match a line conservatively, then disclose every OCR field grouped into
    that line so its full context remains visible.
    """
    if not elements or not user_query or not user_query.strip():
        return set()

    rows = group_rows(elements)
    if not rows:
        return set()

    # Match each requested topic independently. A request for “diagnosis and
    # medication” normally refers to separate lines, so requiring both terms
    # in one row would cause the intended lines to disappear.
    targets = _query_targets(user_query)
    if len(targets) > 1:
        matched: set[str] = set()
        for target in targets:
            matched.update(find_relevant_field_ids(elements, target))
        return matched

    # Step 1: Score all rows with exact / token matching
    row_scores: list[tuple[float, list[DocumentElement]]] = []
    for row in rows:
        score = score_row_match(row, user_query)
        if score > 0:
            row_scores.append((score, row))

    # Step 2: Fallback to conservative fuzzy matching ONLY if no row matched at all
    if not row_scores:
        for row in rows:
            score = score_row_match_fuzzy(row, user_query)
            if score > 0:
                row_scores.append((score, row))

    if not row_scores:
        logger.info("No relevant rows identified for this query")
        return set()

    # A single-word search means “show me the line(s) containing this word.”
    # Do not rank longer labels below a short exact label and accidentally
    # discard them; every row with a valid exact match should be disclosed.
    discriminative, generic, measure = partition_query(user_query)
    query_content_tokens = discriminative | generic
    if len(query_content_tokens) == 1 and not measure:
        selected_rows = [row for _, row in row_scores]
    else:
        selected_rows = None

    # Sort candidates by match score descending for multi-term prompts.
    row_scores.sort(key=lambda item: item[0], reverse=True)
    if selected_rows is None:
        max_score = row_scores[0][0]

        # Select the winning row(s). For multi-term prompts, keep close scoring
        # matches to avoid disclosing unrelated rows.
        cutoff = max_score * 0.85 if max_score >= 80.0 else max_score * 0.95
        selected_rows = [row for score, row in row_scores if score >= cutoff]

    relevant_ids: set[str] = set()

    for row in selected_rows:
        relevant_ids.update(el.id for el in row)
        header_row = _nearby_table_header(rows, row)
        if header_row:
            relevant_ids.update(el.id for el in header_row)

    logger.info("Deterministic relevance matched %d fields across %d rows",
                len(relevant_ids), len(selected_rows))
    return relevant_ids


def extract_answer_from_keep_fields(
    user_query: str,
    elements: list[DocumentElement],
    keep_ids: set[str],
) -> str | None:
    """Build a concise, precise answer string from disclosed fields."""
    keep_elements = [el for el in elements if el.id in keep_ids]
    if not keep_elements:
        return None

    # KEEP is a validated disclosure decision, so the requested value itself
    # (including PII) must be available to construct the answer.
    joined = " ".join(el.text for el in keep_elements)
    kind = _query_kind(user_query)

    if kind == "score":
        paren = _PAREN_NUMBER_RE.search(joined)
        if paren:
            return f"{paren.group(1).replace(',', '.')}%"
        percent = _PERCENT_RE.search(joined)
        if percent:
            return f"{percent.group(1).replace(',', '.')}%"
        decimals = _DECIMAL_RE.findall(joined)
        if decimals:
            return f"{decimals[0]}%"
        return None

    if kind == "amount":
        cur = _CURRENCY_RE.search(joined)
        if cur:
            # find complete currency number
            full_cur = re.search(r"[$€£]\s*\d+(?:[.,]\d+)?", joined)
            if full_cur:
                return full_cur.group(0).replace(" ", "")
        decimals = _DECIMAL_RE.findall(joined)
        if decimals:
            return decimals[0]
        return None

    if kind == "count":
        # Look for standalone integer
        for el in keep_elements:
            if _INTEGER_RE.match(el.text.strip()):
                return el.text.strip()
        nums = re.findall(r"\b\d+\b", joined)
        if nums:
            return nums[0]
        return None

    # General entity queries (e.g. "brain tumor"): extract informative percentage/decimal if present
    paren = _PAREN_NUMBER_RE.search(joined)
    if paren:
        return f"{paren.group(1).replace(',', '.')}%"
    percent = _PERCENT_RE.search(joined)
    if percent:
        return f"{percent.group(1).replace(',', '.')}%"
    decimals = _DECIMAL_RE.findall(joined)
    if decimals:
        return f"{decimals[0]}%"

    # Or return the kept text if small
    if len(keep_elements) <= 3:
        return " ".join(el.text for el in keep_elements)

    return None
