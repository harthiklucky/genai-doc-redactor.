"""Answers that reveal less than the field they come from.

Some questions do not need the whole value: "Is she over 18?" needs a yes or
no, not the date of birth; "Which city?" needs the city, not the street
address; "the last 4 digits of the phone number" needs four digits. Such a
request is answered with a value computed from the verified field, and the
field itself stays protected in the output.

Every derived answer is computed in code from an extracted field value; the
language model is never involved. When the source field is missing, ambiguous
or cannot be parsed, no derived answer is produced and the request falls back
to normal handling (usually "not found").
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date

from ingestion.document_model import DocumentField

# Kinds that may also be satisfied by a field of their own ("City: ..."): a
# real field is preferred and the derived answer is only a fallback.
FALLBACK_KINDS = {"city", "state", "postal_code", "age"}


@dataclass
class DerivedAnswer:
    segment: str
    kind: str          # age_check, age, age_band, birth_year, city, state, postal_code, last_digits, email_domain
    label: str         # "Over 18", "City", ...
    text: str          # "Yes", "Coimbatore", ...
    source_field_id: str
    source_label: str


# ── Source fields ─────────────────────────────────────────────────────────

def _single(fields: list[DocumentField], concept: str) -> DocumentField | None:
    found = [f for f in fields if f.concept == concept and f.value.strip()]
    values = {f.value.strip() for f in found}
    return found[0] if len(values) == 1 else None


def _birth_date(value: str) -> date | None:
    from dateutil import parser
    try:
        parsed = parser.parse(value, dayfirst=True, fuzzy=False).date()
    except (ValueError, OverflowError, TypeError):
        return None
    return parsed if date(1900, 1, 1) <= parsed <= date.today() else None


def _age_from(fields: list[DocumentField], today: date) -> tuple[int, DocumentField] | None:
    dob = _single(fields, "dob")
    if dob is not None:
        born = _birth_date(dob.value)
        if born is not None:
            years = today.year - born.year - ((today.month, today.day) < (born.month, born.day))
            return years, dob
    age = _single(fields, "age")
    if age is not None:
        match = re.search(r"\b(\d{1,3})\b", age.value)
        if match and 0 <= int(match.group(1)) <= 130:
            return int(match.group(1)), age
    return None


# ── Address parts ─────────────────────────────────────────────────────────

_INDIAN_STATES = (
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat",
    "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh",
    "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan",
    "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
    "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
    "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry",
)
_US_STATES = (
    "AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ "
    "NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY DC"
).split()
_PIN = re.compile(r"\b[1-9]\d{2}\s?\d{3}\b")
_ZIP = re.compile(r"\b\d{5}(?:-\d{4})?\b")


def address_parts(value: str) -> dict[str, str]:
    """City, state and postal code of an address, when they can be told apart."""
    parts = [p.strip() for p in re.split(r"[,;\n]", value) if p.strip()]
    found: dict[str, str] = {}
    state_index = None
    for index, part in enumerate(parts):
        lowered = part.lower()
        for state in _INDIAN_STATES:
            if re.search(rf"\b{re.escape(state.lower())}\b", lowered):
                found["state"], state_index = state, index
                pin = _PIN.search(part)
                if pin:
                    found["postal_code"] = pin.group(0).replace(" ", "")
                break
        if state_index is not None:
            break
        us = re.fullmatch(r"([A-Z]{2})\s+(\d{5}(?:-\d{4})?)", part)
        if us and us.group(1) in _US_STATES:
            found["state"], found["postal_code"], state_index = us.group(1), us.group(2), index
            break
    if "postal_code" not in found:
        for part in reversed(parts):
            code = _PIN.search(part) or _ZIP.search(part)
            if code:
                found["postal_code"] = code.group(0).replace(" ", "")
                break
    if state_index is not None:
        before = parts[state_index][: parts[state_index].lower().find(found["state"].lower())].strip()
        city = before or (parts[state_index - 1] if state_index >= 1 else "")
        city = re.sub(r"\d", "", city).strip(" -")
        # The city is a name, not a street line ("42 Lakeview Road").
        if city and len(city.split()) <= 3:
            found["city"] = city
    elif "postal_code" in found:
        # No state: the words just before the PIN/ZIP ("Bengaluru 560001").
        for part in reversed(parts):
            code = _PIN.search(part) or _ZIP.search(part)
            if code:
                before = part[:code.start()].strip(" -")
                if before and not re.search(r"\d", before) and len(before.split()) <= 3:
                    found["city"] = before
                break
    return found


# ── Request patterns ──────────────────────────────────────────────────────

_NUMBER_WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6}
_AGE_CHECK = re.compile(
    r"\b(over|above|older than|at least|more than|under|below|younger than|less than)\s+(\d{1,3})\b"
)
_LAST_DIGITS = re.compile(r"\blast\s+(\d|one|two|three|four|five|six)?\s*(?:digits?|numbers?|characters?)\b")


def _wants(words: set[str], *options: str) -> bool:
    return any(option in words for option in options)


def derive(
    segment: str,
    fields: list[DocumentField],
    already_matched: bool = False,
    today: date | None = None,
) -> DerivedAnswer | None:
    """A minimal answer for one request segment, or None."""
    today = today or date.today()
    text = " ".join(segment.lower().replace("-", " ").split())
    words = set(re.findall(r"[a-z]+", text))

    # Yes/no age checks: "over 18", "is she an adult", "is he a minor".
    # "Over/above 18" means 18 or older (as in "18+"); "older/more than 18"
    # means strictly above; "under/below/younger/less than 18" means below.
    check = _AGE_CHECK.search(text)
    test = label = None
    if check:
        op, threshold = check.group(1), int(check.group(2))
        if op in ("over", "above", "at least"):
            test = lambda years: years >= threshold  # noqa: E731
        elif op in ("older than", "more than"):
            test = lambda years: years > threshold  # noqa: E731
        else:
            test = lambda years: years < threshold  # noqa: E731
        label = check.group(0).capitalize()
    elif _wants(words, "adult", "major"):
        test, label = (lambda years: years >= 18), "Adult (18+)"
    elif _wants(words, "minor"):
        test, label = (lambda years: years < 18), "Minor (under 18)"
    elif "senior" in words and "citizen" in words:
        test, label = (lambda years: years >= 60), "Senior citizen (60+)"
    if test is not None:
        aged = _age_from(fields, today)
        if aged is None:
            return None
        years, source = aged
        return DerivedAnswer(segment, "age_check", label, "Yes" if test(years) else "No",
                             source.field_id, source.label)

    # Age range: "age range", "age group", "age band".
    if "age" in words and _wants(words, "range", "group", "band", "bracket"):
        aged = _age_from(fields, today)
        if aged is None:
            return None
        years, source = aged
        low = years // 5 * 5
        return DerivedAnswer(segment, "age_band", "Age range", f"{low}-{low + 4}", source.field_id, source.label)

    # Birth year only.
    if "year" in words and _wants(words, "birth", "born"):
        source = _single(fields, "dob")
        born = _birth_date(source.value) if source else None
        if born is None:
            return None
        return DerivedAnswer(segment, "birth_year", "Year of birth", str(born.year), source.field_id, source.label)

    # Last N digits of a number field.
    last = _LAST_DIGITS.search(text)
    if last:
        count = last.group(1) or "4"
        count = int(_NUMBER_WORDS.get(count, count))
        rest = _LAST_DIGITS.sub(" ", text)
        from agents.field_matcher import match_fields
        target = match_fields(fields, rest).selected_field_ids
        if len(target) != 1:
            return None
        source = next(f for f in fields if f.field_id in target)
        digits = re.sub(r"\D", "", source.value)
        # Never more than 4 digits, and never more than half of the number.
        count = min(count, 4, len(digits) // 2)
        if count <= 0:
            return None
        return DerivedAnswer(segment, "last_digits", f"Last {count} digits of {source.label}",
                             f"ending {digits[-count:]}", source.field_id, source.label)

    # Email domain.
    if "domain" in words and _wants(words, "email", "mail", "e"):
        source = _single(fields, "email")
        if source is None or "@" not in source.value:
            return None
        domain = source.value.rsplit("@", 1)[1].strip().strip(".").lower()
        return DerivedAnswer(segment, "email_domain", "Email domain", domain, source.field_id, source.label)

    if already_matched:
        return None  # a field of its own answered it ("City: ...", "Age: ...")

    # Address parts: city, state, PIN / ZIP code.
    kind = None
    # Only explicit words: "where does she live" asks for the address itself.
    if _wants(words, "city", "town"):
        kind = "city"
    elif "state" in words or "province" in words:
        kind = "state"
    elif _wants(words, "pincode", "zip", "zipcode") or ("pin" in words) or ("postal" in words and "code" in words):
        kind = "postal_code"
    if kind:
        source = _single(fields, "address")
        part = address_parts(source.value).get(kind) if source else None
        if not part:
            return None
        label = {"city": "City", "state": "State", "postal_code": "PIN / ZIP code"}[kind]
        return DerivedAnswer(segment, kind, label, part, source.field_id, source.label)

    # "How old" / "age" when the document only has a date of birth.
    if _wants(words, "old", "age"):
        source = _single(fields, "dob")
        born = _birth_date(source.value) if source else None
        if born is None:
            return None
        years = today.year - born.year - ((today.month, today.day) < (born.month, born.day))
        return DerivedAnswer(segment, "age", "Age", f"{years} years", source.field_id, source.label)
    return None
