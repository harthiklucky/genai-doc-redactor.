from __future__ import annotations
import json
from ingestion.document_model import DocumentRepresentation, DocumentElement, DocumentField
from agents.schemas import (
    PrivacyDecisionResponse,
    FieldDecision,
    RedactionAction,
    LLMSemanticResult,
)
from agents.prompts import SYSTEM_PROMPT, build_analysis_prompt
from agents.llm_client import LLMClient
from agents.relevance import find_relevant_field_ids, extract_answer_from_keep_fields
from ingestion.field_extractor import extract_document_fields, select_requested_field_element_ids
from utils.logging_utils import get_logger

logger = get_logger("privacy_agent")

MAX_FIELDS_PER_REQUEST = 200

SENSITIVE_ENTITY_TYPES = {
    "PERSON",
    "EMAIL",
    "PHONE",
    "ADDRESS",
    "DATE",
    "CREDIT_CARD",
    "BANK_ACCOUNT",
    "ID_NUMBER",
    "PASSPORT",
    "DRIVER_LICENSE",
    "IP_ADDRESS",
    "ORGANIZATION",
    "MEDICAL_LICENSE",
    "MEDICAL_INFORMATION",
    "SSN",
}


def _is_sensitive_element(el: DocumentElement | None) -> bool:
    if el is None or not el.entity_type:
        return False
    return el.entity_type.upper() in SENSITIVE_ENTITY_TYPES


def _build_fields_description(
    elements: list[DocumentElement], fields: list[DocumentField] | None = None
) -> str:
    """Format OCR elements into structured document context for the LLM."""
    lines = []
    field_roles: dict[str, str] = {}
    for field in fields or []:
        for fid in field.label_element_ids:
            field_roles[fid] = f"field label: {field.label}"
        for fid in field.value_element_ids:
            field_roles[fid] = f"value for field: {field.label}"
    for el in elements:
        entity_label = el.entity_type or "NONE"
        role = field_roles.get(el.id, "document text")
        lines.append(f"[{el.id}] (Page {el.page}) [{entity_label}] [{role}] \"{el.text}\"")
    return "\n".join(lines)


def _parse_llm_json(raw: str) -> LLMSemanticResult | None:
    """Parse and validate LLM output using Pydantic, handling markdown fences and formatting."""
    if not raw or not raw.strip():
        logger.warning("Empty response from LLM")
        return None

    raw_clean = raw.strip()

    # Extract JSON inside markdown code blocks if present
    if "```" in raw_clean:
        start = raw_clean.find("```")
        end = raw_clean.rfind("```")
        if start != end:
            inner = raw_clean[start:end]
            newline_pos = inner.find("\n")
            if newline_pos != -1:
                raw_clean = inner[newline_pos + 1:].strip()

    # Locate first '{' and last '}'
    json_start = raw_clean.find("{")
    json_end = raw_clean.rfind("}")
    if json_start != -1 and json_end != -1 and json_end > json_start:
        raw_clean = raw_clean[json_start:json_end + 1]

    try:
        data = json.loads(raw_clean)
    except json.JSONDecodeError as e:
        logger.warning("Failed to decode LLM JSON: %s", e)
        return None

    if not isinstance(data, dict):
        return None

    if "answer" not in data or not isinstance(data.get("answer"), str):
        logger.warning("LLM result is missing its required answer field")
        return None
    if not any(key in data for key in ("relevant_field_ids", "relevant_value_ids", "decisions")):
        logger.warning("LLM result is missing required field selections")
        return None

    # Handle legacy decision format if present
    if "decisions" in data and isinstance(data["decisions"], list):
        relevant_ids = []
        for d in data["decisions"]:
            if isinstance(d, dict):
                fid = d.get("field_id", "")
                act = str(d.get("action", "")).upper()
                if act in ("KEEP", "VISIBLE", "DISCLOSE") and fid:
                    relevant_ids.append(fid)
        if "relevant_field_ids" not in data:
            data["relevant_field_ids"] = relevant_ids

    try:
        return LLMSemanticResult(**data)
    except Exception:
        logger.warning("Pydantic validation of LLMSemanticResult failed")
        return None


def apply_context_aware_policy(
    semantic_result: LLMSemanticResult | None,
    elements: list[DocumentElement],
    user_query: str,
) -> PrivacyDecisionResponse:
    """Enforce deterministic privacy boundaries on LLM reasoning.

    Three strictly enforced states:
    1. KEEP: approved minimum disclosure fields needed to answer the query
    2. REDACT: sensitive information (PII/PHI) that must remain hidden
    3. HIDE: ordinary document content not required for the query
    """
    by_id = {el.id: el for el in elements}
    all_field_ids = set(by_id.keys())

    # Step 1: Deterministic relevance matching
    deterministic_ids = find_relevant_field_ids(elements, user_query)
    # Sensitive values may be disclosed only when the query selects them.
    # These IDs come from document matching, not model supplied coordinates.
    safe_deterministic_ids = {fid for fid in deterministic_ids if fid in by_id}

    # Step 2: Validate LLM IDs (discard any hallucinated IDs not in the document)
    llm_approved_ids: set[str] = set()
    llm_decisions: dict[str, FieldDecision] = {}
    if semantic_result:
        for d in semantic_result.decisions:
            llm_decisions[d.field_id] = d
        if semantic_result.confidence >= 0.65 and semantic_result.relevant_field_ids:
            for fid in semantic_result.relevant_field_ids:
                if fid in all_field_ids:
                    llm_approved_ids.add(fid)
        for fid in semantic_result.relevant_value_ids:
            if semantic_result.confidence >= 0.65 and fid in all_field_ids:
                llm_approved_ids.add(fid)

    # Step 3: Compute final approved KEEP IDs
    # When deterministic matching identifies relevant row/spans, it takes precedence
    # to guarantee zero false positives from generic words.
    if deterministic_ids:
        approved_keep_ids = safe_deterministic_ids
    elif llm_approved_ids:
        # IDs are accepted only when they resolve to real document elements.
        # Requested PII is eligible for disclosure; unrelated PII stays REDACT.
        structured_fields = extract_document_fields(elements)
        if structured_fields:
            approved_keep_ids = select_requested_field_element_ids(
                structured_fields, user_query, llm_approved_ids
            )
        else:
            approved_keep_ids = llm_approved_ids
    else:
        approved_keep_ids = set()

    # Step 4: Build FieldDecisions with strict 3-state logic
    decisions: list[FieldDecision] = []
    for fid in sorted(all_field_ids):
        el = by_id[fid]
        existing_d = llm_decisions.get(fid)
        has_content = bool(el.text and el.text.strip())

        if fid in approved_keep_ids:
            cat = (existing_d.category if existing_d and existing_d.category else "QUERY_RELEVANT")
            decisions.append(FieldDecision(
                field_id=fid,
                action=RedactionAction.KEEP,
                category=cat,
                reason="Required to answer the user query",
            ))
        elif _is_sensitive_element(el) or (existing_d and (existing_d.category or "").upper() in SENSITIVE_ENTITY_TYPES):
            cat = (el.entity_type or (existing_d.category if existing_d else None) or "SENSITIVE")
            decisions.append(FieldDecision(
                field_id=fid,
                action=RedactionAction.REDACT,
                category=cat,
                reason="Sensitive information is not needed for this request and is protected.",
            ))
        elif existing_d is None:
            # Unaddressed field: if it has content, HIDE; if empty or unknown, REDACT for safety
            decisions.append(FieldDecision(
                field_id=fid,
                action=RedactionAction.HIDE if has_content else RedactionAction.REDACT,
                category="NOT_REQUESTED" if has_content else "UNCLASSIFIED",
                reason="Ordinary document content — hidden" if has_content else "Not addressed by AI - defaulting to redact for safety",
            ))
        elif existing_d.action == RedactionAction.UNCERTAIN:
            if _is_sensitive_element(el) or not has_content:
                decisions.append(FieldDecision(
                    field_id=fid,
                    action=RedactionAction.REDACT,
                    category="UNCERTAIN",
                    reason="Uncertain field — redacted for safety",
                ))
            else:
                decisions.append(FieldDecision(
                    field_id=fid,
                    action=RedactionAction.HIDE,
                    category="NON_SENSITIVE",
                    reason="Uncertain non-sensitive field — hidden",
                ))
        else:
            # Ordinary non-sensitive content is hidden
            decisions.append(FieldDecision(
                field_id=fid,
                action=RedactionAction.HIDE,
                category=(existing_d.category if existing_d and existing_d.category else "NOT_REQUESTED"),
                reason="Ordinary document content — hidden for selective disclosure",
            ))

    # Step 5: Derive concise, accurate answer from approved KEEP elements
    derived_answer = extract_answer_from_keep_fields(user_query, elements, approved_keep_ids)
    final_answer = ""
    if derived_answer:
        final_answer = derived_answer
    elif approved_keep_ids:
        # Never display free-form model output here: it can contain data that
        # was not included in the approved KEEP fields.
        approved_text = " ".join(
            by_id[fid].text for fid in sorted(approved_keep_ids)
            if by_id[fid].text and by_id[fid].text.strip()
        )
        final_answer = approved_text or (
            "Relevant fields were approved, but their text was unavailable "
            "to construct an answer safely."
        )
    else:
        final_answer = "No relevant information found in the document for the specified query."

    summary = (
        f"Selective disclosure: {len(approved_keep_ids)} fields visible (KEEP), "
        f"{sum(1 for d in decisions if d.action.should_redact())} redacted (REDACT), "
        f"{sum(1 for d in decisions if d.action == RedactionAction.HIDE)} hidden (HIDE)."
    )

    conf = semantic_result.confidence if semantic_result else (1.0 if approved_keep_ids else 0.5)

    return PrivacyDecisionResponse(
        answer=final_answer,
        decisions=decisions,
        summary=summary,
        confidence=conf,
        # Expose only selections that survived the deterministic policy. Raw
        # model IDs must never be reused by downstream rendering logic.
        semantic_field_ids=sorted(approved_keep_ids),
    )


def _parse_llm_response(
    raw: str,
    all_field_ids: set[str],
    elements: list[DocumentElement] | None = None,
    user_query: str = "",
) -> PrivacyDecisionResponse:
    """Parse LLM response and apply deterministic policy (for tests and direct callers)."""
    parsed = _parse_llm_json(raw)
    element_list = elements or []
    if not element_list and all_field_ids:
        element_list = [
            DocumentElement(id=fid, text="", bbox=[0, 0, 0, 0]) for fid in all_field_ids
        ]

    if parsed is None:
        return _fallback_response(all_field_ids, element_list, user_query)

    return apply_context_aware_policy(parsed, element_list, user_query)


def _fallback_response(
    all_field_ids: set[str],
    elements: list[DocumentElement] | None = None,
    user_query: str = "",
) -> PrivacyDecisionResponse:
    """Safe fallback when LLM is unavailable: uses deterministic relevance matching."""
    logger.warning("Applying deterministic fallback privacy policy")
    element_list = elements or []
    if element_list and user_query:
        # Even without LLM, our deterministic matching can safely answer and disclose!
        return apply_context_aware_policy(None, element_list, user_query)

    by_id = {el.id: el for el in element_list}
    decisions = []
    for fid in all_field_ids:
        el = by_id.get(fid)
        if el is not None and not _is_sensitive_element(el) and el.text.strip():
            decisions.append(FieldDecision(
                field_id=fid,
                action=RedactionAction.HIDE,
                category="SAFETY_FALLBACK",
                reason="Processing error; non-sensitive content hidden",
            ))
        else:
            decisions.append(FieldDecision(
                field_id=fid,
                action=RedactionAction.REDACT,
                category="SAFETY_FALLBACK",
                reason="Redacted due to processing error — safety first",
            ))

    return PrivacyDecisionResponse(
        answer="Unable to process the request safely. Sensitive information has been redacted.",
        decisions=decisions,
        summary="Fallback policy applied due to processing error.",
    )


def build_llm_document_view(
    doc: DocumentRepresentation,
    max_entries: int = MAX_FIELDS_PER_REQUEST,
) -> tuple[str, dict[str, str], dict[str, str]]:
    """Describe the document to the model as labelled fields plus loose lines.

    Returns the description and two maps from the short IDs shown to the
    model ("F3", "L7") back to DocumentField IDs and element IDs.
    """
    from agents.field_matcher import display_label
    lines: list[str] = []
    field_map: dict[str, str] = {}
    line_map: dict[str, str] = {}
    structured = set()
    for index, field in enumerate(doc.fields, start=1):
        if len(lines) >= max_entries:
            break
        short = f"F{index}"
        field_map[short] = field.field_id
        structured.update(field.label_element_ids + field.value_element_ids + field.row_label_element_ids)
        sensitivity = ",".join(field.sensitivity) or "NONE"
        lines.append(
            f'[{short}] (page {field.page}) label="{display_label(field)}" '
            f'value="{field.value}" sensitivity={sensitivity}'
        )
    for index, el in enumerate((el for el in doc.all_elements() if el.id not in structured), start=1):
        if len(lines) >= max_entries:
            break
        short = f"L{index}"
        line_map[short] = el.id
        lines.append(f'[{short}] (page {el.page}) [{el.entity_type or "NONE"}] "{el.text}"')
    return "\n".join(lines), field_map, line_map


def analyze_document(
    doc: DocumentRepresentation,
    user_query: str,
    llm_client: LLMClient | None = None,
    use_llm: bool = True,
) -> PrivacyDecisionResponse:
    """Semantic reasoning via Qwen2.5 7B + deterministic enforcement.

    The model only proposes IDs. They are translated back to real document
    IDs here, unknown IDs are dropped, and the deterministic policy decides
    what is disclosed. The model's free-text answer is never shown; it is
    only compared against the selected document values for diagnostics.
    """
    all_elements = doc.all_elements()
    if not all_elements:
        return PrivacyDecisionResponse(
            answer="No text content found in the document.",
            decisions=[],
            summary="Empty document - nothing to disclose.",
        )

    semantic_result: LLMSemanticResult | None = None
    llm_status = "Not needed: the request was resolved by deterministic field matching."
    llm_field_ids: list[str] = []
    hallucinated = 0
    if use_llm:
        try:
            if llm_client is None:
                llm_client = LLMClient()
            fields_desc, field_map, line_map = build_llm_document_view(doc)
            user_prompt = build_analysis_prompt(user_query, fields_desc)
            raw_response = llm_client.generate(SYSTEM_PROMPT, user_prompt)
            semantic_result = _parse_llm_json(raw_response)
            if semantic_result is None:
                llm_status = "Model response was not valid structured JSON; deterministic matching used."
            else:
                element_ids: list[str] = []
                known_elements = {el.id for el in all_elements}
                for raw_id in [*semantic_result.relevant_field_ids, *semantic_result.relevant_value_ids]:
                    key = str(raw_id).strip().strip("[]")
                    if key in field_map:
                        if field_map[key] not in llm_field_ids:
                            llm_field_ids.append(field_map[key])
                    elif key in line_map:
                        element_ids.append(line_map[key])
                    elif key in known_elements:
                        element_ids.append(key)
                    else:
                        hallucinated += 1
                semantic_result = semantic_result.model_copy(update={
                    "relevant_field_ids": element_ids, "relevant_value_ids": [],
                })
                llm_status = (
                    f"Model consulted: {len(llm_field_ids)} field(s) and {len(element_ids)} text line(s) proposed"
                    + (f"; {hallucinated} nonexistent ID(s) rejected" if hallucinated else "")
                    + f"; confidence {semantic_result.confidence:.2f}."
                )
            logger.info("LLM stage: fields=%d lines=%d rejected_ids=%d",
                        len(llm_field_ids), len(semantic_result.relevant_field_ids) if semantic_result else 0,
                        hallucinated)
        except Exception as e:
            # Exception text may echo request details; log the type only.
            logger.warning("LLM reasoning failed (%s). Falling back to deterministic matching.",
                           type(e).__name__)
            message = str(e) if isinstance(e, (ConnectionError, TimeoutError, RuntimeError)) else type(e).__name__
            llm_status = f"Model unavailable ({message}); deterministic matching used."
            semantic_result = None

    # Deterministic privacy policy enforces the final boundary
    final_decision = apply_context_aware_policy(semantic_result, all_elements, user_query)
    final_decision.llm_used = use_llm
    final_decision.llm_status = llm_status
    final_decision.semantic_document_field_ids = llm_field_ids
    if semantic_result is not None:
        final_decision.confidence = semantic_result.confidence
        final_decision.llm_reasoning = (semantic_result.reasoning or "")[:300]
        model_answer = (semantic_result.answer or "").strip().lower()
        if model_answer and llm_field_ids:
            values = [f.value.strip().lower() for f in doc.fields if f.field_id in llm_field_ids]
            final_decision.llm_answer_verified = any(v and v in model_answer for v in values)

    logger.info(
        "Final privacy decision: %d KEEP, %d REDACT, %d HIDE",
        sum(1 for d in final_decision.decisions if d.action.is_keep()),
        sum(1 for d in final_decision.decisions if d.action.should_redact()),
        sum(1 for d in final_decision.decisions if d.action == RedactionAction.HIDE),
    )
    return final_decision
