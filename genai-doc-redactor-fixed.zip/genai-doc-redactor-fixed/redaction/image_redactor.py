from __future__ import annotations
import math
from PIL import Image, ImageDraw, ImageFilter, ImageFont
from ingestion.document_model import DocumentElement
from utils.logging_utils import get_logger

logger = get_logger("image_redactor")


def redact_image(
    image: Image.Image,
    elements_to_redact: list[DocumentElement],
    mode: str = "blackout",
    scale_x: float = 1.0,
    scale_y: float = 1.0,
    padding: int = 2,
) -> Image.Image:
    """Apply redaction to an image given elements and their bounding boxes.

    Args:
        image: Source image.
        elements_to_redact: Elements whose regions should be redacted.
        mode: "blackout", "blur", or "pixelate".
        scale_x, scale_y: Scale factors if bbox coordinates differ from image dimensions.
        padding: Extra pixels around each bbox.
    """
    result = image.copy()

    if not elements_to_redact:
        return result

    if mode == "blackout":
        result = _apply_blackout(result, elements_to_redact, scale_x, scale_y, padding)
    elif mode == "blur":
        result = _apply_blur(result, elements_to_redact, scale_x, scale_y, padding)
    elif mode == "pixelate":
        result = _apply_pixelate(result, elements_to_redact, scale_x, scale_y, padding)
    else:
        logger.warning("Unknown redaction mode '%s', using blackout", mode)
        result = _apply_blackout(result, elements_to_redact, scale_x, scale_y, padding)

    logger.info("Redacted %d regions using '%s' mode", len(elements_to_redact), mode)
    return result


def _get_box(el: DocumentElement, scale_x: float, scale_y: float, padding: int, img_w: int, img_h: int) -> tuple[int, int, int, int]:
    x0 = max(0, int(el.bbox[0] * scale_x) - padding)
    y0 = max(0, int(el.bbox[1] * scale_y) - padding)
    x1 = min(img_w, int(el.bbox[2] * scale_x) + padding)
    y1 = min(img_h, int(el.bbox[3] * scale_y) + padding)
    return (x0, y0, x1, y1)


def _apply_blackout(
    image: Image.Image,
    elements: list[DocumentElement],
    scale_x: float, scale_y: float, padding: int,
) -> Image.Image:
    draw = ImageDraw.Draw(image)
    for el in elements:
        box = _get_box(el, scale_x, scale_y, padding, image.width, image.height)
        draw.rectangle(box, fill="black")
    return image


def _apply_blur(
    image: Image.Image,
    elements: list[DocumentElement],
    scale_x: float, scale_y: float, padding: int,
) -> Image.Image:
    for el in elements:
        box = _get_box(el, scale_x, scale_y, padding, image.width, image.height)
        region = image.crop(box)
        blurred = region.filter(ImageFilter.GaussianBlur(radius=15))
        image.paste(blurred, box)
    return image


def _apply_pixelate(
    image: Image.Image,
    elements: list[DocumentElement],
    scale_x: float, scale_y: float, padding: int,
) -> Image.Image:
    for el in elements:
        box = _get_box(el, scale_x, scale_y, padding, image.width, image.height)
        region = image.crop(box)
        w, h = region.size
        if w < 1 or h < 1:
            continue
        small_w = max(1, w // 8)
        small_h = max(1, h // 8)
        small = region.resize((small_w, small_h), Image.NEAREST)
        pixelated = small.resize((w, h), Image.NEAREST)
        image.paste(pixelated, box)
    return image



def _replacement_font(size: int):
    for name in ("DejaVuSans.ttf", "arial.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _frosted_patch(width: int, height: int, pixelate: bool = False) -> Image.Image:
    """A data-independent blurred/pixelated placeholder of the given size."""
    import random
    rng = random.Random(width * 7919 + height)
    cell = 6
    small = Image.new("RGB", (max(1, width // cell), max(1, height // cell)))
    small.putdata([
        (v, v, v) for v in (rng.randint(105, 185) for _ in range(small.width * small.height))
    ])
    if pixelate:
        return small.resize((width, height), Image.NEAREST)
    patch = small.resize((width, height), Image.BILINEAR)
    return patch.filter(ImageFilter.GaussianBlur(radius=max(2, min(width, height) // 4)))


def selective_disclosure_image(
    image: Image.Image,
    keep_elements: list[DocumentElement],
    mode: str = "blackout",
    scale_x: float = 1.0,
    scale_y: float = 1.0,
    padding: int = 4,
    blur_elements: list[DocumentElement] | None = None,
    protected_elements: list[DocumentElement] | None = None,
    hidden_elements: list[DocumentElement] | None = None,
) -> Image.Image:
    """Render a minimum-disclosure image containing only KEEP elements.

    Start with a blank canvas, copy approved OCR regions, and blur sensitive
    regions that belong to the approved lines. Everything else stays hidden.
    """
    blur_elements = blur_elements or []
    protected_elements = protected_elements or []
    if not keep_elements and not blur_elements and not protected_elements:
        return Image.new(image.mode, image.size, "white")

    # White canvas gives true selective disclosure: unrelated text, table
    # lines, headers, and graphics are not present in the output.
    result = Image.new(image.mode, image.size, "white")

    for el in keep_elements:
        x0, y0, x1, y1 = _get_box(
            el, scale_x, scale_y, padding, image.width, image.height
        )
        if x1 <= x0 or y1 <= y0:
            continue

        crop = image.crop((x0, y0, x1, y1))

        # Keep the requested source pixels. Redaction mode is intentionally
        # irrelevant here because these are explicitly disclosed regions.
        result.paste(crop, (x0, y0))

    for el in blur_elements:
        char_count = max(len(el.text), 1)
        spans = el.sensitive_spans or [(0, char_count)]
        box_y0 = max(0, int(el.bbox[1] * scale_y) - max(padding, 8))
        box_y1 = min(image.height, int(el.bbox[3] * scale_y) + max(padding, 8))
        line_x0 = el.bbox[0] * scale_x
        line_width = max(0.0, (el.bbox[2] - el.bbox[0]) * scale_x)
        char_width = line_width / char_count
        extra = max(padding, int(char_width * 1.5))

        for start, end in spans:
            start = max(0, min(int(start), char_count))
            end = max(start, min(int(end), char_count))
            if end <= start:
                continue
            x0 = max(0, int(line_x0 + char_width * start) - extra)
            x1 = min(image.width, int(line_x0 + char_width * end) + extra)
            if x1 <= x0 or box_y1 <= box_y0:
                continue
            box = (x0, box_y0, x1, box_y1)
            region = image.crop(box)
            radius = max(18, min(60, max(region.size) // 4))
            result.paste(region.filter(ImageFilter.GaussianBlur(radius=radius)), (x0, box_y0))

    # Padding around a disclosed region can reach into a tightly spaced
    # neighbouring line; blank every hidden element's exact box afterwards
    # so no pixels of undisclosed text survive.
    draw = ImageDraw.Draw(result)
    for el in hidden_elements or []:
        box = _get_box(el, scale_x, scale_y, 0, image.width, image.height)
        if box[2] > box[0] and box[3] > box[1]:
            draw.rectangle(box, fill="white")

    # Protected value pixels are replaced outright on the fresh canvas. This
    # leaves no original text underneath a visual blur or transparent overlay.
    for el in protected_elements:
        box = _get_box(el, scale_x, scale_y, max(padding, 3), image.width, image.height)
        if box[2] <= box[0] or box[3] <= box[1]:
            continue
        if mode in ("blur", "pixelate"):
            # A blur of the real pixels can leak text shape and length, so the
            # blurred look is synthesised from noise instead of source pixels.
            result.paste(_frosted_patch(box[2] - box[0], box[3] - box[1], pixelate=mode == "pixelate"),
                         (box[0], box[1]))
        elif mode == "replacement":
            draw.rectangle(box, fill="black")
            label = "[PROTECTED]"
            size = max(8, int((box[3] - box[1]) * 0.6))
            font = _replacement_font(size)
            # Shrink until the label fits the protected box width.
            while size > 8 and draw.textlength(label, font=font) > box[2] - box[0] - 4:
                size -= 1
                font = _replacement_font(size)
            text_h = size
            draw.text((box[0] + 2, box[1] + max(0, (box[3] - box[1] - text_h) // 2)), label, fill="white", font=font)
        else:
            draw.rectangle(box, fill="black")

    return result


def render_visual_regions(
    canvas: Image.Image,
    original: Image.Image,
    regions: list,
    disclosed_ids: set[str],
    mode: str = "blackout",
) -> Image.Image:
    """Photos, QR codes, barcodes and signatures on the protected page.

    A disclosed region is copied from the original. A hidden one gets a
    labelled placeholder ("PHOTO HIDDEN") drawn in the chosen style, so the
    reader can see that something was removed. Nothing of a hidden region's
    pixels is used.
    """
    output = canvas.convert("RGB").copy()
    draw = ImageDraw.Draw(output)
    for region in regions:
        # Round outwards so the whole region is covered (or copied).
        x0, y0 = (int(math.floor(v)) for v in region.bbox[:2])
        x1, y1 = (int(math.ceil(v)) for v in region.bbox[2:])
        x0, y0 = max(0, x0), max(0, y0)
        x1, y1 = min(output.width, x1), min(output.height, y1)
        if x1 - x0 < 4 or y1 - y0 < 4:
            continue
        if region.region_id in disclosed_ids:
            output.paste(original.convert("RGB").crop((x0, y0, x1, y1)), (x0, y0))
            continue
        if mode in ("blur", "pixelate"):
            output.paste(_frosted_patch(x1 - x0, y1 - y0, pixelate=mode == "pixelate"), (x0, y0))
            text_fill, outline = (40, 40, 40), (120, 120, 120)
        elif mode == "replacement":
            draw.rectangle([x0, y0, x1, y1], fill=(236, 239, 243), outline=(120, 120, 120), width=2)
            text_fill, outline = (60, 60, 60), None
        else:
            draw.rectangle([x0, y0, x1, y1], fill=(0, 0, 0))
            text_fill, outline = (255, 255, 255), None
        label = f"{region.label.upper()} HIDDEN"
        size = max(8, min(28, (y1 - y0) // 3))
        font = _replacement_font(int(size))
        box = draw.textbbox((0, 0), label, font=font)
        while size > 8 and box[2] - box[0] > (x1 - x0) - 10:  # fit the width
            size -= 1
            font = _replacement_font(int(size))
            box = draw.textbbox((0, 0), label, font=font)
        tx = x0 + ((x1 - x0) - (box[2] - box[0])) // 2
        ty = y0 + ((y1 - y0) - (box[3] - box[1])) // 2
        draw.text((tx, ty), label, fill=text_fill, font=font)
    return output
