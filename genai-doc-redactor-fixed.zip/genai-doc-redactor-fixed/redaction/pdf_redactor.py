from __future__ import annotations
from pathlib import Path
from PIL import Image
from utils.logging_utils import get_logger

logger = get_logger("pdf_redactor")


def images_to_pdf(images: list[Image.Image], output_path: Path) -> Path:
    """Combine a list of PIL images into a single PDF."""
    if not images:
        raise ValueError("No images to combine into PDF")

    rgb_images = [img.convert("RGB") for img in images]
    rgb_images[0].save(
        str(output_path),
        "PDF",
        save_all=True,
        append_images=rgb_images[1:] if len(rgb_images) > 1 else [],
        resolution=200,
        # Neutral metadata: nothing about the source document or its owner.
        title="Protected document",
        author="",
        producer="Privacy Agent",
    )
    logger.info("Created redacted PDF with %d pages: %s", len(images), output_path.name)
    return output_path
