"""Traceable copies: an invisible watermark naming who a copy was made for.

When a recipient is given, every protected page carries an invisible mark.
If the copy later turns up somewhere it should not, ``trace_file`` reads the
mark back and the local ledger says who it was made for and when.

How it works
  * Payload: a random 32-bit trace ID + a 16-bit checksum (48 bits).
  * The page is divided into 32x32-pixel blocks; each block carries one bit
    of the payload (the 48 bits repeat across the page, dozens of times).
  * A bit is written by adding a faint +/- pattern (4 grey levels) to the
    block. The pattern is derived from a secret key stored only on this
    computer, so others can neither read nor forge the mark.
  * Reading correlates each block with its pattern and lets every repeat of
    a bit vote. This survives the JPEG compression used for PDF and JPG
    outputs.
  * The ledger (data/trace_ledger.json) maps trace IDs to recipient, date,
    document type and format. It never contains document values.

Limits: the mark is read from the protected file itself (PDF, DOCX, PNG, JPG
or ZIP as produced). A photo of a screen, a printout, or a resized/cropped
copy is not supported.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import secrets
import threading
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from PIL import Image

from config import DATA_DIR
from utils.logging_utils import get_logger

logger = get_logger("watermark")

BLOCK = 32
CELL = 8            # pattern resolution inside a block (low frequency survives JPEG)
STRENGTH = 4.0      # grey levels
FLAT_STD = 8.0      # blocks busier than this (text, edges) are ignored when reading
ID_BITS, CHECK_BITS = 32, 16
PAYLOAD_BITS = ID_BITS + CHECK_BITS

_KEY_FILE = DATA_DIR / "watermark.key"
_LEDGER_FILE = DATA_DIR / "trace_ledger.json"
_lock = threading.Lock()


def _key() -> bytes:
    with _lock:
        if not _KEY_FILE.exists():
            DATA_DIR.mkdir(exist_ok=True)
            _KEY_FILE.write_bytes(secrets.token_bytes(32))
        return _KEY_FILE.read_bytes()


def _patterns(key: bytes) -> np.ndarray:
    """One balanced +/-1 pattern per payload bit position (BLOCK x BLOCK)."""
    seed = int.from_bytes(hashlib.sha256(key + b"watermark-v1").digest()[:8], "big")
    rng = np.random.default_rng(seed)
    cells = (BLOCK // CELL) ** 2
    out = np.empty((PAYLOAD_BITS, BLOCK, BLOCK), dtype=np.float32)
    for bit in range(PAYLOAD_BITS):
        signs = np.array([1.0] * (cells // 2) + [-1.0] * (cells - cells // 2))
        rng.shuffle(signs)
        grid = signs.reshape(BLOCK // CELL, BLOCK // CELL)
        out[bit] = np.kron(grid, np.ones((CELL, CELL)))
    return out


def _checksum(value: int) -> int:
    # 16 bits: an unmarked page passes by chance about 1 time in 65,536.
    return int.from_bytes(hashlib.sha256(value.to_bytes(4, "big")).digest()[:2], "big")


def _bits(trace_id: int) -> np.ndarray:
    payload = (trace_id << CHECK_BITS) | _checksum(trace_id)
    return np.array([(payload >> (PAYLOAD_BITS - 1 - i)) & 1 for i in range(PAYLOAD_BITS)], dtype=np.int8)


def _block_bit(row: int, col: int, cols: int) -> int:
    return (row * cols + col) % PAYLOAD_BITS


def embed(image: Image.Image, trace_id: int) -> Image.Image:
    """Return a copy of the page carrying the trace ID."""
    patterns = _patterns(_key())
    bits = _bits(trace_id)
    pixels = np.asarray(image.convert("RGB"), dtype=np.float32).copy()
    rows, cols = pixels.shape[0] // BLOCK, pixels.shape[1] // BLOCK
    for r in range(rows):
        for c in range(cols):
            bit = _block_bit(r, c, cols)
            sign = 1.0 if bits[bit] else -1.0
            mark = STRENGTH * sign * patterns[bit]
            pixels[r * BLOCK:(r + 1) * BLOCK, c * BLOCK:(c + 1) * BLOCK, :] += mark[:, :, None]
    return Image.fromarray(np.clip(np.round(pixels), 0, 255).astype(np.uint8))


def read(image: Image.Image) -> tuple[int | None, float]:
    """(trace ID or None, confidence 0..1) for one page."""
    patterns = _patterns(_key())
    gray = np.asarray(image.convert("L"), dtype=np.float32)
    rows, cols = gray.shape[0] // BLOCK, gray.shape[1] // BLOCK
    if rows * cols < PAYLOAD_BITS:
        return None, 0.0
    votes = np.zeros(PAYLOAD_BITS)
    weight = np.zeros(PAYLOAD_BITS)
    for r in range(rows):
        for c in range(cols):
            bit = _block_bit(r, c, cols)
            block = gray[r * BLOCK:(r + 1) * BLOCK, c * BLOCK:(c + 1) * BLOCK]
            block = block - block.mean()
            # Text and mask edges are far louder than the mark; only flat
            # blocks (background, solid masks) carry a clean vote.
            if block.std() > FLAT_STD:
                continue
            votes[bit] += float((block * patterns[bit]).sum())
            weight[bit] += float(np.abs(block).sum()) + 1e-6
    bits = (votes > 0).astype(int)
    payload = 0
    for b in bits:
        payload = (payload << 1) | int(b)
    trace_id, check = payload >> CHECK_BITS, payload & ((1 << CHECK_BITS) - 1)
    confidence = float(np.mean(np.abs(votes) / weight))
    if check != _checksum(trace_id):
        return None, confidence
    return trace_id, confidence


# ── Ledger ────────────────────────────────────────────────────────────────

def _load_ledger() -> dict:
    if not _LEDGER_FILE.exists():
        return {}
    try:
        return json.loads(_LEDGER_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def register(recipient: str, document_type: str, output_format: str, pages: int) -> int:
    """Create a trace ID for a copy and record who it is for."""
    recipient = " ".join(recipient.split())[:120]
    with _lock:
        ledger = _load_ledger()
        while True:
            trace_id = secrets.randbits(ID_BITS)
            if f"{trace_id:08x}" not in ledger:
                break
        ledger[f"{trace_id:08x}"] = {
            "recipient": recipient,
            "created": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
            "document_type": document_type,
            "output_format": output_format,
            "pages": pages,
        }
        DATA_DIR.mkdir(exist_ok=True)
        tmp = _LEDGER_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(ledger, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _LEDGER_FILE)
    logger.info("Trace ID issued for a %s copy (%d page(s))", output_format, pages)
    return trace_id


def lookup(trace_id: int) -> dict | None:
    entry = _load_ledger().get(f"{trace_id:08x}")
    return dict(entry, trace_id=f"{trace_id:08x}") if entry else None


# ── Reading a file ────────────────────────────────────────────────────────

def _page_images(path: Path) -> list[Image.Image]:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        import pymupdf as fitz
        images = []
        with fitz.open(str(path)) as pdf:
            for page in pdf:
                for info in page.get_images(full=True):
                    data = pdf.extract_image(info[0])["image"]
                    images.append(Image.open(io.BytesIO(data)).convert("RGB"))
        return images
    if suffix in (".docx", ".zip"):
        images = []
        with zipfile.ZipFile(path) as archive:
            for name in sorted(archive.namelist()):
                if name.lower().endswith((".png", ".jpg", ".jpeg")):
                    images.append(Image.open(io.BytesIO(archive.read(name))).convert("RGB"))
        return images
    if suffix in (".png", ".jpg", ".jpeg"):
        return [Image.open(path).convert("RGB")]
    return []


def trace_file(path: Path) -> dict:
    """Who a protected copy was made for, if it carries a trace mark."""
    try:
        images = _page_images(path)
    except Exception:
        return {"found": False, "reason": "The file could not be read as a protected document."}
    if not images:
        return {"found": False, "reason": "No page images found in the file."}
    found: dict[int, float] = {}
    for image in images:
        trace_id, confidence = read(image)
        if trace_id is not None:
            found[trace_id] = max(found.get(trace_id, 0.0), confidence)
    if not found:
        return {"found": False, "reason": "No trace mark found (the copy was not traced, or it was altered)."}
    trace_id = max(found, key=found.get)
    entry = lookup(trace_id)
    if entry is None:
        return {"found": False, "reason": "A trace mark was found, but it is not in this computer's ledger."}
    return {"found": True, "pages_checked": len(images), **entry}
