"""Writers for image-based protected output formats."""
from __future__ import annotations

from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

from PIL import Image


def images_to_raster_output(images: list[Image.Image], output_path: Path, output_format: str) -> Path:
    """Write one image or package multiple protected pages in a ZIP."""
    if not images:
        raise ValueError("No protected pages to save")
    output_format = output_format.upper()
    if output_format not in {"PNG", "JPG", "JPEG"}:
        raise ValueError(f"Unsupported raster format: {output_format}")
    image_format = "PNG" if output_format == "PNG" else "JPEG"
    extension = ".png" if image_format == "PNG" else ".jpg"

    if len(images) == 1:
        path = output_path.with_suffix(extension)
        images[0].convert("RGB").save(path, format=image_format)
        return path

    bundle_path = output_path.with_suffix(".zip")
    with ZipFile(bundle_path, "w") as bundle:
        for page_num, image in enumerate(images, start=1):
            page_bytes = BytesIO()
            image.convert("RGB").save(page_bytes, format=image_format)
            bundle.writestr(
                f"protected_page_{page_num:03d}{extension}", page_bytes.getvalue()
            )
    return bundle_path
