"""Create a fresh DOCX containing only protected page images.

The package is written directly as Office Open XML with ``zipfile`` so the
export does not depend on ``python-docx``/``lxml`` (lxml's native module can be
blocked by Windows application-control policies).
"""
from __future__ import annotations

from io import BytesIO
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from PIL import Image

_EMU_PER_INCH = 914400
_PAGE_W_IN, _PAGE_H_IN, _MARGIN_IN = 8.5, 11.0, 0.5

_CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="png" ContentType="image/png"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""

_ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

# Neutral metadata: no author, title, or source information.
_CORE = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>Protected document</dc:title>
</cp:coreProperties>"""

_APP = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Privacy Agent</Application></Properties>"""

_DRAWING = """<w:p><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr><w:r>{page_break}<w:drawing>
<wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/><wp:docPr id="{n}" name="Page {n}"/>
<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="{n}" name="page{n}.png"/><pic:cNvPicPr/></pic:nvPicPr>
<pic:blipFill><a:blip r:embed="rIdImg{n}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>
</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"""


def images_to_docx(images: list[Image.Image], output_path: Path) -> Path:
    """Package sanitized page images in a new Word document.

    The source document is never embedded, so hidden source text, comments,
    relationships, and metadata cannot be carried into the protected DOCX.
    """
    if not images:
        raise ValueError("No protected pages to add to DOCX")

    max_w = int((_PAGE_W_IN - 2 * _MARGIN_IN) * _EMU_PER_INCH)
    max_h = int((_PAGE_H_IN - 2 * _MARGIN_IN) * _EMU_PER_INCH)
    paragraphs, rels, media = [], [], []
    for n, image in enumerate(images, start=1):
        scale = min(max_w / image.width, max_h / image.height)
        cx, cy = int(image.width * scale), int(image.height * scale)
        paragraphs.append(_DRAWING.format(
            n=n, cx=cx, cy=cy, page_break='<w:br w:type="page"/>' if n > 1 else "",
        ))
        rels.append(
            f'<Relationship Id="rIdImg{n}" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
            f'relationships/image" Target="media/page{n}.png"/>'
        )
        buffer = BytesIO()
        image.convert("RGB").save(buffer, format="PNG")
        media.append((f"word/media/page{n}.png", buffer.getvalue()))

    margin = int(_MARGIN_IN * 1440)
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">'
        "<w:body>" + "".join(paragraphs)
        + f'<w:sectPr><w:pgSz w:w="{int(_PAGE_W_IN * 1440)}" w:h="{int(_PAGE_H_IN * 1440)}"/>'
        f'<w:pgMar w:top="{margin}" w:right="{margin}" w:bottom="{margin}" w:left="{margin}" '
        'w:header="0" w:footer="0" w:gutter="0"/></w:sectPr></w:body></w:document>'
    )
    document_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + "".join(rels) + "</Relationships>"
    )

    output_path = Path(output_path)
    with ZipFile(output_path, "w", ZIP_DEFLATED) as package:
        package.writestr("[Content_Types].xml", _CONTENT_TYPES)
        package.writestr("_rels/.rels", _ROOT_RELS)
        package.writestr("docProps/core.xml", _CORE)
        package.writestr("docProps/app.xml", _APP)
        package.writestr("word/document.xml", document)
        package.writestr("word/_rels/document.xml.rels", document_rels)
        for name, data in media:
            package.writestr(name, data)
    return output_path
