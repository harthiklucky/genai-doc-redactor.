"""Post-export check that protected values cannot be read back from the output.

Two independent checks, both run on this machine:

1. File content: no protected value may appear in any machine-readable text
   of the exported file: PDF text layer and metadata, DOCX/ZIP XML parts and
   file names, image text chunks and EXIF.
2. OCR (optional, slower): the protected page images are read back with the
   local OCR engine, and no protected value may appear in what it reads.

Only values that are expected to be hidden are checked; text that is meant to
be visible (disclosed values, field labels, the page heading) is excluded so
it cannot cause false alarms. The report holds counts only, never values.
"""
from __future__ import annotations

import re
import zipfile
from pathlib import Path

from PIL import Image

from utils.logging_utils import get_logger

logger = get_logger("leak_check")

MIN_CHECK_CHARS = 4


def _norm(text: str) -> str:
    return re.sub(r"[^0-9a-z]", "", text.lower())


def checkable_values(protected_texts, visible_texts) -> list[str]:
    """Protected values worth checking: long enough, and not also legitimately visible."""
    visible = _norm(" ".join(visible_texts))
    values = []
    for text in protected_texts:
        norm = _norm(text)
        if len(norm) >= MIN_CHECK_CHARS and norm not in visible and norm not in values:
            values.append(norm)
    return values


_TEXT_MEMBERS = (".xml", ".rels", ".txt", ".json", ".csv", ".html")
_IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg")


def _image_text(data: bytes) -> list[str]:
    """Text an image file carries besides its pixels (PNG text chunks, EXIF)."""
    import io
    with Image.open(io.BytesIO(data)) as image:
        parts = [str(v) for v in image.info.values() if isinstance(v, (str, bytes))]
        parts += [str(v) for v in image.getexif().values()]
    return parts


def _xml_text(xml: str) -> list[str]:
    """Text nodes and attribute values of an XML part (not its markup)."""
    parts = [t for t in re.split(r"<[^>]*>", xml) if t.strip()]
    parts += [v for v in re.findall(r'="([^"]*)"', xml) if v and not v.startswith("http")]
    return parts


def _embedded_text(path: Path) -> list[str]:
    """Every piece of machine-readable text in the exported file."""
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        import pymupdf as fitz
        with fitz.open(str(path)) as pdf:
            parts = [page.get_text() for page in pdf]
            parts += [str(v) for v in (pdf.metadata or {}).values() if v]
            parts += _xml_text(pdf.get_xml_metadata() or "")
        return parts
    if suffix in (".docx", ".zip"):
        parts = []
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                parts.append(name)
                data = archive.read(name)
                if name.lower().endswith(_TEXT_MEMBERS):
                    parts += _xml_text(data.decode("utf-8", "ignore"))
                elif name.lower().endswith(_IMAGE_SUFFIXES):
                    parts += _image_text(data)
        return parts
    if suffix in _IMAGE_SUFFIXES:
        return _image_text(path.read_bytes())
    return [path.read_bytes().decode("utf-8", "ignore")]


def _ocr_text(images: list[Image.Image]) -> str:
    from ocr.factory import get_ocr_engine
    engine = get_ocr_engine()
    return " ".join(
        el.text for index, image in enumerate(images) for el in engine.extract(image, page_num=index + 1)
    )


def verify_protected_output(
    output_path: Path | None,
    redacted_images: list[Image.Image],
    protected_texts: list[str],
    visible_texts: list[str],
    use_ocr: bool = False,
) -> dict:
    """Return {"status": "passed"|"failed", ...counts}. Never includes values."""
    values = checkable_values(protected_texts, visible_texts)
    report = {
        "status": "passed",
        "values_checked": len(values),
        "file_leaks": 0,
        "ocr_checked": False,
        "ocr_leaks": 0,
    }
    if output_path is not None and output_path.exists():
        embedded = [_norm(part) for part in _embedded_text(output_path)]
        report["file_leaks"] = sum(
            1 for value in values if any(value in part for part in embedded)
        )
    if use_ocr and values and redacted_images:
        read_back = _norm(_ocr_text(redacted_images))
        report["ocr_checked"] = True
        report["ocr_leaks"] = sum(1 for value in values if value in read_back)
    if report["file_leaks"] or report["ocr_leaks"]:
        report["status"] = "failed"
    logger.info(
        "Leak check %s: %d value(s) checked, file leaks=%d, OCR %s leaks=%d",
        report["status"], report["values_checked"], report["file_leaks"],
        "on" if report["ocr_checked"] else "off", report["ocr_leaks"],
    )
    return report
