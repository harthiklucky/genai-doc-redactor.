from __future__ import annotations
from abc import ABC, abstractmethod
from PIL import Image
from ingestion.document_model import DocumentElement


class BaseOCR(ABC):
    @abstractmethod
    def extract(self, image: Image.Image, page_num: int = 1) -> list[DocumentElement]:
        """Extract text elements with bounding boxes from an image."""
        ...
