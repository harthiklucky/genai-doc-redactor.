from __future__ import annotations
import numpy as np
from PIL import Image
from ingestion.document_model import DocumentElement
from ocr.base_ocr import BaseOCR
from utils.logging_utils import get_logger

logger = get_logger("paddle_ocr")

_paddle_instance = None


def _get_paddle():
    global _paddle_instance
    if _paddle_instance is None:
        from paddleocr import PaddleOCR
        _paddle_instance = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)
    return _paddle_instance


class PaddleOCREngine(BaseOCR):
    def __init__(self):
        self._counter = 0

    def extract(self, image: Image.Image, page_num: int = 1) -> list[DocumentElement]:
        ocr = _get_paddle()
        img_array = np.array(image)
        results = ocr.ocr(img_array, cls=True)

        elements = []
        if not results or not results[0]:
            logger.warning("No OCR results for page %d", page_num)
            return elements

        for line in results[0]:
            bbox_points = line[0]  # [[x1,y1],[x2,y2],[x3,y3],[x4,y4]]
            text, conf = line[1]
            text = text.strip()
            if not text:
                continue

            xs = [p[0] for p in bbox_points]
            ys = [p[1] for p in bbox_points]
            x0, y0 = min(xs), min(ys)
            x1, y1 = max(xs), max(ys)

            self._counter += 1
            elements.append(DocumentElement(
                id=f"field_{self._counter:04d}",
                text=text,
                bbox=[x0, y0, x1, y1],
                page=page_num,
                confidence=float(conf),
            ))

        logger.info("OCR extracted %d elements from page %d", len(elements), page_num)
        return elements

    def reset_counter(self):
        self._counter = 0
