from ocr.base_ocr import BaseOCR
from config import OCR_ENGINE


def get_ocr_engine() -> BaseOCR:
    if OCR_ENGINE == "easyocr":
        from ocr.easyocr_engine import EasyOCREngine
        return EasyOCREngine()
    elif OCR_ENGINE == "paddleocr":
        from ocr.paddle_ocr import PaddleOCREngine
        return PaddleOCREngine()
    elif OCR_ENGINE == "tesseract":
        from ocr.tesseract_ocr import TesseractOCREngine
        return TesseractOCREngine()
    else:
        raise ValueError(f"Unknown OCR engine: {OCR_ENGINE}. Use 'easyocr', 'paddleocr', or 'tesseract'.")
