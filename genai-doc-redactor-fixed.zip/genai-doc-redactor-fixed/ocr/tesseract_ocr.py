from __future__ import annotations
from PIL import Image
from ingestion.document_model import DocumentElement
from ocr.base_ocr import BaseOCR
from utils.logging_utils import get_logger

logger = get_logger("tesseract_ocr")


class TesseractOCREngine(BaseOCR):
    def __init__(self):
        self._counter = 0

    def extract(self, image: Image.Image, page_num: int = 1) -> list[DocumentElement]:
        try:
            import pytesseract
        except ImportError:
            raise RuntimeError("pytesseract not installed. Install with: pip install pytesseract")

        data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
        elements = []
        n = len(data["text"])

        for i in range(n):
            text = data["text"][i].strip()
            try:
                conf = float(data["conf"][i])
            except (TypeError, ValueError):
                continue
            if not text or conf < 30:
                continue

            x = data["left"][i]
            y = data["top"][i]
            w = data["width"][i]
            h = data["height"][i]

            self._counter += 1
            elements.append(DocumentElement(
                id=f"field_{self._counter:04d}",
                text=text,
                bbox=[x, y, x + w, y + h],
                page=page_num,
                confidence=conf / 100.0,
            ))

        logger.info("Tesseract extracted %d elements from page %d", len(elements), page_num)
        return elements

    def reset_counter(self):
        self._counter = 0
