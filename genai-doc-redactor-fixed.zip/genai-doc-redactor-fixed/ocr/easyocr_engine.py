from __future__ import annotations
import numpy as np
from PIL import Image
from ingestion.document_model import DocumentElement
from ocr.base_ocr import BaseOCR
from utils.logging_utils import get_logger

logger = get_logger("easyocr")

_reader = None


def _get_reader():
    global _reader
    if _reader is None:
        import easyocr
        from config import ALLOW_MODEL_DOWNLOADS
        try:
            # Models are loaded from the local model folder; nothing is
            # fetched at run time unless downloads were explicitly allowed.
            _reader = easyocr.Reader(
                ["en"], gpu=False, verbose=False, download_enabled=ALLOW_MODEL_DOWNLOADS,
            )
        except FileNotFoundError:
            raise RuntimeError(
                "EasyOCR models are not installed locally. Run once: python setup_models.py"
            ) from None
    return _reader


class EasyOCREngine(BaseOCR):
    def __init__(self):
        self._counter = 0

    def extract(self, image: Image.Image, page_num: int = 1) -> list[DocumentElement]:
        reader = _get_reader()
        img_array = np.array(image)
        results = reader.readtext(img_array)

        elements = []
        for bbox_points, text, conf in results:
            text = text.strip()
            if not text:
                continue

            xs = [p[0] for p in bbox_points]
            ys = [p[1] for p in bbox_points]
            x0, y0 = min(xs), min(ys)
            x1, y1 = max(xs), max(ys)

            self._counter += 1
            elements.append(DocumentElement(
                id=f"field_{self._counter:04d}",
                text=text,
                bbox=[float(x0), float(y0), float(x1), float(y1)],
                page=page_num,
                confidence=float(conf),
            ))

        logger.info("EasyOCR extracted %d elements from page %d", len(elements), page_num)
        return elements

    def reset_counter(self):
        self._counter = 0
