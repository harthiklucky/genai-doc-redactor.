import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
TEMP_DIR = BASE_DIR / "temp"

for d in [UPLOAD_DIR, OUTPUT_DIR, TEMP_DIR]:
    d.mkdir(exist_ok=True)

LLM_PROVIDER = "ollama"
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5:7b")
# qwen2.5:7b on CPU needs roughly a minute per request; allow headroom.
OLLAMA_TIMEOUT = int(os.getenv("OLLAMA_TIMEOUT", "240"))

OCR_ENGINE = os.getenv("OCR_ENGINE", "easyocr")
MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", "50"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# Local-only mode (default on): outbound connections to anything other than
# this machine are blocked for the whole app process, and OCR/NLP models are
# never downloaded at run time. Set LOCAL_ONLY=false only for troubleshooting.
LOCAL_ONLY = os.getenv("LOCAL_ONLY", "true").strip().lower() not in {"0", "false", "no", "off"}
# OCR models must already be on disk unless this is set (e.g. for a one-time
# setup run): python setup_models.py
ALLOW_MODEL_DOWNLOADS = os.getenv("ALLOW_MODEL_DOWNLOADS", "false").strip().lower() in {"1", "true", "yes", "on"}
# Uploaded originals and generated outputs are deleted after this many minutes.
RETENTION_MINUTES = int(os.getenv("RETENTION_MINUTES", "60"))

# Local data: the watermark key and the traced-copies ledger (never document
# values). Kept out of git.
DATA_DIR = BASE_DIR / "data"
