from __future__ import annotations
from PIL import Image, ImageDraw, ImageFont
from agents.schemas import PrivacyDecisionResponse


def add_secure_document_heading(image: Image.Image, document_type: str) -> Image.Image:
    """Add a clear type label above the secured first-page content."""
    title = f"SECURE COPY — {document_type or 'Document'}"
    font_size = max(18, min(42, int(image.width / max(len(title) * 0.7, 1))))
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", font_size)
    except OSError:
        try:
            font = ImageFont.truetype("arial.ttf", font_size)
        except OSError:
            font = ImageFont.load_default()
    header_height = max(76, font_size + 32)
    output = Image.new("RGB", (image.width, image.height + header_height), "white")
    draw = ImageDraw.Draw(output)
    draw.text((32, 18), title, fill=(24, 48, 82), font=font)
    draw.line((32, header_height - 12, image.width - 32, header_height - 12), fill=(95, 125, 160), width=2)
    output.paste(image.convert("RGB"), (0, header_height))
    return output


def get_privacy_summary(response: PrivacyDecisionResponse) -> dict:
    """Generate a structured privacy summary for the UI."""
    visible = []
    redacted = []
    categories_hidden = set()
    categories_shown = set()

    ignored = []
    hidden = []

    for d in response.decisions:
        if d.action.is_keep():
            visible.append({"field_id": d.field_id, "category": d.category, "reason": d.reason})
            categories_shown.add(d.category)
        elif d.action.should_redact():
            redacted.append({"field_id": d.field_id, "category": d.category, "reason": d.reason})
            categories_hidden.add(d.category)
        else:
            item = {"field_id": d.field_id, "category": d.category, "reason": d.reason}
            ignored.append(item)
            hidden.append(item)

    return {
        "total_fields": len(response.decisions),
        "visible_count": len(visible),
        "redacted_count": len(redacted),
        "ignored_count": len(ignored),
        "hidden_count": len(hidden),
        "visible_fields": visible,
        "redacted_fields": redacted,
        "ignored_fields": ignored,
        "hidden_fields": hidden,
        "categories_hidden": sorted(categories_hidden),
        "categories_shown": sorted(categories_shown),
    }
