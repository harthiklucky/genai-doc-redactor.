import logging
import sys
from config import LOG_LEVEL


class SensitiveFilter(logging.Filter):
    REDACT_KEYWORDS = ["password", "api_key", "token", "secret", "ssn", "credit_card"]

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage().lower()
        for kw in self.REDACT_KEYWORDS:
            if kw in msg:
                record.msg = "[REDACTED SENSITIVE LOG]"
                record.args = None
                break
        return True


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            logging.Formatter("%(asctime)s [%(name)s] %(levelname)s: %(message)s", datefmt="%H:%M:%S")
        )
        handler.addFilter(SensitiveFilter())
        logger.addHandler(handler)
        logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
    return logger
