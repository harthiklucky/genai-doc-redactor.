"""Process-wide guard that keeps document processing on this machine.

When enabled, every outbound network connection and every DNS lookup made by
Python code in this process is checked: loopback addresses (the local Ollama
server, the Streamlit UI itself) are allowed, anything else is refused before
a packet leaves the machine. The check is a ``sys.addaudithook`` on the
``socket.connect`` / ``socket.getaddrinfo`` audit events, so it covers every
library that uses Python sockets (requests, urllib, model downloaders, ...).

Native code that opens sockets without going through Python's ``socket``
module is not covered; none of this project's dependencies do that for
document processing.
"""
from __future__ import annotations

import ipaddress
import os
import socket
import sys
import threading

from utils.logging_utils import get_logger

logger = get_logger("network_guard")

_LOCAL_NAMES = {"localhost", "localhost.localdomain", "ip6-localhost", "ip6-loopback"}

_state = {"installed": False, "enabled": False, "blocked": 0}
_lock = threading.Lock()


class NonLocalConnectionBlocked(ConnectionError):
    """Raised when code tries to reach a host that is not this machine."""


def is_local_host(host) -> bool:
    """True for loopback addresses and names, and for local (Unix) sockets."""
    if host is None:
        return True
    if isinstance(host, bytes):
        host = host.decode("ascii", "ignore")
    host = str(host).strip().strip("[]").lower()
    if not host or host in _LOCAL_NAMES or host.endswith(".localhost"):
        return True
    try:
        return ipaddress.ip_address(host.split("%", 1)[0]).is_loopback
    except ValueError:
        return False


def _target_host(event: str, args) -> object:
    if event == "socket.connect":
        address = args[1]
        if isinstance(address, (str, bytes)):  # AF_UNIX path
            return None
        return address[0] if address else None
    return args[0]  # socket.getaddrinfo(host, port, ...)


def _audit(event: str, args) -> None:
    if not _state["enabled"] or event not in ("socket.connect", "socket.getaddrinfo"):
        return
    if event == "socket.connect" and getattr(args[0], "family", None) not in (
        socket.AF_INET, socket.AF_INET6,
    ):
        return
    host = _target_host(event, args)
    if is_local_host(host):
        return
    with _lock:
        _state["blocked"] += 1
    # The host name is not document content, but keep the log minimal anyway.
    logger.warning("Blocked a non-local network request (%s)", event)
    raise NonLocalConnectionBlocked(
        "Local-only mode blocked a connection to a host outside this machine."
    )


def enable() -> None:
    """Turn the guard on (installing the audit hook on first use)."""
    with _lock:
        if not _state["installed"]:
            sys.addaudithook(_audit)
            _state["installed"] = True
        _state["enabled"] = True


def activate_local_only() -> None:
    """Local-only mode: tell model libraries to stay offline, then guard sockets."""
    for name in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_DATASETS_OFFLINE"):
        os.environ.setdefault(name, "1")
    os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
    os.environ.setdefault("DO_NOT_TRACK", "1")
    enable()


def disable() -> None:
    """Turn the guard off. The audit hook stays installed but inert."""
    _state["enabled"] = False


def is_enabled() -> bool:
    return _state["enabled"]


def blocked_count() -> int:
    return _state["blocked"]
