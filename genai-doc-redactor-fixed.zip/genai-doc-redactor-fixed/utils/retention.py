"""Retention: uploaded originals and generated outputs do not linger on disk."""
from __future__ import annotations

import time
from pathlib import Path

from config import OUTPUT_DIR, RETENTION_MINUTES, TEMP_DIR, UPLOAD_DIR
from utils.logging_utils import get_logger

logger = get_logger("retention")

_KEEP = {".gitkeep"}


def _managed_dirs() -> tuple[Path, ...]:
    return (UPLOAD_DIR, OUTPUT_DIR, TEMP_DIR)


def purge_expired(max_age_minutes: int | None = None, now: float | None = None) -> int:
    """Delete files in the upload, output and temp folders older than the limit.

    Returns the number of files removed. A limit of 0 or less disables the purge.
    """
    limit = RETENTION_MINUTES if max_age_minutes is None else max_age_minutes
    if limit <= 0:
        return 0
    cutoff = (time.time() if now is None else now) - limit * 60
    removed = 0
    for folder in _managed_dirs():
        if not folder.exists():
            continue
        for path in folder.iterdir():
            if not path.is_file() or path.name in _KEEP:
                continue
            try:
                if path.stat().st_mtime < cutoff:
                    path.unlink()
                    removed += 1
            except OSError:
                pass
    if removed:
        logger.info("Retention: removed %d expired file(s)", removed)
    return removed


def delete_files(paths) -> int:
    """Delete specific files, but only inside the app's own data folders."""
    roots = [folder.resolve() for folder in _managed_dirs()]
    removed = 0
    for raw in paths:
        if not raw:
            continue
        path = Path(raw)
        try:
            resolved = path.resolve()
        except OSError:
            continue
        if resolved.parent not in roots or resolved.name in _KEEP:
            continue
        try:
            resolved.unlink(missing_ok=True)
            removed += 1
        except OSError:
            pass
    return removed
