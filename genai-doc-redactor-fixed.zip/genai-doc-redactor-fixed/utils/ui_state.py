"""Helpers that keep displayed results tied to the inputs that produced them."""
from __future__ import annotations

import hashlib
import json


def request_signature(
    upload_digest: str,
    query: str,
    privacy_mode: str,
    redaction_mode: str,
    output_format: str,
    model: str,
    llm_mode: str,
    reviewed_field_ids=None,
    verify_output: bool = False,
    reviewed_visual_ids=None,
    recipient: str = "",
) -> str:
    """Digest of every input that changes the answer or the protected file.

    The query is hashed rather than stored so session state does not keep
    another plain copy of user-entered text.
    """
    payload = json.dumps(
        [upload_digest, (query or "").strip(), privacy_mode, redaction_mode,
         output_format, model, llm_mode,
         sorted(reviewed_field_ids) if reviewed_field_ids is not None else None,
         bool(verify_output),
         sorted(reviewed_visual_ids) if reviewed_visual_ids is not None else None,
         (recipient or "").strip()],
        ensure_ascii=False,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def result_is_current(state: dict, signature: str) -> bool:
    """A stored result may be shown only for the exact inputs that made it."""
    return "result" in state and state.get("result_signature") == signature


def store_result(state: dict, result, signature: str, query: str) -> None:
    state["result"] = result
    state["result_signature"] = signature
    state["user_query"] = query


def clear_result(state: dict) -> None:
    for key in ("result", "result_signature", "user_query"):
        state.pop(key, None)
