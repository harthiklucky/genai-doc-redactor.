"""Conservative document-type labels derived from visible document wording."""
from __future__ import annotations

import re
from ingestion.document_model import DocumentElement


_DOCUMENT_TYPES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Birth Certificate", ("birth certificate", "certificate of birth", "certificate of live birth")),
    ("Aadhaar Card", ("aadhaar", "aadhar", "uidai", "unique identification authority of india")),
    ("PAN Card", ("pan card", "permanent account number")),
    ("Voter ID Card", ("voter id", "voter identity", "election photo identity")),
    ("Driving Licence", ("driving licence", "driving license", "driver's license", "driver license")),
    ("Passport", ("passport",)),
    ("Death Certificate", ("death certificate", "certificate of death")),
    ("Marriage Certificate", ("marriage certificate", "certificate of marriage")),
    ("Medical Record", ("medical report", "medical record", "patient record", "clinical report")),
    ("Prescription", ("prescription", "medication order")),
    ("Bank Statement", ("bank statement", "account statement")),
    ("Insurance Document", ("insurance policy", "insurance claim", "insurance certificate")),
    ("Tax Document", ("tax return", "form 16", "form 1040", "form 1099", "w-2")),
    ("Invoice", ("invoice", "bill of sale")),
    ("Employment Record", ("employee record", "employment record", "pay slip", "payslip", "pay stub")),
    ("Education Record", ("school transcript", "academic transcript", "marksheet", "mark sheet", "report card")),
    ("Property Document", ("property deed", "title deed", "property registration")),
    ("Utility Bill", ("electricity bill", "utility bill", "water bill")),
    ("Legal Agreement", ("agreement", "contract")),
    ("Receipt", ("receipt",)),
    ("Application Form", ("application form",)),
    ("Identity Card", ("identity card", "identification card")),
)


def infer_document_type(elements: list[DocumentElement]) -> str:
    """Return a safe, non-personal document label, or a generic fallback."""
    text = " ".join(element.text for element in elements[:200]).lower()
    compact_text = re.sub(r"[^a-z0-9]", "", text)
    for label, phrases in _DOCUMENT_TYPES:
        if any(re.sub(r"[^a-z0-9]", "", phrase) in compact_text for phrase in phrases):
            return label
    return "Secure Document"
