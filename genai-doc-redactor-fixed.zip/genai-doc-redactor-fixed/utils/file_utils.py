import uuid
from pathlib import Path
from config import UPLOAD_DIR, OUTPUT_DIR, TEMP_DIR, MAX_FILE_SIZE_MB

ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".docx"}


def validate_file(filename: str, file_size_bytes: int) -> tuple[bool, str]:
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        return False, f"Unsupported file type: {ext}. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
    if file_size_bytes <= 0:
        return False, "The selected file is empty. Please choose a PDF, Word document or image with content."
    max_bytes = MAX_FILE_SIZE_MB * 1024 * 1024
    if file_size_bytes > max_bytes:
        return False, f"File too large ({file_size_bytes / 1024 / 1024:.1f} MB). Max: {MAX_FILE_SIZE_MB} MB"
    return True, ""


def save_upload(filename: str, data: bytes) -> Path:
    ext = Path(filename).suffix.lower()
    unique_name = f"{uuid.uuid4().hex}{ext}"
    path = UPLOAD_DIR / unique_name
    path.write_bytes(data)
    return path


def get_output_path(original_name: str, suffix: str = "_redacted", ext: str = None) -> Path:
    stem = Path(original_name).stem
    if ext is None:
        ext = Path(original_name).suffix
    return OUTPUT_DIR / f"{stem}{suffix}{ext}"


def get_temp_path(ext: str = ".png") -> Path:
    return TEMP_DIR / f"{uuid.uuid4().hex}{ext}"


def cleanup_temp():
    if TEMP_DIR.exists():
        for f in TEMP_DIR.iterdir():
            try:
                if f.is_file() and f.name != ".gitkeep":
                    f.unlink()
            except OSError:
                pass
