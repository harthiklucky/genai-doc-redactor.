"""One-time setup: fetch the models the app needs so it can then run offline.

This is the only part of the project that is allowed to use the internet.
It downloads model files (not documents): the EasyOCR text-recognition
models, the spaCy English model used by Presidio, and checks that the local
Ollama model is installed. After it succeeds the app runs fully offline
(LOCAL_ONLY=true blocks any other connection).

    python setup_models.py
"""
from __future__ import annotations

import subprocess
import sys


def main() -> int:
    ok = True

    print("1/3 EasyOCR models ...", flush=True)
    try:
        import easyocr
        easyocr.Reader(["en"], gpu=False, verbose=False, download_enabled=True)
        print("    ready")
    except Exception as exc:  # pragma: no cover - setup helper
        ok = False
        print(f"    failed: {type(exc).__name__}: {exc}")

    print("2/3 spaCy model for Presidio (en_core_web_lg) ...", flush=True)
    try:
        import spacy
        if "en_core_web_lg" not in spacy.util.get_installed_models():
            subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_lg"])
        print("    ready")
    except Exception as exc:  # pragma: no cover - setup helper
        ok = False
        print(f"    failed: {type(exc).__name__}: {exc}")

    print("3/3 Local Ollama model ...", flush=True)
    try:
        from config import OLLAMA_MODEL
        from agents.llm_client import LLMClient
        connected, message = LLMClient().check_connection()
        if connected and OLLAMA_MODEL in message:
            print(f"    ready ({OLLAMA_MODEL})")
        else:
            print(f"    not ready: {message}")
            print(f"    Start Ollama and run: ollama pull {OLLAMA_MODEL}")
            print("    (optional: the app works without it, using deterministic matching only)")
    except Exception as exc:  # pragma: no cover - setup helper
        print(f"    not ready: {type(exc).__name__}: {exc}")

    print("Setup complete." if ok else "Setup finished with errors (see above).")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
